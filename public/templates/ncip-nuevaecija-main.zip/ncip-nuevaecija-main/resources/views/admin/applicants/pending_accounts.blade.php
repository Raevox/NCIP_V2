@extends('layouts.admin')

@section('title', 'Pending Accounts')

@section('content')
{{-- Add CSRF meta tag --}}
<meta name="csrf-token" content="{{ csrf_token() }}">

<div class="main">
    <!-- Alerts -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
    

<!-- 🔍 Search + Buttons -->
<div class="card border-0 shadow p-3 mb-4" style="min-width: 600px;">
    <div class="d-flex align-items-center gap-3 flex-wrap">
        <!-- Search -->
        <form action="{{ route('admin.applicants.accounts') }}" method="GET" style="width: 280px;">
            <input type="text" name="search" class="form-control form-control-sm rounded-3 ps-5"
                placeholder="Search by name or email..." value="{{ request('search') }}"
                style="height: 36px; background: url('data:image/svg+xml;utf8,<svg fill=\'%230d6efd\' xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' width=\'16\' height=\'16\'><path d=\'M10 2a8 8 0 015.29 13.71l4.36 4.36-1.42 1.42-4.36-4.36A8 8 0 1110 2zm0 2a6 6 0 100 12 6 6 0 000-12z\'/></svg>') no-repeat 12px center; background-size: 16px 16px;">
        </form>

        <!-- Application Button -->
        <a href="{{ route('admin.applicants.index') }}" 
           class="btn shadow-sm d-flex align-items-center justify-content-center px-4 py-3 text-decoration-none {{ request()->routeIs('admin.applicants.index') ? 'bg-primary text-white' : 'bg-light text-dark' }}"
           style="width: 140px; border-radius: 12px; font-weight: 600; transition: background-color 0.3s, box-shadow 0.3s;">
            Application
        </a>

        <!-- Approved Button -->
        <a href="{{ route('admin.applicants.accounts') }}"  
           class="btn shadow-sm d-flex align-items-center justify-content-center px-4 py-3 text-decoration-none {{ request()->routeIs('admin.applicants.accounts') ? 'bg-primary text-white' : 'bg-light text-dark' }}"
           style="width: 140px; border-radius: 12px; font-weight: 600; transition: background-color 0.3s, box-shadow 0.3s;">
            Approved
        </a>

        <!-- Pending Button -->
        <a href="{{ route('admin.applicants.pending') }}"  
           class="btn shadow-sm d-flex align-items-center justify-content-center px-4 py-3 text-decoration-none {{ request()->routeIs('admin.applicants.pending') ? 'bg-primary text-white' : 'bg-light text-dark' }}"
           style="width: 140px; border-radius: 12px; font-weight: 600; transition: background-color 0.3s, box-shadow 0.3s;">
            Pending
        </a>
    </div>
</div>

    <!-- Table -->
    <table class="table table-striped align-middle">
        <thead class="bg-dark text-white">
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>OCR Match</th>
                <th>Status</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            @forelse($pendingAccounts as $account)
                <tr>
                    <td>{{ $account->first_name }} {{ $account->last_name }}</td>
                    <td>{{ $account->email }}</td>
                    <td>{{ $account->contact ?? 'N/A' }}</td>
                    <td>
                        <span class="badge {{ $account->ocr_match === 'Match' ? 'bg-success' : 'bg-warning text-dark' }}">
                            {{ $account->ocr_match }}
                        </span>
                    </td>
                    <td>
                        <span class="badge bg-warning text-dark">
                            {{ ucfirst($account->status) }}
                        </span>
                    </td>
                    <td class="text-center">
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light border rounded-circle" data-bs-toggle="dropdown">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow-sm rounded-3">
                                <li>
                                    <a class="dropdown-item" href="{{ route('admin.applicants.view', $account->id) }}">
                                        <i class="fas fa-eye me-2"></i>View Details
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <button type="button" 
                                            class="dropdown-item text-success"
                                            onclick="showApproveModal('{{ $account->first_name }} {{ $account->last_name }}', '{{ $account->id }}')">
                                        <i class="fas fa-check-circle me-2"></i>Approve Account
                                    </button>
                                </li>
                                <li>
                                    <button type="button" 
                                            class="dropdown-item text-danger"
                                            onclick="showDeclineModal('{{ $account->first_name }} {{ $account->last_name }}', '{{ $account->id }}', '{{ $account->email }}')">
                                        <i class="fas fa-times-circle me-2"></i>Decline & Remove
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="6" class="text-center text-muted py-4">
                        <i class="fas fa-inbox fa-2x mb-2"></i><br>
                        No pending accounts found.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- Approve Modal --}}
<div class="modal fade" id="approveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">
                    <i class="fas fa-user-check me-2"></i>
                    Approve Account
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <div class="mb-3">
                    <i class="fas fa-shield-alt text-success" style="font-size: 3rem;"></i>
                </div>
                <h6 class="fw-bold mb-3">Confirm Account Approval</h6>
                <p class="mb-0">Are you sure you want to approve the account for <strong id="approveAccountName"></strong>?</p>
                <small class="text-muted">This will move the account to active IP accounts and send a welcome email.</small>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-success" onclick="submitApproval()">
                    <i class="fas fa-check me-2"></i>
                    Approve Account
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Decline Modal --}}
<div class="modal fade" id="declineModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="fas fa-user-times me-2"></i>
                    Decline & Remove Account
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-4">
                    <i class="fas fa-exclamation-triangle text-danger" style="font-size: 3rem;"></i>
                    <h6 class="fw-bold mt-3 mb-2">Decline Account Registration</h6>
                    <p class="mb-0">You are about to decline <strong id="declineAccountName"></strong>'s account registration.</p>
                    <small class="text-muted">This account will be permanently removed from the database.</small>
                </div>
                
                <div class="text-start">
                    <label class="form-label fw-bold text-danger">
                        <i class="fas fa-clipboard-list me-1"></i>
                        Reason for Decline (Required):
                    </label>
                    <textarea id="declineReason" class="form-control" rows="4" 
                              placeholder="Please specify what needs to be corrected or why this account is being declined..."></textarea>
                    <div class="form-text">
                        <strong>This message will be sent via email to:</strong> <span id="declineAccountEmail" class="text-primary"></span>
                    </div>
                </div>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" onclick="submitDecline()" id="declineSubmitBtn">
                    <i class="fas fa-trash me-2"></i>
                    Decline & Remove
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Result Modal --}}
<div class="modal fade" id="resultModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" id="resultModalHeader">
                <h5 class="modal-title" id="resultModalTitle"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <div id="resultModalIcon" class="mb-3"></div>
                <p id="resultModalMessage" class="mb-0"></p>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn" id="resultModalBtn" onclick="reloadPage()">OK</button>
            </div>
        </div>
    </div>
</div>

{{-- Loading Modal --}}
<div class="modal fade" id="loadingModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-body text-center py-4">
                <div class="spinner-border text-primary mb-3" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mb-0">Processing request...</p>
            </div>
        </div>
    </div>
</div>

<script>
let currentAccountId = null;
let actionType = null;

function showApproveModal(accountName, accountId) {
    document.getElementById('approveAccountName').textContent = accountName;
    currentAccountId = accountId;
    actionType = 'approve';
    
    const modal = new bootstrap.Modal(document.getElementById('approveModal'));
    modal.show();
}

function showDeclineModal(accountName, accountId, accountEmail) {
    document.getElementById('declineAccountName').textContent = accountName;
    document.getElementById('declineAccountEmail').textContent = accountEmail;
    currentAccountId = accountId;
    actionType = 'decline';
    
    // Clear previous reason
    document.getElementById('declineReason').value = '';
    
    const modal = new bootstrap.Modal(document.getElementById('declineModal'));
    modal.show();
}

function submitApproval() {
    if (!currentAccountId) return;
    
    hideCurrentModal();
    showLoadingModal();
    
    const token = getCSRFToken();
    if (!token) {
        hideLoadingModal();
        showResultModal(false, 'CSRF token not found. Please refresh the page.', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('_token', token);
    
    console.log('Approving account ID:', currentAccountId);
    
    fetch(`/admin/applicants/${currentAccountId}/approve`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        }
    })
    .then(response => {
        console.log('Response status:', response.status);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('Response data:', data);
        hideLoadingModal();
        showResultModal(data.success, data.message, 'approved');
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoadingModal();
        showResultModal(false, 'Error approving account: ' + error.message, 'error');
    });
}

function submitDecline() {
    if (!currentAccountId) return;
    
    const reason = document.getElementById('declineReason').value.trim();
    if (!reason) {
        alert('Please provide a reason for declining this account.');
        return;
    }
    
    hideCurrentModal();
    showLoadingModal();
    
    const token = getCSRFToken();
    if (!token) {
        hideLoadingModal();
        showResultModal(false, 'CSRF token not found. Please refresh the page.', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('_token', token);
    formData.append('reason', reason);
    
    console.log('Declining account ID:', currentAccountId);
    console.log('Decline reason:', reason);
    
    fetch(`/admin/applicants/${currentAccountId}/decline`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        }
    })
    .then(response => {
        console.log('Response status:', response.status);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('Response data:', data);
        hideLoadingModal();
        showResultModal(data.success, data.message, 'declined');
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoadingModal();
        showResultModal(false, 'Error declining account: ' + error.message, 'error');
    });
}

function showResultModal(success, message, type) {
    const modal = document.getElementById('resultModal');
    const header = document.getElementById('resultModalHeader');
    const title = document.getElementById('resultModalTitle');
    const icon = document.getElementById('resultModalIcon');
    const messageEl = document.getElementById('resultModalMessage');
    const btn = document.getElementById('resultModalBtn');
    
    if (success) {
        if (type === 'approved') {
            header.className = 'modal-header bg-success text-white';
            title.textContent = 'Account Approved';
            icon.innerHTML = '<i class="fas fa-user-check text-success" style="font-size: 3rem;"></i>';
            btn.className = 'btn btn-success';
        } else if (type === 'declined') {
            header.className = 'modal-header bg-warning text-white';
            title.textContent = 'Account Declined';
            icon.innerHTML = '<i class="fas fa-user-times text-warning" style="font-size: 3rem;"></i>';
            btn.className = 'btn btn-warning';
        }
    } else {
        header.className = 'modal-header bg-danger text-white';
        title.textContent = 'Error';
        icon.innerHTML = '<i class="fas fa-exclamation-circle text-danger" style="font-size: 3rem;"></i>';
        btn.className = 'btn btn-danger';
    }
    
    messageEl.textContent = message;
    
    const resultModal = new bootstrap.Modal(modal);
    resultModal.show();
}

// Helper functions
function getCSRFToken() {
    return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || 
           document.querySelector('input[name="_token"]')?.value;
}

function hideCurrentModal() {
    const modals = ['approveModal', 'declineModal'];
    modals.forEach(modalId => {
        const modalEl = document.getElementById(modalId);
        const modalInstance = bootstrap.Modal.getInstance(modalEl);
        if (modalInstance) {
            modalInstance.hide();
        }
    });
}

function showLoadingModal() {
    const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
    loadingModal.show();
}

function hideLoadingModal() {
    const loadingModalEl = document.getElementById('loadingModal');
    const loadingModalInstance = bootstrap.Modal.getInstance(loadingModalEl);
    if (loadingModalInstance) {
        loadingModalInstance.dispose();
    }
    loadingModalEl.style.display = 'none';
    loadingModalEl.removeAttribute('aria-hidden');
    document.body.classList.remove('modal-open');
    
    const backdrop = document.querySelector('.modal-backdrop');
    if (backdrop) {
        backdrop.remove();
    }
}

function reloadPage() {
    window.location.reload();
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    currentAccountId = null;
    actionType = null;
});
</script>

{{-- Add Font Awesome if not already included --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

@endsection