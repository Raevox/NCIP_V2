@extends('layouts.admin')

@section('title', 'Approved Accounts')

@section('content')
<div class="main">
<div class="card border-0 shadow p-3 mb-4" style="min-width: 600px;">
        <div class="d-flex align-items-center gap-3 flex-wrap">
            <form action="{{ route('admin.applicants.accounts') }}" method="GET" style="width: 280px;">
                <input type="text" name="search" class="form-control form-control-sm rounded-3 ps-5"
                    placeholder="Search by name or email..." value="{{ request('search') }}">
            </form>
            <a href="{{ route('admin.applicants.index') }}" 
               class="btn shadow-sm d-flex align-items-center justify-content-center px-4 py-3 text-decoration-none {{ request()->routeIs('admin.applicants.index') ? 'bg-primary text-white' : 'bg-light text-dark' }}"
               style="width: 140px; border-radius: 12px; font-weight: 600; transition: background-color 0.3s, box-shadow 0.3s;">
                Application
            </a>
            <a href="{{ route('admin.applicants.accounts') }}"  
               class="btn shadow-sm d-flex align-items-center justify-content-center px-4 py-3 text-decoration-none {{ request()->routeIs('admin.applicants.accounts') ? 'bg-primary text-white' : 'bg-light text-dark' }}"
               style="width: 140px; border-radius: 12px; font-weight: 600; transition: background-color 0.3s, box-shadow 0.3s;">
                Approved
            </a>
            <a href="{{ route('admin.applicants.pending') }}"  
               class="btn shadow-sm d-flex align-items-center justify-content-center px-4 py-3 text-decoration-none {{ request()->routeIs('admin.applicants.pending') ? 'bg-primary text-white' : 'bg-light text-dark' }}"
               style="width: 140px; border-radius: 12px; font-weight: 600; transition: background-color 0.3s, box-shadow 0.3s;">
                Pending
            </a>
        </div>
    </div>
        <table class="table table-striped align-middle">
        <thead class="bg-dark text-white">
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Tribe</th>
                <th>Status</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            @forelse($approvedUsers as $user)
                <tr>
                    <td>{{ $user->first_name }} {{ $user->last_name }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ $user->contact ?? '—' }}</td>
                    <td>{{ $user->tribe ?? '—' }}</td>
                    <td><span class="badge bg-success">Active</span></td>
                    <td class="text-center">
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light border" data-bs-toggle="dropdown">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a href="{{ route('admin.applicants.view', $user->id) }}" class="dropdown-item">View</a>
                                </li>
                                <li>
                                        <form action="{{ route('admin.applicants.accounts.archive', $user->id) }}" method="POST">
                                            @csrf
                                            <button class="dropdown-item text-danger">Archive</button>
                                        </form>
                                        
                                    </li>
                                </ul>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="6" class="text-center text-muted py-4">No approved accounts.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    <div class="mt-3">{{ $approvedUsers->links('pagination::bootstrap-4') }}</div>
</div>
@endsection
