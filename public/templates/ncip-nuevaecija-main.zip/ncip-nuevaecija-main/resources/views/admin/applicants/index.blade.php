@extends('layouts.admin')

@section('title', 'Applicants')

@section('content')
{{-- Add CSRF meta tag to head if not already in layout --}}
<meta name="csrf-token" content="{{ csrf_token() }}">

<div class="main">
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    
    <div class="card border-0 shadow p-3 mb-4" style="min-width: 600px;">
        <div class="d-flex align-items-center gap-3 flex-wrap">
            <div class="position-relative" style="width: 280px;">
                <input
                    type="text"
                    id="searchInput"
                    class="form-control form-control-sm rounded-3 ps-5"
                    placeholder="Search by name or email..."
                    value="{{ request('search') }}"
                    style="height: 36px; background: url('data:image/svg+xml;utf8,<svg fill=\'%230d6efd\' xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' width=\'16\' height=\'16\'><path d=\'M10 2a8 8 0 015.29 13.71l4.36 4.36-1.42 1.42-4.36-4.36A8 8 0 1110 2zm0 2a6 6 0 100 12 6 6 0 000-12z\'/></svg>') no-repeat 12px center; background-size: 16px 16px;"
                />
                <div id="searchSpinner" class="position-absolute top-50 end-0 translate-middle-y me-2" style="display: none;">
                    <div class="spinner-border spinner-border-sm text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
            <a href="{{ route('admin.applicants.index') }}" 
               class="btn shadow-sm d-flex align-items-center justify-content-center px-4 py-3 text-decoration-none {{ request()->routeIs('admin.applicants.index') ? 'bg-primary text-white' : 'bg-light text-dark' }}"
               style="width: 140px; border-radius: 12px; font-weight: 600;">
                Application
            </a>
            <a href="{{ route('admin.applicants.accounts') }}" 
               class="btn shadow-sm d-flex align-items-center justify-content-center px-4 py-3 text-decoration-none {{ request()->routeIs('admin.applicants.accounts') ? 'bg-primary text-white' : 'bg-light text-dark' }}"
               style="width: 140px; border-radius: 12px; font-weight: 600;">
                Account
            </a>
        </div>
    </div>
    
    <div class="d-flex justify-content-between align-items-center mb-3">
        <ul class="nav nav-tabs mb-0">
            <li class="nav-item">
                <a class="nav-link {{ $status === 'all' ? 'active' : '' }}" 
                   href="{{ route('admin.applicants.index', ['status' => 'all']) }}">
                    All
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ $status === 'Approved' ? 'active' : '' }}" 
                   href="{{ route('admin.applicants.index', ['status' => 'Approved']) }}">
                    Approved
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ $status === 'Admin Approval' ? 'active' : '' }}" 
                   href="{{ route('admin.applicants.index', ['status' => 'Admin Approval']) }}">
                    Admin Approval
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ $status === 'Returned' ? 'active' : '' }}" 
                   href="{{ route('admin.applicants.index', ['status' => 'Returned']) }}">
                    Returned
                </a>
            </li>
        </ul>
        
        <div class="d-flex align-items-center">
            <span class="text-muted me-2">Showing:</span>
            <span id="applicantCount" class="badge bg-primary fs-6">{{ $applications->total() }}</span>
            <span class="text-muted ms-1">applicant(s)</span>
        </div>
    </div>

    <div class="table-responsive rounded-3 border shadow-sm">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-dark text-white">
                <tr>
                    <th class="text-start ps-4">Name</th>
                    <th class="text-center">Date of Application</th>
                    <th class="text-center">IP Group</th>
                    <th class="text-center">Endorsement</th>
                    <th class="text-center">COC Status</th>
                    <th class="text-center pe-4">Action</th>
                </tr>
            </thead>
            <tbody id="applicantsTableBody">
                @forelse($applications as $coc)
                    <tr class="applicant-row">
                        <td class="text-start ps-4">
                            <div class="d-flex align-items-center">
                                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px; font-weight: 600;">
                                    {{ strtoupper(substr($coc->applicant->first_name, 0, 1)) }}{{ strtoupper(substr($coc->applicant->last_name, 0, 1)) }}
                                </div>
                                <div>
                                    <div class="fw-semibold">{{ $coc->applicant->first_name }} {{ $coc->applicant->last_name }}</div>
                                    <small class="text-muted">{{ $coc->applicant->email ?? '-' }}</small>
                                </div>
                            </div>
                        </td>
                        <td class="text-center">
                            <div class="text-primary fw-medium">{{ $coc->created_at?->format('M d, Y') ?? '-' }}</div>
                            <small class="text-muted">{{ $coc->created_at?->format('h:i A') ?? '-' }}</small>
                        </td>
                        <td class="text-center">
                            <span class="badge bg-light text-dark border">{{ $coc->applicant->tribe ?? '-' }}</span>
                        </td>
                        <td class="text-center">
                            @if(!empty($coc->classification))
                                @foreach($coc->classification as $class)
                                    <span class="badge bg-info me-1">{{ $class }}</span>
                                @endforeach
                            @else
                                -
                            @endif
                        </td>
                        <td class="text-center">
                            @if($coc->coc_status === 'Approved')
                                <span class="badge bg-success rounded-pill px-3 py-2">Approved</span>
                            @elseif($coc->coc_status === 'Returned')
                                <span class="badge bg-danger rounded-pill px-3 py-2">Returned</span>
                            @elseif($coc->coc_status === 'Admin Approval')
                                <span class="badge bg-warning text-dark rounded-pill px-3 py-2">Admin Approval</span>
                            @else
                                <span class="badge bg-secondary rounded-pill px-3 py-2">{{ $coc->coc_status }}</span>
                            @endif
                        </td>
                        <td class="text-center pe-4">
                            <div class="dropdown">
                                <button class="btn btn-sm btn-light border rounded-circle" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end shadow-sm rounded-3">
                                    <li>
                                        <a href="{{ route('admin.applicants.view', $coc->applicant->id) }}" class="dropdown-item">
                                            <i class="fas fa-eye me-2"></i>View
                                        </a>
                                    </li>
                                    @if($coc->coc_status === 'Admin Approval')
                                        <li><hr class="dropdown-divider"></li>
                                        <li>
                                            <button type="button" 
                                                    class="dropdown-item text-success"
                                                    onclick="showApproveModal('{{ $coc->applicant->first_name }} {{ $coc->applicant->last_name }}', '{{ $coc->id }}')">
                                                <i class="fas fa-check me-2"></i>Approve (Issue COC)
                                            </button>
                                        </li>
                                        <li>
                                            <button type="button" 
                                                    class="dropdown-item text-danger"
                                                    onclick="showDeclineModal('{{ $coc->applicant->first_name }} {{ $coc->applicant->last_name }}', '{{ $coc->applicant->id }}')">
                                                <i class="fas fa-times me-2"></i>Decline
                                            </button>
                                        </li>
                                    @endif
                                </ul>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="fas fa-inbox fa-2x mb-3 d-block"></i>
                            No applications found.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    
    <div class="mt-3 d-flex justify-content-between align-items-center">
        <div class="text-muted" id="paginationInfo">
            Showing {{ $applications->firstItem() ?? 0 }} to {{ $applications->lastItem() ?? 0 }} of {{ $applications->total() }} entries
        </div>
        <div id="paginationLinks">
            {{ $applications->links('pagination::bootstrap-4') }}
        </div>
    </div>
</div>

{{-- Approve Modal --}}
<div class="modal fade" id="approveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">
                    <i class="fas fa-check-circle me-2"></i>
                    Approve Application
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <div class="mb-3">
                    <i class="fas fa-user-check text-success" style="font-size: 3rem;"></i>
                </div>
                <h6 class="fw-bold mb-3">Confirm Approval</h6>
                <p class="mb-0">Are you sure you want to approve and issue COC to <strong id="approveApplicantName"></strong>?</p>
                <small class="text-muted">This action will generate a Certificate of Confirmation for the applicant.</small>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-success" onclick="submitApproval()">
                    <i class="fas fa-check me-2"></i>
                    Approve & Issue COC
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Decline Modal --}}
<div class="modal fade" id="declineModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="fas fa-times-circle me-2"></i>
                    Decline Application
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <div class="mb-3">
                    <i class="fas fa-user-times text-danger" style="font-size: 3rem;"></i>
                </div>
                <h6 class="fw-bold mb-3">Confirm Decline</h6>
                <p class="mb-3">Are you sure you want to decline <strong id="declineApplicantName"></strong>'s application?</p>
                <div class="text-start">
                    <label class="form-label fw-bold">Reason for declining (Optional):</label>
                    <textarea id="declineReason" class="form-control" rows="3" placeholder="Enter reason for declining this application..."></textarea>
                </div>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" onclick="submitDecline()">
                    <i class="fas fa-times me-2"></i>
                    Decline Application
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Result Modal --}}
<div class="modal fade" id="resultModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" id="resultModalHeader">
                <h5 class="modal-title" id="resultModalTitle"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <div id="resultModalIcon" class="mb-3"></div>
                <p id="resultModalMessage" class="mb-0"></p>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn" id="resultModalBtn" data-bs-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>

{{-- Loading Modal --}}
<div class="modal fade" id="loadingModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-body text-center py-4">
                <div class="spinner-border text-primary mb-3" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mb-0">Processing request...</p>
            </div>
        </div>
    </div>
</div>

<script>
let currentApplicantId = null;
let currentApplicationId = null;
let actionType = null;
let searchTimeout = null;

// AJAX Search Functionality
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const searchSpinner = document.getElementById('searchSpinner');
    
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const searchTerm = this.value.trim();
            
            if (searchTerm.length >= 2 || searchTerm.length === 0) {
                searchSpinner.style.display = 'block';
                
                searchTimeout = setTimeout(() => {
                    performSearch(searchTerm);
                }, 500);
            }
        });
    }
});

function performSearch(searchTerm) {
    const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
    const status = '{{ $status }}'; // Get current status from server
    
    fetch('{{ route("admin.applicants.search") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': token,
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            search: searchTerm,
            status: status
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('searchSpinner').style.display = 'none';
        updateTable(data.applicants, data.pagination);
        updateCount(data.total);
        updatePaginationInfo(data.pagination);
    })
    .catch(error => {
        console.error('Error during search:', error);
        document.getElementById('searchSpinner').style.display = 'none';
    });
}

function updateTable(applicants, pagination) {
    const tbody = document.getElementById('applicantsTableBody');
    
    if (applicants.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center text-muted py-4">
                    <i class="fas fa-inbox fa-2x mb-3 d-block"></i>
                    No applications found.
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    applicants.forEach(coc => {
        // Determine status badge
        let statusBadge = '';
        if (coc.coc_status === 'Approved') {
            statusBadge = '<span class="badge bg-success rounded-pill px-3 py-2">Approved</span>';
        } else if (coc.coc_status === 'Returned') {
            statusBadge = '<span class="badge bg-danger rounded-pill px-3 py-2">Returned</span>';
        } else if (coc.coc_status === 'Admin Approval') {
            statusBadge = '<span class="badge bg-warning text-dark rounded-pill px-3 py-2">Admin Approval</span>';
        } else {
            statusBadge = `<span class="badge bg-secondary rounded-pill px-3 py-2">${coc.coc_status}</span>`;
        }
        
        // Format classification badges
        let classificationBadges = '-';
        if (coc.classification && coc.classification.length > 0) {
            classificationBadges = coc.classification.map(cls => 
                `<span class="badge bg-info me-1">${cls}</span>`
            ).join('');
        }
        
        // Format date
        const appDate = coc.created_at ? new Date(coc.created_at) : null;
        const dateFormatted = appDate ? appDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '-';
        const timeFormatted = appDate ? appDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) : '-';
        
        html += `
            <tr class="applicant-row">
                <td class="text-start ps-4">
                    <div class="d-flex align-items-center">
                        <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px; font-weight: 600;">
                            ${coc.applicant.first_name ? coc.applicant.first_name.charAt(0).toUpperCase() : ''}${coc.applicant.last_name ? coc.applicant.last_name.charAt(0).toUpperCase() : ''}
                        </div>
                        <div>
                            <div class="fw-semibold">${coc.applicant.first_name} ${coc.applicant.last_name}</div>
                            <small class="text-muted">${coc.applicant.email || '-'}</small>
                        </div>
                    </div>
                </td>
                <td class="text-center">
                    <div class="text-primary fw-medium">${dateFormatted}</div>
                    <small class="text-muted">${timeFormatted}</small>
                </td>
                <td class="text-center">
                    <span class="badge bg-light text-dark border">${coc.applicant.tribe || '-'}</span>
                </td>
                <td class="text-center">
                    ${classificationBadges}
                </td>
                <td class="text-center">
                    ${statusBadge}
                </td>
                <td class="text-center pe-4">
                    <div class="dropdown">
                        <button class="btn btn-sm btn-light border rounded-circle" data-bs-toggle="dropdown">
                            <i class="fas fa-ellipsis-v"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm rounded-3">
                            <li>
                                <a href="/admin/applicants/view/${coc.applicant.id}" class="dropdown-item">
                                    <i class="fas fa-eye me-2"></i>View
                                </a>
                            </li>
                            ${coc.coc_status === 'Admin Approval' ? `
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <button type="button" 
                                            class="dropdown-item text-success"
                                            onclick="showApproveModal('${coc.applicant.first_name} ${coc.applicant.last_name}', '${coc.id}')">
                                        <i class="fas fa-check me-2"></i>Approve (Issue COC)
                                    </button>
                                </li>
                                <li>
                                    <button type="button" 
                                            class="dropdown-item text-danger"
                                            onclick="showDeclineModal('${coc.applicant.first_name} ${coc.applicant.last_name}', '${coc.applicant.id}')">
                                        <i class="fas fa-times me-2"></i>Decline
                                    </button>
                                </li>
                            ` : ''}
                        </ul>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

function updateCount(total) {
    document.getElementById('applicantCount').textContent = total;
}

function updatePaginationInfo(pagination) {
    const paginationInfo = document.getElementById('paginationInfo');
    const paginationLinks = document.getElementById('paginationLinks');
    
    if (paginationInfo && pagination) {
        const from = pagination.from || 0;
        const to = pagination.to || 0;
        const total = pagination.total || 0;
        
        paginationInfo.textContent = `Showing ${from} to ${to} of ${total} entries`;
    }
    
    if (paginationLinks && pagination.links) {
        // This is a simplified version - you might need to adjust based on your pagination structure
        paginationLinks.innerHTML = pagination.links;
    }
}

// Existing modal functions (unchanged)
function showApproveModal(applicantName, applicationId) {
    document.getElementById('approveApplicantName').textContent = applicantName;
    currentApplicationId = applicationId;
    actionType = 'approve';
    
    const modal = new bootstrap.Modal(document.getElementById('approveModal'));
    modal.show();
}

function showDeclineModal(applicantName, applicantId) {
    document.getElementById('declineApplicantName').textContent = applicantName;
    currentApplicantId = applicantId;
    actionType = 'decline';
    
    const modal = new bootstrap.Modal(document.getElementById('declineModal'));
    modal.show();
}

function submitApproval() {
    if (!currentApplicationId) return;
    
    const approveModal = bootstrap.Modal.getInstance(document.getElementById('approveModal'));
    approveModal.hide();
    
    const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
    loadingModal.show();
    
    const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || 
                  document.querySelector('input[name="_token"]')?.value;
    
    if (!token) {
        console.error('CSRF token not found');
        loadingModal.hide();
        showResultModal(false, 'CSRF token not found. Please refresh the page.', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('_token', token);
    
    fetch(`/admin/applicants/${currentApplicationId}/coc-approve`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        const loadingModalEl = document.getElementById('loadingModal');
        const loadingModalInstance = bootstrap.Modal.getInstance(loadingModalEl);
        if (loadingModalInstance) {
            loadingModalInstance.dispose();
        }
        loadingModalEl.style.display = 'none';
        loadingModalEl.removeAttribute('aria-hidden');
        document.body.classList.remove('modal-open');
        
        const backdrop = document.querySelector('.modal-backdrop');
        if (backdrop) {
            backdrop.remove();
        }
        
        showResultModal(data.success, data.message, 'approved');
    })
    .catch(error => {
        console.error('Error:', error);
        const loadingModalEl = document.getElementById('loadingModal');
        const loadingModalInstance = bootstrap.Modal.getInstance(loadingModalEl);
        if (loadingModalInstance) {
            loadingModalInstance.dispose();
        }
        loadingModalEl.style.display = 'none';
        loadingModalEl.removeAttribute('aria-hidden');
        document.body.classList.remove('modal-open');
        
        const backdrop = document.querySelector('.modal-backdrop');
        if (backdrop) {
            backdrop.remove();
        }
        
        showResultModal(false, 'An error occurred while processing the approval: ' + error.message, 'error');
    });
}

function submitDecline() {
    if (!currentApplicantId) return;
    
    const declineModal = bootstrap.Modal.getInstance(document.getElementById('declineModal'));
    declineModal.hide();
    
    const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
    loadingModal.show();
    
    const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || 
                  document.querySelector('input[name="_token"]')?.value;
    
    if (!token) {
        console.error('CSRF token not found');
        loadingModal.hide();
        showResultModal(false, 'CSRF token not found. Please refresh the page.', 'error');
        return;
    }
    
    const reason = document.getElementById('declineReason').value;
    
    const formData = new FormData();
    formData.append('_token', token);
    formData.append('reason', reason);
    
    fetch(`/admin/applicants/${currentApplicantId}/decline`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        const loadingModalEl = document.getElementById('loadingModal');
        const loadingModalInstance = bootstrap.Modal.getInstance(loadingModalEl);
        if (loadingModalInstance) {
            loadingModalInstance.dispose();
        }
        loadingModalEl.style.display = 'none';
        loadingModalEl.removeAttribute('aria-hidden');
        document.body.classList.remove('modal-open');
        
        const backdrop = document.querySelector('.modal-backdrop');
        if (backdrop) {
            backdrop.remove();
        }
        
        showResultModal(data.success, data.message, 'declined');
    })
    .catch(error => {
        console.error('Error:', error);
        const loadingModalEl = document.getElementById('loadingModal');
        const loadingModalInstance = bootstrap.Modal.getInstance(loadingModalEl);
        if (loadingModalInstance) {
            loadingModalInstance.dispose();
        }
        loadingModalEl.style.display = 'none';
        loadingModalEl.removeAttribute('aria-hidden');
        document.body.classList.remove('modal-open');
        
        const backdrop = document.querySelector('.modal-backdrop');
        if (backdrop) {
            backdrop.remove();
        }
        
        showResultModal(false, 'An error occurred while processing the decline: ' + error.message, 'error');
    });
}

function showResultModal(success, message, type) {
    const modal = document.getElementById('resultModal');
    const header = document.getElementById('resultModalHeader');
    const title = document.getElementById('resultModalTitle');
    const icon = document.getElementById('resultModalIcon');
    const messageEl = document.getElementById('resultModalMessage');
    const btn = document.getElementById('resultModalBtn');
    
    if (success) {
        if (type === 'approved') {
            header.className = 'modal-header bg-success text-white';
            title.textContent = 'Application Approved';
            icon.innerHTML = '<i class="fas fa-check-circle text-success" style="font-size: 3rem;"></i>';
            btn.className = 'btn btn-success';
        } else if (type === 'declined') {
            header.className = 'modal-header bg-warning text-white';
            title.textContent = 'Application Declined';
            icon.innerHTML = '<i class="fas fa-exclamation-triangle text-warning" style="font-size: 3rem;"></i>';
            btn.className = 'btn btn-warning';
        }
    } else {
        header.className = 'modal-header bg-danger text-white';
        title.textContent = 'Error';
        icon.innerHTML = '<i class="fas fa-times-circle text-danger" style="font-size: 3rem;"></i>';
        btn.className = 'btn btn-danger';
    }
    
    messageEl.textContent = message;
    
    const resultModal = new bootstrap.Modal(modal);
    resultModal.show();
    
    modal.addEventListener('hidden.bs.modal', function () {
        window.location.reload();
    });
}

// Clean up on page load
document.addEventListener('DOMContentLoaded', function() {
    currentApplicantId = null;
    currentApplicationId = null;
    actionType = null;
    
    const declineReason = document.getElementById('declineReason');
    if (declineReason) {
        declineReason.value = '';
    }
});
</script>

{{-- Add Font Awesome if not already included --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

@endsection