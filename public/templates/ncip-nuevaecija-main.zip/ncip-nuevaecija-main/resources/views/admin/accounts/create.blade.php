
@extends('layouts.admin')

@section('title', 'Add New Employee Account')

@section('content')
<div class="main">
    <div class="card shadow border-0 p-4" style="max-width: 900px; margin:auto; border-radius: 12px;">
        <h4 class="mb-1 fw-bold">Add New Employee Account</h4>
        <p class="text-muted mb-4">Fill up the form to create a new staff account.</p>

        <!-- Error Messages -->
        @if ($errors->any())
            <div class="alert alert-danger rounded-3">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <!-- Form -->
        <form action="{{ route('admin.accounts.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row g-3">
                <!-- First Name -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">First Name</label>
                    <input type="text" name="first_name" 
                           class="form-control rounded-3 @error('first_name') is-invalid @enderror" 
                           placeholder="Enter first name" value="{{ old('first_name') }}" required>
                </div>

                <!-- Last Name -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">Last Name</label>
                    <input type="text" name="last_name" 
                           class="form-control rounded-3 @error('last_name') is-invalid @enderror" 
                           placeholder="Enter last name" value="{{ old('last_name') }}" required>
                </div>

                <!-- Profile Picture -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">Profile Picture</label>
                    <input type="file" name="profile_picture" 
                           class="form-control rounded-3 @error('profile_picture') is-invalid @enderror">
                </div>

                <!-- Role -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">Role</label>
                    <select name="role" class="form-select rounded-3">
                        <option value="staff" selected>Staff</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>

                <!-- Phone -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">Phone Number</label>
                    <input type="text" name="contact" 
                           class="form-control rounded-3 @error('contact') is-invalid @enderror" 
                           placeholder="Enter phone number" value="{{ old('contact') }}">
                </div>

                <!-- Email -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">Email</label>
                    <input type="email" name="email" 
                           class="form-control rounded-3 @error('email') is-invalid @enderror" 
                           placeholder="example@gmail.com" value="{{ old('email') }}" required>
                </div>

                <!-- Address -->
                <div class="col-md-12">
                    <label class="form-label fw-bold">Address</label>
                    <input type="text" name="address" 
                           class="form-control rounded-3 @error('address') is-invalid @enderror" 
                           placeholder="Enter address" value="{{ old('address') }}">
                </div>

                <!-- Password -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">Password</label>
                    <input type="password" name="password" 
                           class="form-control rounded-3 @error('password') is-invalid @enderror" 
                           placeholder="Enter password" required>
                </div>

                <!-- Status -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">Status</label>
                    <select name="status" class="form-select rounded-3">
                        <option value="active" selected>Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
            </div>

            <!-- Buttons -->
            <div class="d-flex justify-content-end mt-4 gap-2">
                <a href="{{ route('admin.accounts.index') }}" class="btn btn-secondary px-4">Cancel</a>
                <button type="submit" class="btn btn-primary px-4">Save</button>
            </div>
        </form>
    </div>
</div>
@endsection