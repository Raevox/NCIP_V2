@extends('layouts.admin')

@section('title', 'View Account')

@section('content')
<div class="main p-4">
    <div class="card shadow p-4">
        <h2 class="mb-4">Account Details</h2>
        <p><strong>Name:</strong> {{ $account->name }}</p>
        <p><strong>Email:</strong> {{ $account->email }}</p>
        <p><strong>Created At:</strong> {{ $account->created_at->format('M d, Y') }}</p>

        <a href="{{ route('admin.accounts.index') }}" class="btn btn-secondary mt-3">Back</a>
    </div>
</div>
@endsection
