@extends('layouts.admin')

@section('title', 'Accounts')

@section('content')
<div class="main">
    <div class="container mt-2">
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i> {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
</div>


    <!-- 🔍 Search + Toggle Buttons -->
    <div class="card border-0 shadow p-3 mb-4" style="min-width: 600px;">
        <div class="d-flex align-items-center gap-3 flex-wrap">

            <!-- Search Bar -->
            <form action="{{ route('admin.accounts.index') }}" method="GET" style="width: 280px;">
                <input
                    type="text"
                    name="search"
                    class="form-control form-control-sm rounded-3 ps-5"
                    placeholder="Search by name or email..."
                    value="{{ request('search') }}"
                    style="height: 36px; background: url('data:image/svg+xml;utf8,<svg fill=\'%230d6efd\' xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' width=\'16\' height=\'16\'><path d=\'M10 2a8 8 0 015.29 13.71l4.36 4.36-1.42 1.42-4.36-4.36A8 8 0 1110 2zm0 2a6 6 0 100 12 6 6 0 000-12z\'/></svg>') no-repeat 12px center; background-size: 16px 16px;"
                />
            </form>

            <!-- Add New Button -->
            <a href="{{ route('admin.accounts.create') }}" 
               class="btn btn-primary shadow-sm px-4 py-2 text-decoration-none"
               style="border-radius: 12px; font-weight: 600;">
                + Add New
            </a>
        </div>
    </div>

    <!-- 📋 Accounts Table -->
    <table class="table table-striped align-middle">
        <thead class="bg-dark text-white">
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            @forelse($accounts as $account)
                <tr>
                    <td>{{ $account->first_name }} {{ $account->last_name }}</td> <!-- FIXED -->
                    <td>{{ $account->email }}</td>
                    <td>{{ $account->role ?? 'Staff' }}</td>
                    <td>
                        @if($account->isOnline())
                            <span class="badge bg-success">Active</span>
                        @else
                            <span class="badge bg-danger">Inactive</span>
                        @endif
                    </td>
                    <td class="text-center">
                        <!-- Dropdown -->
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light border" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a href="{{ route('admin.accounts.show', $account) }}" class="dropdown-item">
                                        <i class="fas fa-eye me-2"></i> View
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ route('admin.accounts.edit', $account) }}" class="dropdown-item text-success">
                                        <i class="fas fa-edit me-2"></i> Edit
                                    </a>
                                </li>
                                <li>
                                    <!-- Archive Button triggers modal -->
                                    <button class="dropdown-item text-danger" data-bs-toggle="modal" data-bs-target="#archiveModal{{ $account->id }}">
                                        <i class="fas fa-archive me-2"></i> Archive
                                    </button>
                                </li>
                            </ul>
                        </div>
                        

                        <!-- Archive Confirmation Modal -->
                        <div class="modal fade" id="archiveModal{{ $account->id }}" tabindex="-1" aria-labelledby="archiveModalLabel{{ $account->id }}" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header bg-warning text-dark">
                                        <h5 class="modal-title" id="archiveModalLabel{{ $account->id }}">
                                            <i class="fas fa-exclamation-triangle me-1"></i> Confirm Archive
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Are you sure you want to move <strong>{{ $account->first_name }} {{ $account->last_name }}</strong> to the archive?
                                        <br><br>
                                        <small class="text-muted">This action won't delete the account permanently. It can be restored later.</small>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                                        <form action="{{ route('admin.accounts.destroy', $account->id) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-warning btn-sm">Yes, Archive</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                                        <!-- End Modal -->
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="text-center text-muted py-4">No accounts found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <div class="mt-3">
        {{ $accounts->links('pagination::bootstrap-4') }}
    </div>

</div>
@endsection