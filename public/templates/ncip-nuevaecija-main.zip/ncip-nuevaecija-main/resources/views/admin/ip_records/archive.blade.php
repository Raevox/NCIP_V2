@extends('layouts.admin')

@section('title', 'Archived Records')

@section('content')
<div class="main">

    <!-- Topbar -->
    <div class="topbar mb-3">
        <h2>Archived Records</h2>
    </div>

    <!-- Flash Success -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <!-- Nav Tabs -->
    <ul class="nav nav-tabs mb-3" id="archiveTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="ip-tab" data-bs-toggle="tab" data-bs-target="#ip-records" type="button" role="tab">
                IP Records
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="staff-admin-tab" data-bs-toggle="tab" data-bs-target="#staff-admin" type="button" role="tab">
                Staff & Admin Accounts
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="ip-accounts-tab" data-bs-toggle="tab" data-bs-target="#ip-accounts" type="button" role="tab">
                Applicant Accounts
            </button>
        </li>
    </ul>

    <div class="tab-content" id="archiveTabsContent">

        <!-- Archived IP Records -->
        <div class="tab-pane fade show active" id="ip-records" role="tabpanel">
            <table class="table table-striped ip-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Present Address</th>
                        <th>IP Group</th>
                        <th>Date Archived</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($records as $record)
                        <tr>
                            <td>{{ $record->first_name }} {{ $record->last_name }}</td>
                            <td>{{ $record->barangay }}, {{ $record->municipality }}, {{ $record->province }}</td>
                            <td>{{ $record->ip_group }}</td>
                            <td>{{ $record->deleted_at ? $record->deleted_at->format('m/d/Y') : '' }}</td>
                            <td class="text-center">
                                <form action="{{ route('admin.archive.ip_records.restore', $record->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-success">
                                        <i class="fas fa-undo me-1"></i> Restore
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center">No archived IP records found.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
            <div class="pagination mt-3">
                {{ $records->links() }}
            </div>
        </div>

        <!-- Archived Staff & Admin Accounts -->
        <div class="tab-pane fade" id="staff-admin" role="tabpanel">
            <table class="table table-striped align-middle">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Date Archived</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($staffAdminAccounts as $account)
                        <tr>
                            <td>{{ $account->first_name }} {{ $account->last_name }}</td>
                            <td>{{ $account->email }}</td>
                            <td>{{ ucfirst($account->role) }}</td>
                            <td>{{ $account->deleted_at ? $account->deleted_at->format('m/d/Y') : '' }}</td>
                            <td class="text-center">
                                <form action="{{ route('admin.archive.accounts.restore', $account->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-success">
                                        <i class="fas fa-undo me-1"></i> Restore
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">No archived staff/admin accounts.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
            <div class="pagination mt-3">
                {{ $staffAdminAccounts->links() }}
            </div>
        </div>

        <!-- Archived Applicant Accounts -->
        <div class="tab-pane fade" id="ip-accounts" role="tabpanel">
            <table class="table table-striped align-middle">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Tribe</th>
                        <th>Date Archived</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($ipAccounts as $account)
                        <tr>
                            <td>{{ $account->first_name }} {{ $account->last_name }}</td>
                            <td>{{ $account->email }}</td>
                            <td>{{ $account->tribe ?? 'N/A' }}</td>
                            <td>{{ $account->deleted_at ? $account->deleted_at->format('m/d/Y') : '' }}</td>
                            <td class="text-center">
                                <form action="{{ route('admin.archive.accounts.restore', $account->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-success">
                                        <i class="fas fa-undo me-1"></i> Restore
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center">No archived applicant accounts found.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
            <div class="pagination mt-3">
                {{ $ipAccounts->links() }}
            </div>
        </div>

    </div>
</div>
@endsection
