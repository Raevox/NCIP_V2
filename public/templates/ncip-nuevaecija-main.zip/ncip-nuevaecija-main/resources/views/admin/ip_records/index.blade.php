@extends('layouts.admin')

@section('title', 'IP Records')

@section('content')
<div class="main">
    <!-- Flash Success -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <!-- Filters / Search / Download / Add New -->
    <div class="filters mb-4 d-flex flex-wrap justify-content-between align-items-center gap-2 w-100">
        <!-- Left: Search, Filters, Download -->
        <form method="GET" action="{{ route('ip_records.index') }}" class="d-flex flex-wrap align-items-center gap-2 flex-grow-1">
            <input type="text" name="search" placeholder="Search by name" value="{{ request('search') }}" class="form-control" style="min-width: 180px; flex: 1;">

            <select name="municipality" class="form-select" style="min-width: 160px; flex: 1;">
                <option value="">All Municipalities</option>
                @foreach($municipalities as $municipality)
                    <option value="{{ $municipality }}" {{ request('municipality') == $municipality ? 'selected' : '' }}>
                        {{ $municipality }}
                    </option>
                @endforeach
            </select>

            <select name="ip_group" class="form-select" style="min-width: 160px; flex: 1;">
                <option value="">All IP Groups</option>
                @foreach($ipGroups as $group)
                    <option value="{{ $group }}" {{ request('ip_group') == $group ? 'selected' : '' }}>
                        {{ $group }}
                    </option>
                @endforeach
            </select>

            <button type="submit" class="btn btn-primary">
                <i class="fas fa-filter me-1"></i> Filter
            </button>

            <button type="submit" formaction="{{ route('ip_records.download') }}" class="btn btn-success">
                <i class="fas fa-download me-1"></i> Download
            </button>
        </form>

        <!-- Right: Add New -->
        <a href="{{ route('ip_records.create') }}" class="btn btn-primary add-btn">
            <i class="fas fa-plus me-1"></i> Add New
        </a>
    </div>

    <!-- Table -->
    <table class="table table-striped ip-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Present Address</th>
                <th>IP Group</th>
                <th>Date of Census</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            @forelse($records as $record)
                <tr>
                    <td>{{ $record->first_name }} {{ $record->last_name }}</td>
                    <td>{{ $record->barangay }}, {{ $record->municipality }}, {{ $record->province }}</td>
                    <td>{{ $record->ip_group }}</td>
                    <td>{{ $record->census_date ? \Carbon\Carbon::parse($record->census_date)->format('m/d/Y') : 'N/A' }}</td>
                    <td class="text-center">
                        <!-- Dropdown -->
                        <div class="dropdown">
                            <button class="btn btn-action-dots" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                ⋮
                            </button>
                           <ul class="dropdown-menu dropdown-menu-end">
                                <li><a href="{{ route('ip_records.show', $record->id) }}" class="dropdown-item">View</a></li>
                                <li><a class="dropdown-item" href="{{ route('ip_records.transaction', $record->id) }}">View Transaction</a></li>
                                <li>
                                <button class="dropdown-item text-danger" data-bs-toggle="modal" data-bs-target="#archiveModal{{ $record->id }}">
                                    Archive
                                </button>
                            </li>
                        </ul>
                        </div>

                        <!-- Archive Modal -->
                        <div class="modal fade" id="archiveModal{{ $record->id }}" tabindex="-1" aria-labelledby="archiveModalLabel{{ $record->id }}" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content shadow">
                                    <div class="modal-header bg-danger text-white">
                                        <h5 class="modal-title" id="archiveModalLabel{{ $record->id }}">
                                            <i class="fas fa-exclamation-triangle me-1"></i> Confirm Archive
                                        </h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Are you sure you want to move <strong>{{ $record->first_name }} {{ $record->last_name }}</strong> to the archive?
                                        <br>
                                        <small class="text-muted">This action won't delete the record permanently. It can be restored later.</small>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                                        <form action="{{ route('ip_records.destroy', $record->id) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-sm">Yes, Archive</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="text-center">No records found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

        <div class="pagination mt-3">
            {{ $records->appends(request()->query())->links('pagination::bootstrap-4') }}
        </div>
        

</div>
@endsection
