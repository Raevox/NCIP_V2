<!DOCTYPE html>
<html>
<head>
    <title>Account Approved</title>
</head>
<body>
    <h2>Hello {{ $applicant->first_name }} {{ $applicant->last_name }},</h2>
    <p>Your NCIP account has been approved.</p>
    <p>You can now log in to the system using your registered email address: <strong>{{ $applicant->email }}</strong></p>
    
    <p><strong>Account Details:</strong></p>
    <ul>
        <li>Name: {{ $applicant->first_name }} {{ $applicant->last_name }}</li>
        <li>Email: {{ $applicant->email }}</li>
        <li>Tribe: {{ $applicant->tribe }}</li>
        <li>Contact: {{ $applicant->contact }}</li>
        <li>Address: {{ $applicant->address }}</li>
    </ul>
    
    <br>
    <p>Thank you,<br>NCIP Administration</p>
</body>
</html>