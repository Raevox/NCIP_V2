<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Forgot Password - NCIP</title>
  <link rel="stylesheet" href="{{ asset('css/login.css') }}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
  <div class="page-background">
    <div class="login-card">

      <!-- LEFT PANEL -->
      <div class="left-panel">
        <img src="{{ asset('images/ncipbg.png') }}" alt="Background" class="background-image" />
      </div>

      <!-- RIGHT PANEL -->
      <div class="right-panel">
        <img src="{{ asset('images/ncip logo.png') }}" alt="NCIP Logo" class="logo">
        <h2>FORGOT PASSWORD</h2>
        <p class="subtitle">Enter your email and we’ll send you a reset link.</p>

        <!-- SUCCESS MESSAGE -->
        @if (session('status'))
          <div class="success">
            {{ session('status') }}
          </div>
        @endif

        <!-- FORM -->
        <form method="POST" action="{{ route('password.email') }}" class="login-form">
          @csrf

          <!-- EMAIL INPUT -->
          <div class="input-group">
            <input type="email" name="email" placeholder="Email" value="{{ old('email') }}" required autofocus />
            <span class="icon"><i class="fas fa-envelope"></i></span>
          </div>

          <!-- ERROR MESSAGES -->
          @if ($errors->any())
            <div class="error">
              @foreach ($errors->all() as $error)
                <p>{{ $error }}</p>
              @endforeach
            </div>
          @endif

          <!-- SUBMIT BUTTON -->
          <button type="submit">Send Reset Link</button>

          <!-- BACK TO LOGIN LINK -->
          <p class="signup-text">
            Remembered your password? 
            <a href="{{ route('login') }}">Login here</a>
          </p>
        </form>
      </div>
    </div>
  </div>
</body>
</html>
