<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>NCIP Login</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Inter', sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .page-background {
      width: 100%;
      max-width: 1200px;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .login-card {
      display: flex;
      background: white;
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      width: 100%;
      max-width: 900px;
    }

    .left-panel {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 40px;
      min-height: 400px;
    }

    .background-image {
      max-width: 100%;
      height: auto;
      object-fit: contain;
    }

    .right-panel {
      flex: 1;
      padding: 40px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }

    .logo {
      width: 80px;
      height: auto;
      margin-bottom: 20px;
    }

    .right-panel h2 {
      text-align: center;
      color: #333;
      font-size: 18px;
      font-weight: 600;
      margin-bottom: 30px;
      line-height: 1.4;
    }

    .login-form {
      width: 100%;
      max-width: 350px;
    }

    .input-group {
      position: relative;
      margin-bottom: 20px;
    }

    .input-group input {
      width: 100%;
      padding: 14px 45px 14px 15px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 15px;
      transition: border-color 0.3s;
      font-family: 'Inter', sans-serif;
    }

    .input-group input:focus {
      outline: none;
    }

    .input-group .icon {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: #999;
      cursor: pointer;
    }

    .error {
      background: #fee;
      color: #c33;
      padding: 12px;
      border-radius: 8px;
      margin-bottom: 15px;
      font-size: 14px;
    }

    .remember-me {
      margin-bottom: 15px;
    }

    .remember-me label {
      display: flex;
      align-items: center;
      font-size: 14px;
      color: #666;
      cursor: pointer;
    }

    .remember-me input[type="checkbox"] {
      margin-right: 8px;
      cursor: pointer;
    }

    .forgot {
      display: inline-block;
      text-decoration: none;
      font-size: 14px;
      margin-bottom: 25px;
    }

    .forgot:hover {
      text-decoration: underline;
    }

    button[type="submit"] {
      width: 100%;
      padding: 14px;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.2s, box-shadow 0.2s;
      font-family: 'Inter', sans-serif;
    }

    button[type="submit"]:hover {
      transform: translateY(-2px);
    }

    .signup-text {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
      color: #666;
    }

    .signup-text a {
      text-decoration: none;
      font-weight: 600;
    }

    .signup-text a:hover {
      text-decoration: underline;
    }

    /* Mobile Responsive */
    @media (max-width: 768px) {
      body {
        padding: 15px;
      }

      .login-card {
        flex-direction: column;
        max-width: 100%;
      }

      .left-panel {
        min-height: 200px;
        padding: 30px;
      }

      .right-panel {
        padding: 30px 25px;
      }

      .right-panel h2 {
        font-size: 16px;
        margin-bottom: 25px;
      }

      .logo {
        width: 70px;
        margin-bottom: 15px;
      }

      .login-form {
        max-width: 100%;
      }
    }

    @media (max-width: 480px) {
      .left-panel {
        min-height: 150px;
        padding: 20px;
      }

      .right-panel {
        padding: 25px 20px;
      }

      .right-panel h2 {
        font-size: 14px;
        margin-bottom: 20px;
      }

      .logo {
        width: 60px;
      }

      .input-group input {
        padding: 12px 40px 12px 12px;
        font-size: 14px;
      }

      button[type="submit"] {
        padding: 12px;
        font-size: 15px;
      }
    }
  </style>
</head>
<body>
  <div class="page-background">
    <div class="login-card">

      <!-- LEFT PANEL -->
      <div class="left-panel">
        <img src="{{ asset('images/ncipbg.png') }}" alt="Background" class="background-image" />
      </div>

      <!-- RIGHT PANEL -->
      <div class="right-panel">
        <img src="{{ asset('images/ncip logo.png') }}" alt="NCIP Logo" class="logo">
        <h2>NATIONAL COMMISSION ON<br/>INDIGENOUS PEOPLE</h2>

        <form method="POST" action="{{ route('login') }}" class="login-form">
          @csrf

          <!-- EMAIL INPUT -->
          <div class="input-group">
            <input type="email" name="email" placeholder="Email" value="{{ old('email') }}" required autofocus />
            <span class="icon"><i class="fas fa-envelope"></i></span>
          </div>

          <!-- PASSWORD INPUT -->
          <div class="input-group">
            <input type="password" name="password" id="password" placeholder="Password" required />
            <span class="icon" onclick="togglePassword()">
              <i id="eye-icon" class="fas fa-eye"></i>
            </span>
          </div>

          <!-- ERROR MESSAGES -->
          @if ($errors->any())
            <div class="error">
              @foreach ($errors->all() as $error)
                <p>{{ $error }}</p>
              @endforeach
            </div>
          @endif

          <!-- REMEMBER ME -->
          <div class="remember-me">
            <label>
              <input type="checkbox" name="remember" /> Remember me
            </label>
          </div>

          <!-- FORGOT PASSWORD LINK -->
          <a href="{{ route('password.request') }}" class="forgot">Forgot password?</a>

          <!-- LOGIN BUTTON -->
          <button type="submit">Login</button>

          <!-- SIGN UP LINK -->
          <p class="signup-text">
            Don't have an account? 
            <a href="{{ route('register') }}">Sign Up</a>
          </p>
        </form>
      </div>
    </div>
  </div>

  <!-- Password Toggle Script -->
  <script>
    function togglePassword() {
      const passwordInput = document.getElementById('password');
      const eyeIcon = document.getElementById('eye-icon');
      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.remove("fa-eye");
        eyeIcon.classList.add("fa-eye-slash");
      } else {
        passwordInput.type = "password";
        eyeIcon.classList.remove("fa-eye-slash");
        eyeIcon.classList.add("fa-eye");
      }
    }
  </script>
</body>
</html>