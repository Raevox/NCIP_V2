<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no"/>
  <title>NCIP Sign Up</title>
  <link rel="stylesheet" href="{{ asset('css/register.css') }}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>
  <div class="page-background">
    <div class="signup-card">

      <!-- LEFT PANEL -->
      <div class="left-panel">
        <img src="{{ asset('images/ncip logo.png') }}" alt="NCIP Logo" class="logo-image" />
      </div>

      <!-- RIGHT PANEL -->
      <div class="right-panel">
        <h2>Create Your Account</h2>

        <!-- Flash Messages -->
        @if(session('success'))
          <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if(session('error'))
          <div class="alert alert-danger">{{ session('error') }}</div>
        @endif
        @if ($errors->any())
          <div class="alert alert-danger">
            <ul class="mb-0">
              @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
              @endforeach
            </ul>
          </div>
        @endif

        <form method="POST" action="{{ route('register') }}" class="signup-form" enctype="multipart/form-data">
          @csrf

          <!-- First and Last name -->
          <div class="row">
            <div class="form-group">
              <label for="first_name">First Name</label>
              <input type="text" id="first_name" name="first_name" placeholder="Enter your first name" value="{{ old('first_name') }}" required>
            </div>
            <div class="form-group">
              <label for="last_name">Last Name</label>
              <input type="text" id="last_name" name="last_name" placeholder="Enter your last name" value="{{ old('last_name') }}" required>
            </div>
          </div>

          <!-- Email -->
          <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" placeholder="Enter your email address" value="{{ old('email') }}" required>
          </div>

          <!-- Province / Municipality / Barangay -->
          <div class="row triple">
            <div class="form-group">
              <label for="province_code">Province</label>
              <select id="province_code" name="province_code" required>
                <option disabled selected>Select Province</option>
              </select>
              <input type="hidden" name="province_name" id="province_name" value="{{ old('province_name') }}">
            </div>
            <div class="form-group">
              <label for="municipality_code">Municipality</label>
              <select id="municipality_code" name="municipality_code" required disabled>
                <option disabled selected>Select Municipality</option>
              </select>
              <input type="hidden" name="municipality_name" id="municipality_name" value="{{ old('municipality_name') }}">
            </div>
            <div class="form-group">
              <label for="barangay_code">Barangay</label>
              <select id="barangay_code" name="barangay_code" required disabled>
                <option disabled selected>Select Barangay</option>
              </select>
              <input type="hidden" name="barangay_name" id="barangay_name" value="{{ old('barangay_name') }}">
            </div>
          </div>

          <!-- Tribe & Contact -->
          <div class="row">
            <div class="form-group">
              <label for="tribe">Indigenous Group/Tribe</label>
              <input type="text" id="tribe" name="tribe" placeholder="Enter your IP group" value="{{ old('tribe') }}" required>
            </div>
            <div class="form-group">
              <label for="contact">Phone Number</label>
              <input type="tel" id="contact" name="contact" placeholder="Enter your phone number" value="{{ old('contact') }}" required>
            </div>
          </div>

          <!-- Leader -->
          <div class="form-group">
            <label for="leader">Elder/Chieftain/Leader</label>
            <input type="text" id="leader" name="leader" placeholder="Enter your Elder/Chieftain/Leader name" value="{{ old('leader') }}" required>
          </div>

          <!-- Password -->
          <div class="row">
            <div class="form-group">
              <label for="password">Password</label>
              <div class="password-wrapper">
                <input type="password" id="password" name="password" placeholder="Create a strong password" required>
              </div>
            </div>
            <div class="form-group">
              <label for="password_confirmation">Confirm Password</label>
              <div class="password-wrapper">
                <input type="password" id="password_confirmation" name="password_confirmation" placeholder="Confirm your password" required>
              </div>
            </div>
          </div>

          <!-- Birth Certificate Upload -->
          <div class="form-group">
            <label for="birth_certificate">Upload Birth Certificate</label>
            <input type="file" id="birth_certificate" name="birth_certificate" accept=".jpg,.jpeg,.png,.pdf" required>
            <p id="file-preview"></p>
          </div>

          <!-- Submit Button -->
          <button type="submit">Create Account</button>

          <!-- Link to Login -->
          <p class="login-text">
            Already have an account? <a href="{{ route('login') }}">Sign in here</a>
          </p>
        </form>
      </div>
    </div>
  </div>

  <!-- Approval Modal -->
  <div id="approvalModal">
    <div class="modal-overlay"></div>
    <div class="modal-content">
      <h3>Account Pending Approval</h3>
      <p>Your registration has been submitted successfully. Your account is now pending approval from the administrator.</p>
      <p>You will receive an email notification once your account has been approved.</p>
      <button type="button" id="closeModal">Got it, thanks!</button>
    </div>
  </div>

  <!-- JavaScript -->
  <script>
    // Password toggle functionality
    function togglePassword(fieldId) {
      const passwordField = document.getElementById(fieldId);
      const toggleButton = passwordField.nextElementSibling;
      
      if (passwordField.type === 'password') {
        passwordField.type = 'text';
        toggleButton.textContent = '🙈';
      } else {
        passwordField.type = 'password';
        toggleButton.textContent = '👁';
      }
    }

    document.addEventListener('DOMContentLoaded', async () => {
      const provinceSelect = document.getElementById('province_code');
      const municipalitySelect = document.getElementById('municipality_code');
      const barangaySelect = document.getElementById('barangay_code');
      const fileInput = document.getElementById('birth_certificate');
      const filePreview = document.getElementById('file-preview');

      // Loading states
      const showLoading = (element, text = 'Loading...') => {
        element.innerHTML = `<option disabled selected>${text}</option>`;
        element.disabled = true;
      };

      const hideLoading = (element, defaultText) => {
        element.innerHTML = `<option disabled selected>${defaultText}</option>`;
        element.disabled = false;
      };

      try {
        // Load locations JSON with error handling
        showLoading(provinceSelect, 'Loading provinces...');
        
        const [provincesResponse, municipalitiesResponse, barangaysResponse] = await Promise.all([
          fetch('/data/provinces.json'),
          fetch('/data/mun.json'),
          fetch('/data/brgy.json')
        ]);

        if (!provincesResponse.ok || !municipalitiesResponse.ok || !barangaysResponse.ok) {
          throw new Error('Failed to load location data');
        }

        const provinces = (await provincesResponse.json()).RECORDS;
        const municipalitiesData = (await municipalitiesResponse.json()).RECORDS;
        const barangaysData = (await barangaysResponse.json()).RECORDS;

        // Populate provinces
        hideLoading(provinceSelect, 'Select Province');
        provinces.forEach(p => {
          const option = document.createElement('option');
          option.value = p.provCode;
          option.textContent = p.provDesc;
          provinceSelect.appendChild(option);
        });

        // Province change handler
        provinceSelect.addEventListener('change', function() {
          const selectedProvCode = this.value;
          const selectedProvName = this.options[this.selectedIndex].text;
          
          document.getElementById('province_name').value = selectedProvName;
          
          showLoading(municipalitySelect, 'Loading municipalities...');
          barangaySelect.innerHTML = '<option disabled selected>Select Barangay</option>';
          barangaySelect.disabled = true;
          
          setTimeout(() => {
            hideLoading(municipalitySelect, 'Select Municipality');
            const municipalities = municipalitiesData.filter(m => m.provCode === selectedProvCode);
            
            municipalities.forEach(m => {
              const option = document.createElement('option');
              option.value = m.citymunCode;
              option.textContent = m.citymunDesc;
              municipalitySelect.appendChild(option);
            });
          }, 300);
        });

        // Municipality change handler
        municipalitySelect.addEventListener('change', function() {
          const selectedMunCode = this.value;
          const selectedMunName = this.options[this.selectedIndex].text;
          
          document.getElementById('municipality_name').value = selectedMunName;
          
          showLoading(barangaySelect, 'Loading barangays...');
          
          setTimeout(() => {
            hideLoading(barangaySelect, 'Select Barangay');
            const barangays = barangaysData.filter(b => b.citymunCode === selectedMunCode);
            
            barangays.forEach(b => {
              const option = document.createElement('option');
              option.value = b.brgyCode;
              option.textContent = b.brgyDesc;
              barangaySelect.appendChild(option);
            });
          }, 300);
        });

        // Barangay change handler
        barangaySelect.addEventListener('change', function() {
          const selectedBrgyName = this.options[this.selectedIndex].text;
          document.getElementById('barangay_name').value = selectedBrgyName;
        });

      } catch (error) {
        console.error('Error loading location data:', error);
        provinceSelect.innerHTML = '<option disabled selected>Error loading provinces</option>';
        
        // Show user-friendly error message
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-danger';
        errorDiv.textContent = 'Unable to load location data. Please refresh the page and try again.';
        document.querySelector('.signup-form').insertBefore(errorDiv, document.querySelector('.signup-form').firstChild);
      }

      // File preview with validation
      fileInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
          const fileSize = (file.size / 1024 / 1024).toFixed(2); // MB
          const maxSize = 5; // 5MB limit
          
          if (fileSize > maxSize) {
            filePreview.textContent = `File too large (${fileSize}MB). Maximum size is ${maxSize}MB.`;
            filePreview.style.color = '#dc2626';
            this.value = '';
          } else {
            filePreview.textContent = `Selected: ${file.name} (${fileSize}MB)`;
            filePreview.style.color = '#059669';
          }
        } else {
          filePreview.textContent = '';
        }
      });

      // Form submission with modal
      const form = document.querySelector('.signup-form');
      const modal = document.getElementById('approvalModal');
      const closeBtn = document.getElementById('closeModal');

      form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Basic client-side validation
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('password_confirmation').value;
        
        if (password !== confirmPassword) {
          alert('Passwords do not match. Please try again.');
          return;
        }
        
        if (password.length < 8) {
          alert('Password must be at least 8 characters long.');
          return;
        }

        // Show the modal
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden'; // Prevent background scrolling
      });

      // Close modal and submit form
      closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
        form.submit();
      });

      // Close modal when clicking overlay
      modal.querySelector('.modal-overlay').addEventListener('click', function() {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
      });
    });

    // Prevent form resubmission on page refresh
    if (window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }
  </script>
</body>
</html>