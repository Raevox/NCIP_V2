@extends('layouts.staff')

@section('title', 'Profile')

@section('content')
<div class="container mt-4">

    <!-- Profile Header -->
    <div class="card shadow-lg border-0 rounded-3 mb-4">
        <div class="card-body d-flex flex-column flex-sm-row align-items-center text-center text-sm-start">
            <img src="{{ Auth::user()->profile_picture ? asset('storage/' . Auth::user()->profile_picture) : asset('assets/images/default.png') }}"
                 class="rounded-circle me-sm-3 mb-3 mb-sm-0 border"
                 width="70" height="70" alt="Profile Picture">

            <div>
                <h5 class="mb-1">{{ Auth::user()->name }}</h5>
                <small class="text-muted d-block">{{ ucfirst(Auth::user()->role) }} (Committee)</small>
                <div>
                    <span class="badge bg-success mt-2">{{ ucfirst(Auth::user()->status) }}</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Profile Info -->
    <div class="card shadow-sm p-4">
        <h6 class="fw-bold mb-3">Personal Information</h6>
        <div class="row gy-3">
            <div class="col-12 col-md-4">
                <small class="text-muted">Email</small>
                <div>{{ Auth::user()->email }}</div>
            </div>
            <div class="col-12 col-md-4">
                <small class="text-muted">Phone</small>
                <div>{{ Auth::user()->contact ?? 'N/A' }}</div>
            </div>
            <div class="col-12 col-md-4">
                <small class="text-muted">Address</small>
                <div>{{ Auth::user()->address ?? 'N/A' }}</div>
            </div>
        </div>
    </div>
</div>
@endsection
