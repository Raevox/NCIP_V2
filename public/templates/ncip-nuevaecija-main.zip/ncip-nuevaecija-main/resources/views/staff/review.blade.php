@extends('layouts.staff')

@section('title', 'Review Applications')

@section('content')
<div class="container mt-3">

    <!-- Search -->
    <div class="mb-3">
        <input type="text" class="form-control" placeholder="Search applications...">
    </div>
<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <ul class="nav nav-tabs mb-3">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#underReview">
                    Under Review <span class="badge bg-warning">{{ $underReview->count() }}</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#approved">
                    Approved <span class="badge bg-success">{{ $approved->count() }}</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#returned">
                    Returned <span class="badge bg-danger">{{ $returned->count() }}</span>
                </a>
            </li>
        </ul>


    <div class="tab-content">
        <!-- Under Review -->
        <div id="underReview" class="tab-pane fade show active">
            <div class="card shadow-sm p-3">
                @if($underReview->isEmpty())
                    <p class="text-muted">No applications under review.</p>
                @else
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Remarks</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($underReview as $app)
                                <tr>
                                    <td>{{ $app->user->full_name ?? 'N/A' }}</td>
                                    <td>{{ $app->created_at->format('M d, Y') }}</td>
                                    <td><span class="badge bg-warning">Under Review</span></td>
                                    <td>{{ $app->remarks ?? '-' }}</td>
                                    <td>
                                        <a href="{{ route('staff.review.show', $app->id) }}" class="btn btn-sm btn-dark">View</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>

        <!-- Approved -->
        <div id="approved" class="tab-pane fade">
            <div class="card shadow-sm p-3">
                @if($approved->isEmpty())
                    <p class="text-muted">No approved applications yet.</p>
                @else
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Remarks</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($approved as $app)
                                <tr>
                                    <td>{{ $app->user->full_name ?? 'N/A' }}</td>
                                    <td>{{ $app->created_at->format('M d, Y') }}</td>
                                    <td><span class="badge bg-success">Approved</span></td>
                                    <td>{{ $app->remarks ?? '-' }}</td>
                                    <td>
                                        <a href="{{ route('staff.review.show', $app->id) }}" class="btn btn-sm btn-dark">View</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>

        <!-- Returned -->
        <div id="returned" class="tab-pane fade">
            <div class="card shadow-sm p-3">
                @if($returned->isEmpty())
                    <p class="text-muted">No returned applications yet.</p>
                @else
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Remarks</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($returned as $app)
                                <tr>
                                    <td>{{ $app->user->full_name ?? 'N/A' }}</td>
                                    <td>{{ $app->created_at->format('M d, Y') }}</td>
                                    <td><span class="badge bg-danger">Returned</span></td>
                                    <td>{{ $app->remarks ?? '-' }}</td>
                                    <td>
                                        <a href="{{ route('staff.review.show', $app->id) }}" class="btn btn-sm btn-dark">View</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
