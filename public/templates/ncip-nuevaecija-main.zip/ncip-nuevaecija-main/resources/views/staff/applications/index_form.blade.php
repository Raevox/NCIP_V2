<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCIP Certification Form</title>
    <style>
        body { font-family: Arial, Helvetica, sans-serif; font-size:13px; background:#f5f5f5; padding:20px; }
        .form-box { border:1px solid #000; padding:20px; max-width:1000px; margin:auto; background:#fff; border-radius:6px; }
        .form-header {
    position: relative;
    display: flex;
    align-items: center;
}
        .header-left {
    flex: 0 0 100px;      
    text-align: center;
    margin-right: 10px;    
}
        .header-left img { max-width:90px; margin-bottom:5px; }
        .header-left p { font-size:12px; font-weight:bold; margin:2px 0; }
        
.header-center {
    text-align: center;
    flex: 1;
    position: relative;
    left: -55px; 
}

        .header-center p { margin:2px 0; }
        .header-center b { font-size:14px; }
        .location-line { margin-top:8px; font-size:13px; line-height:1.6; }
        .location-line span { display:inline-block; border-bottom:1px solid #000; min-width:150px; }
        h2,h3 { margin:12px 0; font-size:16px; text-decoration:underline; }
        .title-form h2 { text-align:center; }
        .purpose-box { border:1px solid #000; padding:12px; margin-top:10px; }
        .purpose-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:5px 15px; }
        .purpose-grid label { display:flex; align-items:center; gap:5px; }
        .purpose-grid input[type="checkbox"] {accent-color: #0d6efd; width: 16px; height: 16px;}
        .grid-2, .grid-3 { display:grid; gap:10px 15px; margin-bottom:12px; }
        .grid-2 { grid-template-columns:repeat(2,1fr); }
        .grid-3 { grid-template-columns:repeat(3,1fr); }
        .grid-2 div, .grid-3 div { display:flex; flex-direction:column; }
        .grid-2 label, .grid-3 label { font-weight:bold; font-size:13px; margin-bottom:3px; }
        .grid-2 input, .grid-3 input, .grid-2 select, .grid-3 select { padding:5px 8px; border:1px solid #000; border-radius:3px; font-size:13px; }
        table { width:100%; border-collapse:collapse; margin-top:10px; font-size:13px; }
        table, th, td { border:1px solid #000; }
        th, td { padding:6px; text-align:left; }
        .land-section { margin-top:15px; font-size:13px; }
        .land-section p { margin:5px 0; }
        .underline { display:inline-block; border-bottom:1px solid #000; min-width:150px; }
        .pledge { border:1px solid #000; padding:12px; margin-top:15px; line-height:1.5; }
        .pledge p { margin-bottom:8px; text-align:justify; }
        .signature { margin-top:30px; text-align:right; }
        .signature p { margin:5px 0; }
    </style>
</head>
<body>
<div class="form-box">
    <!-- HEADER -->
    <div class="form-header">
        <div class="header-left">
            <img src="{{ asset('images/ncip_logo.jpg') }}" alt="NCIP Logo" />
            <p>REGION 3</p>
            <p>CENTRAL LUZON</p>
        </div>
        <div class="header-center">
            <p>Republic of the Philippines</p>
            <p>OFFICE OF THE PRESIDENT</p>
            <p><b>NATIONAL COMMISSION ON INDIGENOUS PEOPLES</b></p>
            <div class="location-line">
                Province of <span>{{ $step1['province_name'] ?? '' }}</span><br>
                AD/Municipality <span>{{ $step1['municipality_name'] ?? '' }}</span><br>
                AD/Barangay of <span>{{ $step1['barangay_name'] ?? '' }}</span>
            </div>
        </div>
    </div>

    <!-- TITLE -->
    <div class="title-form"><h2>INFORMATION INDEX</h2></div>

    <!-- PURPOSE -->
    <div class="purpose-box">
        <h3>Purpose: (Check only 1 box)</h3>
        <div class="purpose-grid">
            @php
                $purposes = [
                    'Scholarship (SCH)','Local Employment (LE)','Land Matter (LM)','Civil Service Commission (CSC)',
                    'NAPOLCOM Requirement (PNP)','BJMP: Age Waiver (AW)','BuCor: Age Waiver (AW)','BFP: Age Waiver (AW)',
                    'AFP: Age Waiver (AW)','IPMR (IPMR)','Cert. of Tribal Marriage (CTM)','Travel Abroad (TA)'
                ];
                $selectedPurposes = $step1['purpose'] ?? [];
            @endphp
            @foreach($purposes as $index => $p)
                <label><input type="checkbox" {{ in_array($p, $selectedPurposes) ? 'checked' : '' }} disabled> {{ $index+1 }}. {{ $p }}</label>
            @endforeach
            <label>Others: <input type="text" value="{{ $step1['purpose_others'] ?? '' }}" readonly></label>
        </div>
    </div>

    <!-- PERSONAL INFO -->
    <h2>I. Personal Information</h2>
    <div class="grid-2">
        <div><label>First Name</label><input type="text" value="{{ $step1['first_name'] ?? '' }}" readonly></div>
        <div><label>Last Name</label><input type="text" value="{{ $step1['last_name'] ?? '' }}" readonly></div>
    </div>
    <div class="grid-3">
        <div><label>Sex</label><input type="text" value="{{ $step1['sex'] ?? '' }}" readonly></div>
        <div><label>Civil Status</label><input type="text" value="{{ $step1['civil_status'] ?? '' }}" readonly></div>
        <div><label>Place Origin</label><input type="text" value="{{ $step1['place_origin'] ?? '' }}" readonly></div>
    </div>

    <!-- SPOUSE -->
    <div class="spouse-section">
        <p>If married, provide the name of your spouse. If not married, indicate N/A.</p>
        <div class="grid-2">
            <div><label>First Name</label><input type="text" value="{{ $step1['spouse_first_name'] ?? 'N/A' }}" readonly></div>
            <div><label>Last Name</label><input type="text" value="{{ $step1['spouse_last_name'] ?? 'N/A' }}" readonly></div>
        </div>
    </div>

    <!-- EDUCATIONAL -->
    <h3>II. Educational Background</h3>
    <div class="grid-2">
        <div><label>Highest Educational Attainment</label><input type="text" value="{{ $step2['educational_attainment'] ?? '' }}" readonly></div>
        <div><label>Degree Obtained</label><input type="text" value="{{ $step2['degree_obtained'] ?? '' }}" readonly></div>
    </div>

    <!-- PARENTAL -->
    <h3>III. Parental Background</h3>
    <table>
        <thead>
            <tr><th>Details</th><th>Father</th><th>Mother(Maiden name)</th></tr>
        </thead>
        <tbody>
            <tr><td>Name</td><td>{{ $step2['father_name'] ?? '' }}</td><td>{{ $step2['mother_name'] ?? '' }}</td></tr>
            <tr><td>IP Group</td><td>{{ $step2['father_ipgroup'] ?? '' }}</td><td>{{ $step2['mother_ipgroup'] ?? '' }}</td></tr>
            <tr><td>Place Origin</td><td>{{ $step2['father_origin'] ?? '' }}</td><td>{{ $step2['mother_origin'] ?? '' }}</td></tr>
            <tr><td>Grandfather</td><td>{{ ($step2['paternal_grandfather_first_name'] ?? '') . ' ' . ($step2['paternal_grandfather_last_name'] ?? '') }}</td><td>{{ ($step2['maternal_grandfather_first_name'] ?? '') . ' ' . ($step2['maternal_grandfather_last_name'] ?? '') }}</td></tr>
            <tr><td>IP Group</td><td>{{ $step2['paternal_grandfather_ipgroup'] ?? '' }}</td><td>{{ $step2['maternal_grandfather_ipgroup'] ?? '' }}</td></tr>
            <tr><td>Place Origin</td><td>{{ $step2['paternal_grandfather_origin'] ?? '' }}</td><td>{{ $step2['maternal_grandfather_origin'] ?? '' }}</td></tr>
            <tr><td>Grandmother</td><td>{{ ($step2['paternal_grandmother_first_name'] ?? '') . ' ' . ($step2['paternal_grandmother_last_name'] ?? '') }}</td><td>{{ ($step2['maternal_grandmother_first_name'] ?? '') . ' ' . ($step2['maternal_grandmother_last_name'] ?? '') }}</td></tr>
            <tr><td>IP Group</td><td>{{ $step2['paternal_grandmother_ipgroup'] ?? '' }}</td><td>{{ $step2['maternal_grandmother_ipgroup'] ?? '' }}</td></tr>
            <tr><td>Place Origin</td><td>{{ $step2['paternal_grandmother_origin'] ?? '' }}</td><td>{{ $step2['maternal_grandmother_origin'] ?? '' }}</td></tr>
        </tbody>
    </table>

    <!-- LAND MATTER -->
    <div class="land-section">
        <label><input type="checkbox" disabled> If Purpose is Land Matter fill up the following:</label>
        <p>Homestead/Free Patent No. <span class="underline">{{ $step2['homestead_no'] ?? '' }}</span> Lot No. <span class="underline">{{ $step2['lot_no'] ?? '' }}</span></p>
        <p>Date of Issuance <span class="underline">{{ $step2['issuance_date'] ?? '' }}</span> Area <span class="underline">{{ $step2['area'] ?? '' }}</span></p>
        <p>Location <span class="underline" style="min-width:300px">{{ $step2['location'] ?? '' }}</span></p>
    </div>

    <!-- PLEDGE -->
    <h3>III. Applicant Pledge</h3>
    <div class="pledge">
        <p>I, {{ $step2['applicant_name'] ?? $application->user->first_name ?? '' }}, do solemnly swear that all data given in the above information are true and correct to the best of my knowledge and based on authentic records.</p>
        <p>I understand that any false information is enough to cause the denial of my application and could subject me to CRIMINAL and/or ADMINISTRATIVE prosecution.</p>
    </div>

    <!-- SIGNATURE -->
    <div class="signature">
        <p>__________________________</p>
        <p><b>Signature of Applicant</b></p>
    </div>
</div>
</body>
</html>
