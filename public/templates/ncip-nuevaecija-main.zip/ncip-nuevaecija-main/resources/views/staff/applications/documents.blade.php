<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="{{ asset('css/staff.css') }}">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="wrapper">
        @yield('content')
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<div class="documents-preview">
    <h5 class="mb-3"><i class="fas fa-file-alt me-2"></i>Uploaded Documents</h5>
    
    <div class="documents-list">
        {{-- Applicant Photo --}}
        <div class="doc-item mb-3 p-3 border rounded">
            <span class="doc-label fw-bold">Applicant Photo:</span>
            @if(!empty($application->applicant_picture))
                <a href="{{ asset('storage/'.$application->applicant_picture) }}" target="_blank" class="view-btn btn btn-outline-primary btn-sm ms-2">
                    <i class="fas fa-eye me-1"></i>View
                </a>
                <a href="{{ asset('storage/'.$application->applicant_picture) }}" download class="btn btn-outline-success btn-sm ms-1">
                    <i class="fas fa-download me-1"></i>Download
                </a>
            @else
                <span class="text-muted ms-2"><i class="fas fa-times-circle text-danger me-1"></i>No applicant photo uploaded</span>
            @endif
        </div>

        {{-- Birth Certificate --}}
        <div class="doc-item mb-3 p-3 border rounded">
            <span class="doc-label fw-bold">Birth Certificate:</span>
            @if($ipAccount && !empty($ipAccount->document_path))
                <a href="{{ asset('storage/' . $ipAccount->document_path) }}" target="_blank" class="view-btn btn btn-outline-primary btn-sm ms-2">
                    <i class="fas fa-eye me-1"></i>View
                </a>
                <a href="{{ asset('storage/' . $ipAccount->document_path) }}" download class="btn btn-outline-success btn-sm ms-1">
                    <i class="fas fa-download me-1"></i>Download
                </a>
            @else
                <span class="text-muted ms-2"><i class="fas fa-times-circle text-danger me-1"></i>No birth certificate uploaded</span>
            @endif
        </div>

        {{-- Signature --}}
        <div class="doc-item mb-3 p-3 border rounded">
            <span class="doc-label fw-bold">Applicant Signature:</span>
            @if(!empty($application->signature))
                <a href="{{ asset('storage/'.$application->signature) }}" target="_blank" class="view-btn btn btn-outline-primary btn-sm ms-2">
                    <i class="fas fa-eye me-1"></i>View
                </a>
                <a href="{{ asset('storage/'.$application->signature) }}" download class="btn btn-outline-success btn-sm ms-1">
                    <i class="fas fa-download me-1"></i>Download
                </a>
            @else
                <span class="text-muted ms-2"><i class="fas fa-times-circle text-danger me-1"></i>No signature uploaded</span>
            @endif
        </div>

        {{-- Tribal Certificate --}}
        <div class="doc-item mb-3 p-3 border rounded">
            <span class="doc-label fw-bold">Certificate of Tribal Chieftain:</span>
            @if(!empty($application->tribal_certificate))
                <a href="{{ asset('storage/'.$application->tribal_certificate) }}" target="_blank" class="view-btn btn btn-outline-primary btn-sm ms-2">
                    <i class="fas fa-eye me-1"></i>View
                </a>
                <a href="{{ asset('storage/'.$application->tribal_certificate) }}" download class="btn btn-outline-success btn-sm ms-1">
                    <i class="fas fa-download me-1"></i>Download
                </a>
            @else
                <span class="text-muted ms-2"><i class="fas fa-times-circle text-danger me-1"></i>No certificate uploaded</span>
            @endif
        </div>

        {{-- Genealogy Form --}}
        <div class="doc-item mb-3 p-3 border rounded">
            <span class="doc-label fw-bold">Completed Genealogy Form:</span>
            @if(!empty($application->genealogy_form))
                <a href="{{ asset('storage/'.$application->genealogy_form) }}" target="_blank" class="view-btn btn btn-outline-primary btn-sm ms-2">
                    <i class="fas fa-eye me-1"></i>View
                </a>
                <a href="{{ asset('storage/'.$application->genealogy_form) }}" download class="btn btn-outline-success btn-sm ms-1">
                    <i class="fas fa-download me-1"></i>Download
                </a>
                
                {{-- File info badge --}}
                @php
                    $fileExtension = pathinfo($application->genealogy_form, PATHINFO_EXTENSION);
                    $fileType = strtoupper($fileExtension);
                @endphp
                <span class="badge bg-info ms-2">{{ $fileType }} File</span>
            @else
                <span class="text-muted ms-2"><i class="fas fa-times-circle text-danger me-1"></i>No genealogy form uploaded</span>
            @endif
        </div>
    </div>

    {{-- Document Status Summary --}}
    @if(isset($application) && in_array($application->status, ['Under Review', 'Returned']))
    <div class="document-status mt-4 p-3 border rounded bg-light">
        <h6 class="fw-bold mb-3"><i class="fas fa-clipboard-check me-2"></i>Document Status</h6>
        
        <div class="row">
            <div class="col-md-6">
                <div class="status-item mb-2">
                    <span class="fw-medium">Applicant Photo:</span>
                    <span class="badge {{ !empty($application->applicant_picture) ? 'bg-success' : 'bg-warning' }} ms-2">
                        {{ !empty($application->applicant_picture) ? 'Uploaded' : 'Missing' }}
                    </span>
                </div>
                <div class="status-item mb-2">
                    <span class="fw-medium">Birth Certificate:</span>
                    <span class="badge {{ ($ipAccount && !empty($ipAccount->document_path)) ? 'bg-success' : 'bg-warning' }} ms-2">
                        {{ ($ipAccount && !empty($ipAccount->document_path)) ? 'Uploaded' : 'Missing' }}
                    </span>
                </div>
            </div>
            <div class="col-md-6">
                <div class="status-item mb-2">
                    <span class="fw-medium">Signature:</span>
                    <span class="badge {{ !empty($application->signature) ? 'bg-success' : 'bg-warning' }} ms-2">
                        {{ !empty($application->signature) ? 'Uploaded' : 'Missing' }}
                    </span>
                </div>
                <div class="status-item mb-2">
                    <span class="fw-medium">Tribal Certificate:</span>
                    <span class="badge {{ !empty($application->tribal_certificate) ? 'bg-success' : 'bg-warning' }} ms-2">
                        {{ !empty($application->tribal_certificate) ? 'Uploaded' : 'Missing' }}
                    </span>
                </div>
                <div class="status-item mb-2">
                    <span class="fw-medium">Genealogy Form:</span>
                    <span class="badge {{ !empty($application->genealogy_form) ? 'bg-success' : 'bg-warning' }} ms-2">
                        {{ !empty($application->genealogy_form) ? 'Uploaded' : 'Missing' }}
                    </span>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>

<style>
.documents-preview {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;
}

.doc-item {
    background: white;
    transition: all 0.3s ease;
}

.doc-item:hover {
    background: #f0f0f0;
    transform: translateY(-2px);
}

.doc-label {
    color: #2c3e50;
    font-size: 0.95rem;
}

.badge {
    font-size: 0.75rem;
}

.view-btn, .btn-outline-success {
    font-size: 0.85rem;
    padding: 0.25rem 0.75rem;
}

.document-status {
    background: linear-gradient(135deg, #e3f2fd 0%, #f3e5f5 100%);
}

.status-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0;
}

@media (max-width: 768px) {
    .documents-preview {
        padding: 15px;
    }
    
    .doc-item {
        padding: 15px !important;
    }
    
    .status-item {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .badge {
        margin-top: 5px;
        margin-left: 0 !important;
    }
}
</style>