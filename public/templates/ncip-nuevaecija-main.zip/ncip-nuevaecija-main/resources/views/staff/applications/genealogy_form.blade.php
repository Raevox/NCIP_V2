<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCIP Genealogy Form</title>

    {{-- Link to Review CSS --}}
    <link rel="stylesheet" href="{{ asset('css/review.css') }}">
</head>
<body>
    <div class="form-container">
        <!-- Header -->
        <div class="header">
            <div class="header-left">
                <strong>Republic of the Philippines</strong><br>
                <strong>Province of</strong> <input type="text" class="address-input"><br>
                <strong>AD/Municipality of</strong> <input type="text" class="address-input"><br>
                <strong>AD/Barangay of</strong> <input type="text" class="address-input">
            </div>
            <div class="header-center">
                <div class="form-title">GENEALOGY</div>
            </div>
            <div class="header-right">
                <div class="form-code">NCIP COC Form 2</div>
                <div class="instructions">
                    <strong>Instruction:</strong><br>
                    1. Use mother's maiden name.<br>
                    2. Complete entry in the Place of Origin (Barangay, Municipality, Province)<br>
                    3. Click on any person box to view full details
                </div>
            </div>
        </div>

        <!-- Family Tree -->
        <div class="tree-container">
            <svg class="tree-connections"></svg>
            
            <!-- Great Grandparents Row -->
            <div class="tree-row great-grandparents-row">
                <div id="great-grandfather1" class="person-box" onclick="showDetails(this)">
                    <div class="person-title">Great Grandfather</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
                
                <div id="great-grandmother1" class="person-box" onclick="showDetails(this)">
                    <div class="person-title">Great Grandmother</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>

                <div id="great-grandfather2" class="person-box" onclick="showDetails(this)">
                    <div class="person-title">Great Grandfather</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
                
                <div id="great-grandmother2" class="person-box" onclick="showDetails(this)">
                    <div class="person-title">Great Grandmother</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>

                <div id="great-grandfather3" class="person-box" onclick="showDetails(this)">
                    <div class="person-title">Great Grandfather</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
                
                <div id="great-grandmother3" class="person-box" onclick="showDetails(this)">
                    <div class="person-title">Great Grandmother</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>

                <div id="great-grandfather4" class="person-box" onclick="showDetails(this)">
                    <div class="person-title">Great Grandfather</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
                
                <div id="great-grandmother4" class="person-box" onclick="showDetails(this)">
                    <div class="person-title">Great Grandmother</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
            </div>

            <!-- Grandparents Row -->
            <div class="tree-row grandparents-row">
                <div id="grandfather1" class="person-box-large" onclick="showDetails(this)">
                    <div class="person-title">Grandfather</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
                
                <div id="grandmother1" class="person-box-large" onclick="showDetails(this)">
                    <div class="person-title">Grandmother</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
                
                <div id="grandfather2" class="person-box-large" onclick="showDetails(this)">
                    <div class="person-title">Grandfather</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
                
                <div id="grandmother2" class="person-box-large" onclick="showDetails(this)">
                    <div class="person-title">Grandmother</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
            </div>

            <!-- Parents Row -->
            <div class="tree-row parents-row">
                <div id="father" class="person-box-large" onclick="showDetails(this)">
                    <div class="person-title">Applicant's Father</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
                
                <div id="mother" class="person-box-large" onclick="showDetails(this)">
                    <div class="person-title">Applicant's Mother</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
            </div>

            <!-- Applicant Row -->
            <div class="tree-row applicant-row">
                <div id="applicant" class="person-box-large" onclick="showDetails(this)">
                    <div class="person-title">Name of Applicant</div>
                    <input type="text" class="name-field" placeholder="Full Name">
                    <div class="field-section">
                        <div class="field-label">IP Group</div>
                        <input type="text" class="field-input">
                        <div class="field-label">Place of Origin</div>
                        <input type="text" class="field-input">
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Section -->
        <div class="footer-section">
            <div class="footer-left">
                <div class="validation-left">
                    <p>Validated by:</p>
                    <div class="signature-line"></div>
                    <div class="signature-title">(Signature over Printed Name of Tribal Chieftain/Leader/Elder)</div>
                    
                    <p>CTC No. <input type="text" class="field-input" style="width: 100px;"> 
                    Date Issued: <input type="text" class="field-input" style="width: 100px;"> 
                    Place Issued: <input type="text" class="field-input" style="width: 100px;"></p>
                </div>
            </div>
            
            <div class="validation-center">
                <p>Applicant's Signature</p>
                <div class="signature-line"></div>
                <div class="signature-title2">(Signature over Printed Name)</div>
            </div>
        </div>
    </div>

    <!-- Modal for expanded view -->
    <div id="detailsModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal()">&times;</span>
            <div class="modal-title" id="modalPersonTitle"></div>
            <div class="modal-field">
                <div class="modal-label">Full Name</div>
                <div class="modal-value" id="modalName"></div>
            </div>
            <div class="modal-field">
                <div class="modal-label">IP Group</div>
                <div class="modal-value" id="modalIpGroup"></div>
            </div>
            <div class="modal-field">
                <div class="modal-label">Place of Origin</div>
                <div class="modal-value" id="modalOrigin"></div>
            </div>
        </div>
    </div>

    <script>
    // JavaScript for filling the form with data
    function fillReadonlyTree(step3, step4) {
        // Left side - step3 (father & paternal lineage)
        const leftMap = {
            "father": ["father_first_name","father_last_name","father_ipgroup","father_origin"],
            "grandfather1": ["paternal_grandfather_first_name","paternal_grandfather_last_name","paternal_grandfather_ipgroup","paternal_grandfather_origin"],
            "grandmother1": ["paternal_grandmother_first_name","paternal_grandmother_last_name","paternal_grandmother_ipgroup","paternal_grandmother_origin"],
            "great-grandfather1": ["great_grandfather_grandfather_first_name","great_grandfather_grandfather_last_name","great_grandfather_grandfather_ipgroup","great_grandfather_grandfather_origin"],
            "great-grandmother1": ["great_grandmother_grandfather_first_name","great_grandmother_grandfather_last_name","great_grandmother_grandfather_ipgroup","great_grandmother_grandfather_origin"],
            "great-grandfather2": ["great_grandfather_grandmother_first_name","great_grandfather_grandmother_last_name","great_grandfather_grandmother_ipgroup","great_grandfather_grandmother_origin"],
            "great-grandmother2": ["great_grandmother_grandmother_first_name","great_grandmother_grandmother_last_name","great_grandmother_grandmother_ipgroup","great_grandmother_grandmother_origin"]
        };

        Object.entries(leftMap).forEach(([id, keys]) => {
            const el = document.getElementById(id);
            if (!el) return;
            el.querySelector(".name-field").value = (step3[keys[0]] || '') + ' ' + (step3[keys[1]] || '');
            const inputs = el.querySelectorAll(".field-input");
            if(inputs.length>=2){
                inputs[0].value = step3[keys[2]] || '';
                inputs[1].value = step3[keys[3]] || '';
            }
        });

        // Right side - step4 (mother & maternal lineage)
        const rightMap = {
            "mother": ["mother_first_name","mother_last_name","mother_ipgroup","mother_origin"],
            "grandfather2": ["maternal_grandfather_first_name","maternal_grandfather_last_name","maternal_grandfather_ipgroup","maternal_grandfather_origin"],
            "grandmother2": ["maternal_grandmother_first_name","maternal_grandmother_last_name","maternal_grandmother_ipgroup","maternal_grandmother_origin"],
            "great-grandfather3": ["great_grandfather_grandfather_mother_first_name","great_grandfather_grandfather_mother_last_name","great_grandfather_grandfather_mother_ipgroup","great_grandfather_grandfather_mother_origin"],
            "great-grandmother3": ["great_grandmother_grandfather_mother_first_name","great_grandmother_grandfather_mother_last_name","great_grandmother_grandfather_mother_ipgroup","great_grandmother_grandfather_mother_origin"],
            "great-grandfather4": ["great_grandfather_grandmother_mother_first_name","great_grandfather_grandmother_mother_last_name","great_grandfather_grandmother_mother_ipgroup","great_grandfather_grandmother_mother_origin"],
            "great-grandmother4": ["great_grandmother_grandmother_mother_first_name","great_grandmother_grandmother_mother_last_name","great_grandmother_grandmother_mother_ipgroup","great_grandmother_grandmother_mother_origin"]
        };

        Object.entries(rightMap).forEach(([id, keys]) => {
            const el = document.getElementById(id);
            if (!el) return;
            el.querySelector(".name-field").value = (step4[keys[0]] || '') + ' ' + (step4[keys[1]] || '');
            const inputs = el.querySelectorAll(".field-input");
            if(inputs.length>=2){
                inputs[0].value = step4[keys[2]] || '';
                inputs[1].value = step4[keys[3]] || '';
            }
        });

        // Applicant
        const applicantEl = document.getElementById("applicant");
        applicantEl.querySelector(".name-field").value = (step3.applicant_first_name || '') + ' ' + (step3.applicant_last_name || '');
        const appInputs = applicantEl.querySelectorAll(".field-input");
        if(appInputs.length>=2){
            appInputs[0].value = step3.applicant_ipgroup || '';
            appInputs[1].value = step3.applicant_origin || '';
        }

        // Address fields
        const addrInputs = document.querySelectorAll(".header-left .address-input");
        if(addrInputs.length>=3){
            addrInputs[0].value = step3.province || '';
            addrInputs[1].value = step3.municipality || '';
            addrInputs[2].value = step3.barangay || '';
        }

        // Make all inputs readonly
        document.querySelectorAll("input").forEach(input => input.setAttribute("readonly", true));
    }

    // Function to show details in modal
    function showDetails(element) {
        const title = element.querySelector('.person-title').textContent;
        const name = element.querySelector('.name-field').value;
        const ipGroup = element.querySelectorAll('.field-input')[0].value;
        const origin = element.querySelectorAll('.field-input')[1].value;
        
        document.getElementById('modalPersonTitle').textContent = title;
        document.getElementById('modalName').textContent = name || 'Not provided';
        document.getElementById('modalIpGroup').textContent = ipGroup || 'Not provided';
        document.getElementById('modalOrigin').textContent = origin || 'Not provided';
        
        document.getElementById('detailsModal').style.display = 'flex';
    }

    // Function to close modal
    function closeModal() {
        document.getElementById('detailsModal').style.display = 'none';
    }

    // Close modal when clicking outside of it
    window.onclick = function(event) {
        const modal = document.getElementById('detailsModal');
        if (event.target == modal) {
            closeModal();
        }
    }

    // Example usage (replace with your actual data)
    const step3 = @json($step3);
    const step4 = @json($step4);

    window.addEventListener("load", function() {
        fillReadonlyTree(step3, step4);
    });
    </script>
</body>
</html>