<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
    <!-- Hamburger Button -->
    <div class="hamburger" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </div>

    <!-- Sidebar -->
     <div class="sidebar" id="sidebar">
        <div class="logo">
            <img src="{{ asset('images/ncip logo.png') }}" alt="NCIP Logo">
            <h4>Central Luzon,<br>Nueva Ecija</h4>
        </div>

        <ul class="nav">
            <li class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                <a href="{{ route('admin.dashboard') }}">
                    <i class="fas fa-chart-pie"></i> Dashboard
                </a>
            </li>

            <li class="{{ request()->routeIs('ip_records.index') ? 'active' : '' }}">
                <a href="{{ route('ip_records.index') }}">
                    <i class="fas fa-folder-open"></i> IP Record
                </a>
            </li>

            <li class="{{ request()->routeIs('admin.applicants.*') ? 'active' : '' }}">
               <a href="{{ route('admin.applicants.index') }}">
                    <i class="fas fa-users"></i> Applicant
                </a>
            </li>
            <!-- Content link disabled for now -->
            <li class="disabled">
                <a href="#" style="pointer-events: none; opacity: 0.5;">
                    <i class="fas fa-file-alt"></i> Content
                </a>
            </li>

            <li class="{{ request()->routeIs('admin.accounts.*') ? 'active' : '' }}">
                <a href="{{ route('admin.accounts.index') }}">
                    <i class="fas fa-user-shield"></i> Accounts
                </a>
            </li>
            <li class="{{ request()->routeIs('admin.archive.ip_records') ? 'active' : '' }}">
                <a href="{{ route('admin.archive.ip_records') }}">
                    <i class="fas fa-archive"></i> Archive
                </a>
            </li>
        <!-- Logout at bottom -->
        <div class="logout">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit"><i class="fas fa-sign-out-alt"></i> Log Out</button>
            </form>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main" id="mainContent">
        <!-- Wrapped Topbar -->
        <div class="topbar-wrapper">
            <div class="topbar">
                <h2>Dashboard</h2>
                <div class="profile">
                    <img src="{{ asset('images/adminprofile.png') }}" alt="Admin">
                    <div>
                        <strong>Donato Burnacas</strong><br>
                        <span>Admin</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="cards">
            <div class="card">
                <h3>Total User</h3>
                <p>{{ $totalUsers }}</p>
                <i class="fas fa-user"></i>
            </div>
            <div class="card">
                <h3>Total IP Records</h3>
                <p>{{ $totalIPRecords }}</p>
                <i class="fas fa-folder"></i>
            </div>
            <div class="card">
                <h3>Total COC Issued</h3>
                <p>{{ $totalCOC }}</p>
                <i class="fas fa-certificate"></i>
            </div>
            <div class="card">
                <h3>Total Pending</h3>
                <p>{{ $totalPending }}</p>
                <i class="fas fa-clock"></i>
            </div>
        </div>

        <div class="chart-container">
            <h3>Monthly Application</h3>
            <canvas id="barChart"></canvas>
        </div>
    </div>

    <!-- JS -->
    <script>
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const main = document.getElementById('mainContent');
        sidebar.classList.toggle('active');
        main.classList.toggle('shifted');
    }

    const ctx = document.getElementById('barChart').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: @json($chartLabels),   // ✅ Tribe names
            datasets: [{
                label: 'Number of Applications',
                data: @json($chartData),   // ✅ Counts per tribe
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    precision: 0
                }
            }
        }
    });
</script>

</body>
</html>
