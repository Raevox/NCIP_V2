<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Staff Dashboard')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <style>
        /* Base Layout */
        body {
            margin: 0;
            font-family: "Poppins", sans-serif;
            background: #f5f5f5;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: #fff;
            color: #333;
            padding: 20px 0;
            overflow-y: auto;
            transition: width 0.3s ease, left 0.3s ease;
            z-index: 1000;
        }
        .sidebar.collapsed {
            width: 70px;
        }

        .sidebar .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar .logo img {
            max-width: 60px;
        }
        .sidebar .nav {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar .nav li {
            padding: 12px 20px;
        }
        .sidebar .nav a {
            text-decoration: none;
            color: #0d6efd;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }
        .sidebar.collapsed .nav a span {
            display: none;
        }
        .sidebar .logout {
            position: absolute;
            bottom: 20px;
            width: 100%;
            text-align: center;
        }
        .sidebar .logout button {
            background: transparent;
            border: none;
            color: #ff0000;
            font-weight: bold;
        }

       /* Hamburger */
.hamburger {
    position: fixed;
    top: 15px;
    left: 15px;
    font-size: 20px;
    color: #000;
    cursor: pointer;
    z-index: 1200; /* higher than sidebar (1000) */
    background: #fff; /* optional: add white background so it's always visible */
    border-radius: 4px; 
    padding: 5px 8px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.15); /* optional: slight shadow */
}

        .logo {
    text-align: center;
    margin-bottom: 20px;
    position: relative;
}

.full-logo {
    max-width: 60px;
    transition: all 0.3s ease;
}
.mini-logo {
    max-width: 40px;
    display: none;
    transition: all 0.3s ease;
}

.full-text {
    font-size: 13px;
    transition: opacity 0.3s ease;
}

/* When sidebar collapsed */
.sidebar.collapsed .full-logo,
.sidebar.collapsed .full-text {
    display: none;
}
.sidebar.collapsed .mini-logo {
    display: inline-block;
}


       /* Main content */
.main {
    margin-left: 250px; /* initial sidebar width */
    padding: 10px 20px;
    min-height: 100vh;
    width: calc(100% - 250px); /* fill remaining space */
    transition: margin-left 0.3s ease, width 0.3s ease;
}

/* Topbar */
.topbar {
    margin-left: 0; /* optional: topbar inside main */
    width: 100%; 
    padding: 10px 20px;
    margin-bottom: 20px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0px 2px 6px rgba(0,0,0,0.1);
    transition: margin-left 0.3s ease, width 0.3s ease;
}

/* When sidebar is collapsed */
.sidebar.collapsed ~ .main {
    margin-left: 70px;
    width: calc(100% - 70px);
}

        /* Tables */
        .table-responsive {
            overflow-x: auto;
        }

        /* Mobile */
        @media (max-width: 992px) {
            .sidebar { left: -250px; }
            .sidebar.active { left: 0; }
            .main { margin-left: 0; padding: 10px 15px; }
        }
    </style>
</head>
<body>

<!-- Hamburger Toggle -->
<div class="hamburger" onclick="toggleSidebar()">
    <i class="fas fa-bars"></i>
</div>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="{{ asset('images/ncip logo.png') }}" class="full-logo" alt="NCIP Logo">
        <img src="{{ asset('images/ncip logo.png') }}" class="mini-logo" alt="NCIP Logo">
        <h4 class="full-text">Central Luzon,<br>Nueva Ecija</h4>
    </div>

    <ul class="nav">
        <li class="{{ request()->routeIs('staff.profile') ? 'active' : '' }}">
            <a href="{{ route('staff.profile') }}">
                <i class="fas fa-user"></i> <span>Profile</span>
            </a>
        </li>
        <li class="{{ request()->routeIs('staff.review') ? 'active' : '' }}">
            <a href="{{ route('staff.review') }}">
                <i class="fas fa-tasks"></i> <span>Review Applications</span>
            </a>
        </li>
    </ul>

    <div class="logout">
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit">
                <i class="fas fa-sign-out-alt"></i> <span>Log Out</span>
            </button>
        </form>
    </div>
</div>

<!-- Main -->
<div class="main" id="mainContent">
    <div class="topbar d-flex justify-content-between align-items-center flex-wrap">
        <h2 class="mb-2 mb-md-0">@yield('title', 'Dashboard')</h2>
        <div class="profile d-flex align-items-center gap-2">
            @php $staff = Auth::user(); @endphp
            <img src="{{ $staff && $staff->profile_picture 
                ? asset('storage/' . $staff->profile_picture) 
                : asset('assets/images/default.png') }}"
                 class="rounded-circle" width="40" height="40" alt="Profile">
            <div>
                <strong>{{ $staff->name ?? 'Staff Name' }}</strong><br>
                <span>{{ ucfirst($staff->role ?? 'Staff') }}</span>
            </div>
        </div>
    </div>

    <div class="content-wrapper">
        @yield('content')
    </div>
</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const main = document.getElementById('mainContent');

    sidebar.classList.toggle('collapsed');

    if(window.innerWidth > 992){
        if(sidebar.classList.contains('collapsed')){
            main.style.marginLeft = '70px';
            main.style.width = 'calc(100% - 70px)';
        } else {
            main.style.marginLeft = '250px';
            main.style.width = 'calc(100% - 250px)';
        }
    }
}


</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
