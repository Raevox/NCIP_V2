<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Applicant Dashboard')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- FontAwesome & Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{ asset('css/applicant.css') }}">
    @stack('styles')
</head>
<body>

    <!-- Hamburger -->
    <div class="hamburger" id="hamburger">
        <i class="fas fa-bars"></i>
    </div>

    <!-- Overlay for mobile -->
    <div class="sidebar-overlay" id="overlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="logo text-center my-3">
            <img src="{{ asset('assets/images/IP_logo.jpg') }}" alt="NCIP Logo" class="rounded-circle mb-2" width="70">
            <h5>Central Luzon,<br>Nueva Ecija</h5>
        </div>
            <ul class="nav flex-column">
                <li class="nav-item {{ request()->routeIs('applicant.dashboard') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('applicant.dashboard') }}"><i class="fas fa-home"></i> Home</a>
                </li>
                <li class="nav-item {{ request()->routeIs('applicant.profile') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('applicant.profile') }}"><i class="fas fa-user"></i> Profile</a>
                </li>
                <li class="nav-item {{ request()->routeIs('applicant.history') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('applicant.history') }}">
                        <i class="fas fa-history"></i> COC History
                    </a>
                </li>
                        <a class="nav-link" href="{{ route('applicant.coc.application') }}">
                        <i class="fas fa-file-alt"></i> COC Application
                        </a>

            </ul>
        <div class="logout mt-auto p-3 text-center">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="btn btn-outline-danger w-100"><i class="fas fa-sign-out-alt"></i> Log Out</button>
            </form>
        </div>
    </div>

    <!-- Main content -->
    <div class="main" id="mainContent">
        <div class="topbar-wrapper mb-4">
            <div class="topbar d-flex justify-content-between align-items-center">
                <h2 class="m-0">@yield('page-title', 'Dashboard')</h2>
            </div>
        </div>

        <div class="container-fluid px-4">
            @yield('content')
        </div>
    </div>

    <!-- Scripts -->
    <script>
        const hamburger = document.getElementById('hamburger');
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');
        const overlay = document.getElementById('overlay');

        function toggleSidebar() {
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');

            if(window.innerWidth >= 992){
                if(sidebar.classList.contains('active')){
                    mainContent.style.marginLeft = '240px';
                    mainContent.style.width = 'calc(100% - 240px)';
                } else {
                    mainContent.style.marginLeft = '0';
                    mainContent.style.width = '100%';
                }
            }
        }

        hamburger.addEventListener('click', toggleSidebar);
        overlay.addEventListener('click', toggleSidebar);
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    @stack('scripts')
</body>
</html>
