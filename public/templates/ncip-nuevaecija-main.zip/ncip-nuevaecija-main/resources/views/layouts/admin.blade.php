<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Admin Dashboard')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Chart.js (Optional) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Alpine.js (Optional) -->
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body>

    <!-- Hamburger Menu -->
    <div class="hamburger" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="logo">
            <img src="{{ asset('images/ncip logo.png') }}" alt="NCIP Logo">
            <h4>Central Luzon,<br>Nueva Ecija</h4>
        </div>

        <ul class="nav">
            <li class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                <a href="{{ route('admin.dashboard') }}">
                    <i class="fas fa-chart-pie"></i> Dashboard
                </a>
            </li>

            <li class="{{ request()->routeIs('ip_records.index') ? 'active' : '' }}">
                <a href="{{ route('ip_records.index') }}">
                    <i class="fas fa-folder-open"></i> IP Record
                </a>
            </li>

            <li class="{{ request()->routeIs('admin.applicants.*') ? 'active' : '' }}">
                <a href="{{ route('admin.applicants.index') }}">
                    <i class="fas fa-users"></i> Applicant
                </a>
            </li>
            <!-- Content link disabled for now -->
            <li class="disabled">
                <a href="#" style="pointer-events: none; opacity: 0.5;">
                    <i class="fas fa-file-alt"></i> Content
                </a>
            </li>

            <li class="{{ request()->routeIs('admin.accounts.*') ? 'active' : '' }}">
                <a href="{{ route('admin.accounts.index') }}">
                    <i class="fas fa-user-shield"></i> Accounts
                </a>
            </li>
            <li class="{{ request()->routeIs('admin.archive.ip_records') ? 'active' : '' }}">
                <a href="{{ route('admin.archive.ip_records') }}">
                    <i class="fas fa-archive"></i> Archive
                </a>
            </li>


        <!-- Logout -->
        <div class="logout">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit">
                    <i class="fas fa-sign-out-alt"></i> Log Out
                </button>
            </form>
        </div>
    </div>

    <!-- Main Section -->
    <div class="main" id="mainContent">
        <!-- Topbar -->
        <div class="topbar-wrapper">
            <div class="topbar d-flex justify-content-between align-items-center">
                <h2>@yield('title', 'Dashboard')</h2>
                <div class="profile d-flex align-items-center gap-2">
                    <img src="{{ asset('images/adminprofile.png') }}" alt="Admin Profile">
                    <div>
                        <strong>{{ Auth::user()->name }}</strong><br>
                        <span>{{ ucfirst(Auth::user()->role) }}</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Page Content -->
        <div class="content-wrapper p-3">
            @yield('content')
        </div>
    </div>

    <!-- JS Scripts -->
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const main = document.getElementById('mainContent');
            sidebar.classList.toggle('active');
            main.classList.toggle('shifted');
        }
    </script>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
