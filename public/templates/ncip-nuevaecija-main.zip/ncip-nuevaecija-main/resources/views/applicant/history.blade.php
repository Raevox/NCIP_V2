@extends('layouts.applicant')

@section('title', 'COC History')
@section('page-title', 'COC History')

@section('content')
<div class="card shadow-sm border-0 rounded-3">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0"><i class="fas fa-history"></i> My COC History</h5>
    </div>
    <div class="card-body">
        @if($cocHistory->isEmpty())
            <p class="text-muted">No approved COC forms yet.</p>
        @else
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-primary">
                        <tr>
                            <th>#</th>
                            <th>Application No.</th>
                            <th>Status</th>
                            <th>Approved Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($cocHistory as $index => $coc)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $coc->id }}</td>
                            <td><span class="badge bg-success">{{ $coc->status }}</span></td>
                            <td>{{ $coc->updated_at->format('M d, Y h:i A') }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>
</div>
@endsection
