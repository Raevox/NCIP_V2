@extends('layouts.applicant')

@section('title', 'COC Application')
@section('page-title', 'Application for Certificate of Confirmation (COC)')

@section('content')
<div class="container py-4">
    <div class="container-card p-4 shadow-sm rounded">
        <h2 class="fw-bold mb-3">Apply for Certificate of Confirmation (COC)</h2>
        <p>
            The Certificate of Confirmation (COC) is an official document issued by the 
            National Commission on Indigenous Peoples (NCIP). It serves as proof of an 
            individual's recognition as a member of an Indigenous Cultural Community (ICC) 
            or Indigenous Peoples (IP) group.
        </p>
        <ul class="list-group list-group-flush mb-3">
            <li class="list-group-item">✔ Fill up Information Index Form</li>
            <li class="list-group-item">✔ Fill up Genealogy Form</li>
            <li class="list-group-item">✔ Certification of IP Membership</li>
            <li class="list-group-item">✔ Two (2) identical 2x2 ID photos (Bring to office)</li>
            <li class="list-group-item">✔ Two (2) documentary stamps (Pay in office only)</li>
            <li class="list-group-item">✔ Birth Certificate</li>
            <li class="list-group-item">✔ Certification from the Office of the Tribal Chieftain</li>
        </ul>
        <div class="alert alert-warning d-flex align-items-center mb-4">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <p class="mb-0">
                Important Notice: Before applying for the Certificate of Confirmation (COC), 
                ensure you have all the required documents. Incomplete applications may be rejected.
            </p>
        </div>
        <div class="d-flex justify-content-end my-4">
                {{-- If no application exists yet --}}
                <a href="{{ route('applicant.coc.step1') }}" class="btn btn-primary">
                    <i class="fas fa-paper-plane me-2"></i> Apply Now
                </a>
        </div>

    </div>
</div>
@endsection
