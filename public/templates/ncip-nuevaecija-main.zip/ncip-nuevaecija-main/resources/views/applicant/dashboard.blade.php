@extends('layouts.applicant')

@section('title', 'Dashboard')
@section('page-title', 'Applicant Dashboard')

@section('content')
<div class="container py-4">
    {{-- Add the application status alerts here --}}
    @if($application)
        @if(in_array($application->status, ['Under Review', 'Pending', 'Admin Approval']))
            <div class="alert alert-warning">
                <i class="fas fa-clock"></i> 
                Your application is currently being processed. You cannot submit a new application until this one is completed.
            </div>
        @endif

        @if($application->status === 'Returned')
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i> 
                Your application requires corrections. 
                <a href="{{ route('applicant.coc.coc') }}" class="alert-link">Click here to complete the corrections.</a>
            </div>
        @endif

        @if(in_array($application->status, ['Approved', 'Rejected']))
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> 
                Your previous application has been completed. You can now apply for a new Certificate of Confirmation.
                <a href="{{ route('applicant.coc.coc') }}" class="alert-link">Start new application</a>
            </div>
        @endif
    @else
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> 
            You don't have any active applications. 
            <a href="{{ route('applicant.coc.coc') }}">Start your first application</a>
        </div>
    @endif
    {{-- End of application status alerts --}}

    <div class="d-flex flex-column flex-lg-row gap-4">
        <div class="container-card flex-fill">
            {{-- Rest of your existing content remains the same --}}
            <div class="text-center">
                <div class="rounded-circle bg-primary text-white d-flex justify-content-center align-items-center mx-auto mb-3 shadow"
                     style="width:80px; height:80px;">
                    <i class="fas fa-user fa-2x"></i>
                </div>

                <h5 class="fw-bold mb-1">{{ $user->first_name }} {{ $user->last_name }}</h5>
                <p class="text-muted small mb-4">Applicant</p>

                <div class="table-responsive">
                    <table class="table table-sm table-borderless text-start mx-auto mb-0">
                        <tr>
                            <th class="text-muted">IP Group:</th>
                            <td>{{ $user->tribe ?? ($record->tribe ?? '—') }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Application Date:</th>
                            <td>{{ $application ? $application->created_at->format('F d, Y') : 'No Application Submitted' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">COC Status:</th>
                            <td>
                                <span class="badge px-3 py-2 rounded-pill shadow-sm
                                    @if(!$application) bg-secondary
                                    @elseif(in_array($application->coc_status, ['Under Review', 'Admin Approval'])) bg-warning text-dark
                                    @elseif($application->coc_status === 'Returned') bg-danger
                                    @elseif($application->coc_status === 'Approved') bg-success
                                    @else bg-secondary @endif">
                                    {{ $application ? $application->coc_status : 'No Application Submitted' }}
                                </span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="container-card flex-fill">
            <h5 class="fw-bold text-secondary">
                <i class="fas fa-clipboard-check me-2 text-success"></i> Application Status
            </h5>
            <p class="text-muted small">Track your Certificate of Confirmation application</p>

            <div class="d-flex align-items-center gap-3 flex-wrap mt-3">
                <span class="fw-semibold">Current Status:</span>
                <span class="badge px-3 py-2 rounded-pill shadow-sm
                    @if(!$application) bg-secondary
                    @elseif($application->status === 'Approved') bg-success
                    @elseif($application->status === 'Rejected') bg-danger
                    @else bg-warning text-dark @endif">
                    {{ $application ? $application->status : 'No Application Submitted' }}
                </span>
            </div>

            <div class="mt-4">
                @if($application)
                    <a href="{{ route('applicant.track-status') }}" 
                       class="btn btn-success fw-semibold shadow-sm px-4 py-2" 
                       style="border-radius: 10px;">
                        <i class="fas fa-eye me-2"></i> View Detailed Status
                    </a>
                @else
                    <button class="btn btn-secondary fw-semibold shadow-sm px-4 py-2" 
                            style="border-radius: 10px;" disabled>
                        <i class="fas fa-eye me-2"></i> No Application Yet
                    </button>
                @endif
            </div>

            <div class="mt-3 text-muted small">
                Last updated: {{ now()->format('h:i A, F d, Y') }}
            </div>
        </div>
    </div>
    
    @if($application && $application->coc_status === 'Approved')
    <div class="container-card mt-4 p-4 rounded shadow-lg" style="background-color: #fff; border-left: 4px solid #28a745;">
        <h5 class="fw-bold mb-1">Pickup Location</h5>
        <p class="mb-3 text-muted">Burgos Avenue at Old Capito, Cabanatuan City, Nueva Ecija</p>
        <h6 class="fw-bold mb-2">Instructions</h6>
        <p class="text-muted mb-2" style="font-size: 0.95rem;">
            Please bring the hard copy of the following:
        </p>
        <ul class="mb-0 ps-3" style="font-size: 0.95rem;">
            <li>Certificate of IP Membership</li>
            <li>Two (2) identical 2x2 ID photos</li>
            <li>Photocopy of Birth Certificate</li>
            <li>Certification from the Office of the Tribal Chieftain</li>
        </ul>
    </div>
    @endif
</div>
@endsection