@extends('layouts.applicant')

@section('title', 'COC Form')
@section('page-title', 'NCIP COC Form 1')

@section('content')
@include('applicant.coc.progress-circle', ['currentStep' => 1])
<div class="container-fluid px-2 px-md-4 py-3 py-md-4">
    <div class="row justify-content-center">
        <div class="col-12 col-sm-11 col-md-10 col-lg-8 col-xl-7">
            <div class="paper-container">
                <div class="paper shadow bg-white">
         

                    <div class="paper-header">
                        <h2 class="form-title">NCIP COC Form 1</h2>
                    </div>

                    <div class="paper-content">
                        <form id="step1Form" action="{{ route('applicant.coc.step1.store') }}" method="POST">
                            @csrf

                            {{-- Region Info Section --}}
                            <div class="form-section">
                                <h4 class="section-title">
                                    <i class="fas fa-map-marker-alt me-2"></i>
                                    Region Information
                                </h4>

                                {{-- Province --}}
                                <div class="form-group">
                                    <label class="form-label required">Province</label>
                                    <div class="searchable-select">
                                        <input type="text" 
                                               id="provinceSearch" 
                                               class="form-control search-input" 
                                               placeholder="Search and select province" 
                                               autocomplete="off"
                                               required
                                               value="{{ old('province_name', session('coc_step1.province_name') ?? '') }}">
                                        <i class="fas fa-chevron-down search-icon"></i>
                                        <input type="hidden" name="province" id="province" required value="{{ old('province', session('coc_step1.province') ?? '') }}">
                                        <input type="hidden" name="province_name" id="province_name" required value="{{ old('province_name', session('coc_step1.province_name') ?? '') }}">
                                        <ul id="provinceList" class="dropdown-list"></ul>
                                    </div>
                                </div>

                                {{-- Municipality --}}
                                <div class="form-group">
                                    <label class="form-label required">Municipality</label>
                                    <div class="searchable-select">
                                        <input type="text" 
                                               id="municipalitySearch" 
                                               class="form-control search-input" 
                                               placeholder="Search and select municipality" 
                                               autocomplete="off"
                                               required
                                               value="{{ old('municipality_name', session('coc_step1.municipality_name') ?? '') }}">
                                        <i class="fas fa-chevron-down search-icon"></i>
                                        <input type="hidden" name="municipality" id="municipality" required value="{{ old('municipality', session('coc_step1.municipality') ?? '') }}">
                                        <input type="hidden" name="municipality_name" id="municipality_name" required value="{{ old('municipality_name', session('coc_step1.municipality_name') ?? '') }}">
                                        <ul id="municipalityList" class="dropdown-list"></ul>
                                    </div>
                                </div>

                                {{-- Barangay --}}
                                <div class="form-group">
                                    <label class="form-label required">Barangay</label>
                                    <div class="searchable-select">
                                        <input type="text" 
                                               id="barangaySearch" 
                                               class="form-control search-input" 
                                               placeholder="Search and select barangay" 
                                               autocomplete="off"
                                               required
                                               value="{{ old('barangay_name', session('coc_step1.barangay_name') ?? '') }}">
                                        <i class="fas fa-chevron-down search-icon"></i>
                                        <input type="hidden" name="barangay" id="barangay" required value="{{ old('barangay', session('coc_step1.barangay') ?? '') }}">
                                        <input type="hidden" name="barangay_name" id="barangay_name" required value="{{ old('barangay_name', session('coc_step1.barangay_name') ?? '') }}">
                                        <ul id="barangayList" class="dropdown-list"></ul>
                                    </div>
                                </div>
                            </div>

                            {{-- Purpose Section --}}
                            <div class="form-section">
                                <h4 class="section-title">
                                    <i class="fas fa-clipboard-list me-2"></i>
                                    Purpose (Select as needed)
                                </h4>
                                
                                @php
                                    $purposes = [
                                        'Scholarship (SCH)','Local Employment (LE)','Land Matter (LM)','Civil Service Commission (CSC)',
                                        'IPMR (IPMR)','Cert. of Tribal Marriage (CTM)','Travel Abroad (TA)','NAPOLCOM Requirement (PNP)',
                                        'BJMP: Age Waiver (AW)','BuCor: Age Waiver (AW)','BFP: Age Waiver (AW)','AFP: Age Waiver (AW)'
                                    ];
                                    $oldPurpose = session('coc_step1.purpose', []);
                                @endphp

                                <div class="checkbox-grid">
                                    @foreach ($purposes as $key => $purpose)
                                        <div class="checkbox-item">
                                            <input type="checkbox" 
                                                   name="purpose[]" 
                                                   value="{{ $purpose }}" 
                                                   id="purpose{{ $key }}"
                                                   {{ is_array($oldPurpose) && in_array($purpose, $oldPurpose) ? 'checked' : '' }}>
                                            <label for="purpose{{ $key }}" class="checkbox-label">{{ $purpose }}</label>
                                        </div>
                                    @endforeach
                                </div>

                                <div class="form-group mt-3">
                                    <label class="form-label">Others</label>
                                    <input type="text" 
                                           name="purpose_others" 
                                           class="form-control" 
                                           placeholder="If purpose is not listed above"
                                           value="{{ session('coc_step1.purpose_others') ?? '' }}">
                                </div>
                            </div>

                            {{-- Personal Information Section --}}
                            <div class="form-section">
                                <h4 class="section-title">
                                    <i class="fas fa-user me-2"></i>
                                    Personal Information
                                </h4>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label required">First Name</label>
                                            <input type="text" 
                                                   name="first_name" 
                                                   class="form-control" 
                                                   required
                                                   value="{{ old('first_name', $user->first_name ?? session('coc_step1.first_name', '')) }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label required">Last Name</label>
                                            <input type="text" 
                                                   name="last_name" 
                                                   class="form-control" 
                                                   required
                                                   value="{{ old('last_name', $user->last_name ?? session('coc_step1.last_name', '')) }}">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label required">Sex</label>
                                            <select name="sex" class="form-control" required>
                                                <option value="">Select Sex</option>
                                                <option value="Male" {{ old('sex', session('coc_step1.sex', '')) == 'Male' ? 'selected' : '' }}>Male</option>
                                                <option value="Female" {{ old('sex', session('coc_step1.sex', '')) == 'Female' ? 'selected' : '' }}>Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label required">Civil Status</label>
                                            <select name="civil_status" class="form-control" required>
                                                <option value="">Select Civil Status</option>
                                                <option value="Single" {{ old('civil_status', session('coc_step1.civil_status', '')) == 'Single' ? 'selected' : '' }}>Single</option>
                                                <option value="Married" {{ old('civil_status', session('coc_step1.civil_status', '')) == 'Married' ? 'selected' : '' }}>Married</option>
                                                <option value="Widowed" {{ old('civil_status', session('coc_step1.civil_status', '')) == 'Widowed' ? 'selected' : '' }}>Widowed</option>
                                                <option value="Separated" {{ old('civil_status', session('coc_step1.civil_status', '')) == 'Separated' ? 'selected' : '' }}>Separated</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="form-label required">Place of Origin</label>
                                    <input type="text" 
                                           name="place_origin" 
                                           class="form-control" 
                                           required
                                           value="{{ old('place_origin', session('coc_step1.place_origin', '')) }}">
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Date of Birth</label>
                                            <input type="date" 
                                                   name="date_of_birth" 
                                                   class="form-control"
                                                   value="{{ old('date_of_birth', session('coc_step1.date_of_birth', '')) }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">IP Group</label>
                                            <input type="text" 
                                                   name="ip_group" 
                                                   class="form-control"
                                                   value="{{ old('ip_group', session('coc_step1.ip_group', '')) }}">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- Spouse Information Section --}}
                            <div class="form-section">
                                <h4 class="section-title">
                                    <i class="fas fa-heart me-2"></i>
                                    Spouse Information
                                </h4>
                                <p class="text-muted small mb-3">Fill out only if married</p>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Spouse First Name</label>
                                            <input type="text" 
                                                   name="spouse_first_name" 
                                                   class="form-control"
                                                   value="{{ old('spouse_first_name', session('coc_step1.spouse_first_name', '')) }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Spouse Last Name</label>
                                            <input type="text" 
                                                   name="spouse_last_name" 
                                                   class="form-control"
                                                   value="{{ old('spouse_last_name', session('coc_step1.spouse_last_name', '')) }}">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- Submit Button --}}
                            <div class="form-actions">
                                <button type="submit" class="btn btn-success btn-next">
                                    <span class="btn-text">
                                        <i class="fas fa-arrow-right me-2"></i>
                                        Next: Step 2
                                    </span>
                                    <div class="btn-loading d-none">
                                        <i class="fas fa-spinner fa-spin me-2"></i>
                                        Processing...
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Enhanced Mobile-Friendly CSS --}}
<style>
/* Paper Container Styles */
.paper-container {
    width: 100%;
    margin: 0 auto;
}

.paper {
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    min-height: auto;
    position: relative;
}

/* Paper Header */
.paper-header {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
    color: white;
    padding: 1.5rem;
    text-align: center;
    margin: -1px -1px 0 -1px;
}

.form-title {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 700;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Paper Content */
.paper-content {
    padding: 2rem;
}

/* Form Sections */
.form-section {
    margin-bottom: 2.5rem;
    border-bottom: 1px solid #e9ecef;
    padding-bottom: 2rem;
}

.form-section:last-of-type {
    border-bottom: none;
    margin-bottom: 1rem;
}

.section-title {
    color: #28a745;
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid #e9ecef;
}

/* Form Groups */
.form-group {
    margin-bottom: 1.5rem;
}

.form-label {
    font-weight: 600;
    color: #495057;
    margin-bottom: 0.5rem;
    display: block;
    font-size: 0.95rem;
}

.form-label.required::after {
    content: " *";
    color: #dc3545;
    font-weight: bold;
}

.form-control {
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 0.75rem 1rem;
    font-size: 1rem;
    transition: all 0.3s ease;
    background-color: #ffffff;
}

.form-control:focus {
    border-color: #28a745;
    box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.25);
    background-color: #ffffff;
}

/* Searchable Select Styles */
.searchable-select {
    position: relative;
}

.search-input {
    padding-right: 2.5rem;
}

.search-icon {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: #6c757d;
    pointer-events: none;
    transition: transform 0.3s ease;
}

.searchable-select:focus-within .search-icon {
    transform: translateY(-50%) rotate(180deg);
}

/* Dropdown List */
.dropdown-list {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    max-height: 200px;
    overflow-y: auto;
    border: 2px solid #28a745;
    border-radius: 8px;
    background: white;
    z-index: 1000;
    list-style: none;
    padding: 0;
    margin: 0.25rem 0 0 0;
    display: none;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.dropdown-list li {
    padding: 0.75rem 1rem;
    cursor: pointer;
    border-bottom: 1px solid #f8f9fa;
    font-size: 0.95rem;
    transition: background-color 0.2s ease;
}

.dropdown-list li:hover {
    background: #28a745;
    color: white;
}

.dropdown-list li:last-child {
    border-bottom: none;
}

/* Checkbox Grid */
.checkbox-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 0.75rem;
}

.checkbox-item {
    display: flex;
    align-items: flex-start;
    padding: 0.75rem;
    background: #f8f9fa;
    border-radius: 8px;
    transition: background-color 0.2s ease;
}

.checkbox-item:hover {
    background: #e9ecef;
}

.checkbox-item input[type="checkbox"] {
    margin-right: 0.75rem;
    margin-top: 0.1rem;
    width: 1.2rem;
    height: 1.2rem;
    accent-color: #28a745;
    cursor: pointer;
}

.checkbox-label {
    cursor: pointer;
    margin: 0;
    font-size: 0.9rem;
    line-height: 1.4;
    color: #495057;
}

/* Form Actions */
.form-actions {
    padding-top: 1.5rem;
    border-top: 2px solid #e9ecef;
    margin-top: 1rem;
}

.btn-next {
    width: 100%;
    padding: 0.9rem 2rem;
    font-size: 1.1rem;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
    color: white;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn-next:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(40, 167, 69, 0.3);
    background: linear-gradient(135deg, #218838 0%, #1ea887 100%);
}

.btn-next:active {
    transform: translateY(0);
}

.btn-next:disabled {
    opacity: 0.7;
    transform: none;
    cursor: not-allowed;
}

/* Mobile Responsive Design */
@media (max-width: 768px) {
    .paper-content {
        padding: 1.25rem;
    }
    
    .paper-header {
        padding: 1.25rem;
    }
    
    .form-title {
        font-size: 1.3rem;
    }
    
    .section-title {
        font-size: 1.1rem;
    }
    
    .checkbox-grid {
        grid-template-columns: 1fr;
    }
    
    .dropdown-list {
        max-height: 160px;
    }
    
    .form-group {
        margin-bottom: 1.25rem;
    }
}

@media (max-width: 480px) {
    .container-fluid {
        padding-left: 0.75rem;
        padding-right: 0.75rem;
    }
    
    .paper-content {
        padding: 1rem;
    }
    
    .paper-header {
        padding: 1rem;
    }
    
    .form-title {
        font-size: 1.2rem;
    }
    
    .form-control {
        padding: 0.65rem 0.85rem;
        font-size: 0.95rem;
    }
    
    .btn-next {
        padding: 0.8rem 1.5rem;
        font-size: 1rem;
    }
}

/* Loading State */
.btn-loading {
    display: none;
}

.btn-next.loading .btn-text {
    display: none;
}

.btn-next.loading .btn-loading {
    display: block;
}

/* Accessibility Improvements */
@media (prefers-reduced-motion: reduce) {
    * {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
        scroll-behavior: auto !important;
    }
}

/* High Contrast Mode Support */
@media (prefers-contrast: high) {
    .form-control {
        border-width: 3px;
    }
    
    .dropdown-list {
        border-width: 3px;
    }
}
</style>

{{-- Enhanced JavaScript --}}
<script>
document.addEventListener("DOMContentLoaded", async () => {
    // Add loading state to form
    const form = document.getElementById("step1Form");
    const submitBtn = form.querySelector(".btn-next");
    
    // Load location data
    try {
        const [provincesRes, municipalitiesRes, barangaysRes] = await Promise.all([
            fetch('/data/provinces.json'),
            fetch('/data/mun.json'),
            fetch('/data/brgy.json')
        ]);
        
        const provinces = (await provincesRes.json()).RECORDS;
        const municipalities = (await municipalitiesRes.json()).RECORDS;
        const barangays = (await barangaysRes.json()).RECORDS;

        function setupSearch(inputId, listId, hiddenId, hiddenNameId, dataset, filterKey, labelKey, parentFilterKey = null, parentInputId = null) {
            const input = document.getElementById(inputId);
            const list = document.getElementById(listId);
            const hidden = document.getElementById(hiddenId);
            const hiddenName = document.getElementById(hiddenNameId);
            let debounceTimer;

            input.addEventListener("input", () => {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => {
                    const query = input.value.toLowerCase().trim();
                    let filtered = dataset;

                    // Filter by parent first
                    if (parentFilterKey && parentInputId) {
                        const parentVal = document.getElementById(parentInputId).value;
                        if (parentVal) {
                            filtered = filtered.filter(item => item[parentFilterKey] === parentVal);
                        }
                    }

                    // Then filter by search query
                    if (query) {
                        filtered = filtered.filter(item => 
                            item[labelKey].toLowerCase().includes(query)
                        ).slice(0, 50); // Limit results for performance
                    } else {
                        filtered = filtered.slice(0, 50);
                    }

                    // Clear previous selections if input changed
                    if (input.value !== hiddenName.value) {
                        hidden.value = "";
                        hiddenName.value = "";
                    }

                    renderDropdown(filtered);
                }, 300);
            });

            input.addEventListener("focus", () => {
                if (input.value && !hidden.value) {
                    input.dispatchEvent(new Event('input'));
                }
            });

            input.addEventListener("blur", () => {
                setTimeout(() => {
                    list.style.display = "none";
                }, 200);
            });

            function renderDropdown(items) {
                list.innerHTML = "";
                
                if (items.length === 0) {
                    const li = document.createElement("li");
                    li.textContent = "No results found";
                    li.style.color = "#6c757d";
                    li.style.fontStyle = "italic";
                    list.appendChild(li);
                } else {
                    items.forEach(item => {
                        const li = document.createElement("li");
                        li.textContent = item[labelKey];
                        li.setAttribute('data-value', item[filterKey]);
                        
                        li.addEventListener('click', () => {
                            input.value = item[labelKey];
                            hidden.value = item[filterKey];
                            hiddenName.value = item[labelKey];
                            list.style.display = "none";
                            
                            // Trigger change event for dependent dropdowns
                            input.dispatchEvent(new Event('change'));
                            
                            // Clear dependent dropdowns
                            clearDependentDropdowns(inputId);
                        });
                        
                        list.appendChild(li);
                    });
                }

                list.style.display = items.length ? "block" : "none";
            }
        }

        function clearDependentDropdowns(parentInputId) {
            if (parentInputId === 'provinceSearch') {
                // Clear municipality and barangay
                ['municipalitySearch', 'barangaySearch'].forEach(id => {
                    document.getElementById(id).value = '';
                    document.getElementById(id.replace('Search', '')).value = '';
                    document.getElementById(id.replace('Search', '_name')).value = '';
                });
            } else if (parentInputId === 'municipalitySearch') {
                // Clear barangay
                document.getElementById('barangaySearch').value = '';
                document.getElementById('barangay').value = '';
                document.getElementById('barangay_name').value = '';
            }
        }

        // Setup searchable dropdowns
        setupSearch("provinceSearch", "provinceList", "province", "province_name", provinces, "provCode", "provDesc");
        setupSearch("municipalitySearch", "municipalityList", "municipality", "municipality_name", municipalities, "citymunCode", "citymunDesc", "provCode", "province");
        setupSearch("barangaySearch", "barangayList", "barangay", "barangay_name", barangays, "brgyCode", "brgyDesc", "citymunCode", "municipality");

        // Form validation and submission
        form.addEventListener("submit", function(e) {
            const province = document.getElementById("province").value;
            const municipality = document.getElementById("municipality").value;
            const barangay = document.getElementById("barangay").value;

            if (!province || !municipality || !barangay) {
                e.preventDefault();
                showAlert("Please select a Province, Municipality, and Barangay from the dropdown lists.", "warning");
                return;
            }

            // Add loading state
            submitBtn.classList.add('loading');
            submitBtn.disabled = true;
        });

        // Show alert function
        function showAlert(message, type = 'info') {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
            alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
            alertDiv.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            document.body.appendChild(alertDiv);

            // Auto dismiss after 5 seconds
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.parentNode.removeChild(alertDiv);
                }
            }, 5000);
        }

    } catch (error) {
        console.error('Error loading location data:', error);
        showAlert('Error loading location data. Please refresh the page.', 'danger');
    }
});
</script>
@endsection