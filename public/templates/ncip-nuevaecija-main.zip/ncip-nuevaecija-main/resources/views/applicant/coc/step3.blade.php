@extends('layouts.applicant')

@section('title', 'COC Form')
@section('page-title', 'NCIP COC Form 3')

@section('content')
       @include('applicant.coc.progress-circle', ['currentStep' => 3])
<div class="container py-4 d-flex justify-content-center">
    <div class="paper-container">
        <div class="paper shadow p-5 bg-white">

            <h2 class="fw-bold mb-3 text-center">NCIP COC Form 3 (Genealogy)</h2>

            <form action="{{ route('applicant.coc.step3.store', ['id' => $step3['id'] ?? null]) }}" method="POST">
                @csrf

                {{-- Full Name of Applicant --}}
                <div class="mb-4">
                    <h5 class="fw-bold">Full Name of Applicant</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">First Name</label>
                            <input type="text" name="applicant_first_name" class="form-control" placeholder="First name"
                                   value="{{ old('applicant_first_name', $step3['applicant_first_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="applicant_last_name" class="form-control" placeholder="Last name"
                                   value="{{ old('applicant_last_name', $step3['applicant_last_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Place of Origin</label>
                            <input type="text" name="applicant_origin" class="form-control" placeholder="Place origin"
                                   value="{{ old('applicant_origin', $step3['applicant_origin'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">IP Group</label>
                            <input type="text" name="applicant_ipgroup" class="form-control" placeholder="IP group"
                                   value="{{ old('applicant_ipgroup', $step3['applicant_ipgroup'] ?? '') }}">
                        </div>
                    </div>
                </div>

                {{-- Present Address --}}
                <div class="mb-4">
                    <h5 class="fw-bold">Present Address</h5>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Province</label>
                            <input type="text" name="province" class="form-control" placeholder="Province"
                                   value="{{ old('province', $step3['province'] ?? '') }}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Municipality</label>
                            <input type="text" name="municipality" class="form-control" placeholder="Municipality"
                                   value="{{ old('municipality', $step3['municipality'] ?? '') }}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Barangay</label>
                            <input type="text" name="barangay" class="form-control" placeholder="Barangay"
                                   value="{{ old('barangay', $step3['barangay'] ?? '') }}">
                        </div>
                    </div>
                </div>

        {{-- Father --}}
        <div class="mb-4">
            <h5 class="fw-bold">Father</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">First Name</label>
                    <input type="text" name="father_first_name" class="form-control" placeholder="Enter first name"
                           value="{{ old('father_first_name', $step3['father_first_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="father_last_name" class="form-control" placeholder="Enter last name"
                           value="{{ old('father_last_name', $step3['father_last_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Place of Origin</label>
                    <input type="text" name="father_origin" class="form-control" placeholder="Enter place of origin"
                           value="{{ old('father_origin', $step3['father_origin'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">IP Group</label>
                    <input type="text" name="father_ipgroup" class="form-control" placeholder="Enter IP group"
                           value="{{ old('father_ipgroup', $step3['father_ipgroup'] ?? '') }}">
                </div>
            </div>
        </div>
        {{-- Grandfather (Father’s Side) --}}
        <div class="mb-4">
            <h5 class="fw-bold">Grandfather (Father’s Side)</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">First Name</label>
                    <input type="text" name="paternal_grandfather_first_name" class="form-control"
                           value="{{ old('paternal_grandfather_first_name', $step3['paternal_grandfather_first_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="paternal_grandfather_last_name" class="form-control"
                           value="{{ old('paternal_grandfather_last_name', $step3['paternal_grandfather_last_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Place of Origin</label>
                    <input type="text" name="paternal_grandfather_origin" class="form-control"
                           value="{{ old('paternal_grandfather_origin', $step3['paternal_grandfather_origin'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">IP Group</label>
                    <input type="text" name="paternal_grandfather_ipgroup" class="form-control"
                           value="{{ old('paternal_grandfather_ipgroup', $step3['paternal_grandfather_ipgroup'] ?? '') }}">
                </div>
            </div>
        </div>
        {{-- Grandmother (Father’s Side) --}}
        <div class="mb-4">
            <h5 class="fw-bold">Grandmother (Father’s Side)</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">First Name</label>
                    <input type="text" name="paternal_grandmother_first_name" class="form-control"
                           value="{{ old('paternal_grandmother_first_name', $step3['paternal_grandmother_first_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="paternal_grandmother_last_name" class="form-control"
                           value="{{ old('paternal_grandmother_last_name', $step3['paternal_grandmother_last_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Place of Origin</label>
                    <input type="text" name="paternal_grandmother_origin" class="form-control"
                           value="{{ old('paternal_grandmother_origin', $step3['paternal_grandmother_origin'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">IP Group</label>
                    <input type="text" name="paternal_grandmother_ipgroup" class="form-control"
                           value="{{ old('paternal_grandmother_ipgroup', $step3['paternal_grandmother_ipgroup'] ?? '') }}">
                </div>
            </div>
        </div>
        
        
        {{-- Great Grandfather (Grandfather’s Father) --}}
        <div class="mb-4">
            <h5 class="fw-bold">Great Grandfather (Grandfather’s Father)</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">First Name</label>
                    <input type="text" name="great_grandfather_grandfather_first_name" class="form-control" placeholder="Enter first name"
                           value="{{ old('great_grandfather_grandfather_first_name', $step3['great_grandfather_grandfather_first_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="great_grandfather_grandfather_last_name" class="form-control" placeholder="Enter last name"
                           value="{{ old('great_grandfather_grandfather_last_name', $step3['great_grandfather_grandfather_last_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Place of Origin</label>
                    <input type="text" name="great_grandfather_grandfather_origin" class="form-control" placeholder="Enter place of origin"
                           value="{{ old('great_grandfather_grandfather_origin', $step3['great_grandfather_grandfather_origin'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">IP Group</label>
                    <input type="text" name="great_grandfather_grandfather_ipgroup" class="form-control" placeholder="Enter IP group"
                           value="{{ old('great_grandfather_grandfather_ipgroup', $step3['great_grandfather_grandfather_ipgroup'] ?? '') }}">
                </div>
            </div>
        </div>
        
        {{-- Great Grandmother (Grandfather’s Mother) --}}
        <div class="mb-4">
            <h5 class="fw-bold">Great Grandmother (Grandfather’s Mother)</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">First Name</label>
                    <input type="text" name="great_grandmother_grandfather_first_name" class="form-control" placeholder="Enter first name"
                           value="{{ old('great_grandmother_grandfather_first_name', $step3['great_grandmother_grandfather_first_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="great_grandmother_grandfather_last_name" class="form-control" placeholder="Enter last name"
                           value="{{ old('great_grandmother_grandfather_last_name', $step3['great_grandmother_grandfather_last_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Place of Origin</label>
                    <input type="text" name="great_grandmother_grandfather_origin" class="form-control" placeholder="Enter place of origin"
                           value="{{ old('great_grandmother_grandfather_origin', $step3['great_grandmother_grandfather_origin'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">IP Group</label>
                    <input type="text" name="great_grandmother_grandfather_ipgroup" class="form-control" placeholder="Enter IP group"
                           value="{{ old('great_grandmother_grandfather_ipgroup', $step3['great_grandmother_grandfather_ipgroup'] ?? '') }}">
                </div>
            </div>
        </div>
        {{-- Great Grandfather (Grandmother’s Father) --}}
        <div class="mb-4">
            <h5 class="fw-bold">Great Grandfather (Grandmother’s Father)</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">First Name</label>
                    <input type="text" name="great_grandfather_grandmother_first_name" class="form-control" placeholder="Enter first name"
                           value="{{ old('great_grandfather_grandmother_first_name', $step3['great_grandfather_grandmother_first_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="great_grandfather_grandmother_last_name" class="form-control" placeholder="Enter last name"
                           value="{{ old('great_grandfather_grandmother_last_name', $step3['great_grandfather_grandmother_last_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Place of Origin</label>
                    <input type="text" name="great_grandfather_grandmother_origin" class="form-control" placeholder="Enter place of origin"
                           value="{{ old('great_grandfather_grandmother_origin', $step3['great_grandfather_grandmother_origin'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">IP Group</label>
                    <input type="text" name="great_grandfather_grandmother_ipgroup" class="form-control" placeholder="Enter IP group"
                           value="{{ old('great_grandfather_grandmother_ipgroup', $step3['great_grandfather_grandmother_ipgroup'] ?? '') }}">
                </div>
            </div>
        </div>
        
        {{-- Great Grandmother (Grandmother’s Mother) --}}
        <div class="mb-4">
            <h5 class="fw-bold">Great Grandmother (Grandmother’s Mother)</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">First Name</label>
                    <input type="text" name="great_grandmother_grandmother_first_name" class="form-control" placeholder="Enter first name"
                           value="{{ old('great_grandmother_grandmother_first_name', $step3['great_grandmother_grandmother_first_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="great_grandmother_grandmother_last_name" class="form-control" placeholder="Enter last name"
                           value="{{ old('great_grandmother_grandmother_last_name', $step3['great_grandmother_grandmother_last_name'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Place of Origin</label>
                    <input type="text" name="great_grandmother_grandmother_origin" class="form-control" placeholder="Enter place of origin"
                           value="{{ old('great_grandmother_grandmother_origin', $step3['great_grandmother_grandmother_origin'] ?? '') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">IP Group</label>
                    <input type="text" name="great_grandmother_grandmother_ipgroup" class="form-control" placeholder="Enter IP group"
                           value="{{ old('great_grandmother_grandmother_ipgroup', $step3['great_grandmother_grandmother_ipgroup'] ?? '') }}">
                </div>
            </div>
        </div>
        {{-- Step Navigation Buttons --}}
        <div class="d-flex justify-content-between mt-4">
            {{-- Back Button --}}
            <a href="{{ route('applicant.coc.step2') }}" class="btn btn-secondary">
                 Back
            </a>
        
            {{-- Next Button (submit form) --}}
            <button type="submit" class="btn btn-primary">
                Next 
            </button>
        </div>
        

@endsection
