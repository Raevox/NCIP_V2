@extends('layouts.applicant')

@section('title', 'COC Form - Step 5')
@section('page-title', 'Step 5: Upload Documents')

@section('content')
    @include('applicant.coc.progress-circle', ['currentStep' => 5])
    <div class="container my-3 my-md-5">
        <div class="card shadow-sm p-3 p-md-4 mx-auto" style="max-width: 700px;">
            <h4 class="mb-3 mb-md-4 text-center">Upload Required Documents</h4>

            <form action="{{ route('applicant.coc.step5.store') }}" method="POST" enctype="multipart/form-data">


                @csrf

                {{-- Applicant Picture --}}
                <div class="mb-3 mb-md-4">
                    <label class="form-label fw-bold">Applicant Picture <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input type="file" name="applicant_picture" class="form-control" required 
                               accept="image/*" aria-describedby="pictureHelp">
                    </div>
                    <div id="pictureHelp" class="form-text text-muted small">
                        Accepted formats: JPG, PNG, GIF. Max size: 5MB
                    </div>
                    @error('applicant_picture')
                        <span class="text-danger small">{{ $message }}</span>
                    @enderror
                </div>

                {{-- Signature --}}
                <div class="mb-3 mb-md-4">
                    <label class="form-label fw-bold">Signature <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input type="file" name="signature" class="form-control" required 
                               accept="image/*" aria-describedby="signatureHelp">
                    </div>
                    <div id="signatureHelp" class="form-text text-muted small">
                        Accepted formats: JPG, PNG, GIF. Max size: 5MB
                    </div>
                    @error('signature')
                        <span class="text-danger small">{{ $message }}</span>
                    @enderror
                </div>

                {{-- Tribal Certificate --}}
                <div class="mb-3 mb-md-4">
                    <label class="form-label fw-bold">Tribal Certificate <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input type="file" name="tribal_certificate" class="form-control" required 
                               accept=".pdf,.jpg,.jpeg,.png" aria-describedby="certificateHelp">
                    </div>
                    <div id="certificateHelp" class="form-text text-muted small">
                        Accepted formats: PDF, JPG, PNG. Max size: 10MB
                    </div>
                    @error('tribal_certificate')
                        <span class="text-danger small">{{ $message }}</span>
                    @enderror
                </div>

                
                <div class="mb-3 mb-md-4">
                    <label class="form-label fw-bold">Upload Completed Genealogy Form <span class="text-danger">*</span></label>
                    <input type="file" name="genealogy_form" class="form-control @error('genealogy_form') is-invalid @enderror" 
                        required accept=".pdf,image/*">
                    <div class="form-text small">Accepted formats: PDF, JPG, PNG, JPEG. Max size: 10MB</div>
                    @error('genealogy_form')
                        <span class="text-danger small">{{ $message }}</span>
                    @enderror
                </div>

                
        {{-- Notice --}}
        <div class="alert alert-warning">
            <strong>Important:</strong> Please download the Genealogy Form from Step 4, print it, and have it attested by 
            <strong>Council of Elders / IP Leader / Punong Barangay</strong> 
            with <strong>SIGNATURE OVER PRINTED NAME</strong>. Only completed and signed forms can be uploaded here.
        </div>

                {{-- File Preview Section (Optional) --}}
                <div class="alert alert-info d-none" id="filePreviewAlert">
                    <small><i class="fas fa-info-circle me-1"></i> Selected files will be shown here</small>
                    <div id="filePreviews" class="mt-2"></div>
                </div>

                {{-- Buttons --}}
                <div class="d-flex flex-column flex-sm-row justify-content-between gap-3 mt-4 pt-3 border-top">
                    <a href="{{ route('applicant.coc.step4') }}" class="btn btn-secondary order-2 order-sm-1">
                        <i class="fas fa-arrow-left me-1"></i> Back
                    </a>

                    @if(
                        $application->status === 'Returned' && 
                        $application->documents_status === 'returned' &&
                        empty($application->index_status) &&
                        empty($application->genealogy_status)
                    )
                        <button type="submit" class="btn btn-success order-1 order-sm-2">
                            <i class="fas fa-paper-plane me-1"></i> Resubmit Application
                        </button>
                    @else
                        <button type="submit" class="btn btn-primary order-1 order-sm-2">
                            <i class="fas fa-arrow-right me-1"></i> Next
                        </button>
                    @endif
                </div>
            </form>
        </div>
    </div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const fileInputs = document.querySelectorAll('input[type="file"]');
    const previewAlert = document.getElementById('filePreviewAlert');
    const filePreviews = document.getElementById('filePreviews');

    fileInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            updateFilePreviews();
        });
    });

    function updateFilePreviews() {
        filePreviews.innerHTML = '';
        let hasFiles = false;
        
        fileInputs.forEach(input => {
            if (input.files.length > 0) {
                hasFiles = true;
                const file = input.files[0];
                const fileSize = (file.size / 1024 / 1024).toFixed(2); // MB
                
                const preview = document.createElement('div');
                preview.className = 'file-preview mb-2 p-2 bg-light rounded small';
                preview.innerHTML = `
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="text-truncate me-2">
                            <i class="fas fa-file-${getFileIcon(file.type)} text-primary me-1"></i>
                            ${file.name}
                        </span>
                        <span class="badge bg-secondary">${fileSize} MB</span>
                    </div>
                `;
                filePreviews.appendChild(preview);
            }
        });

        if (hasFiles) {
            previewAlert.classList.remove('d-none');
        } else {
            previewAlert.classList.add('d-none');
        }
    }

    function getFileIcon(fileType) {
        if (fileType.startsWith('image/')) return 'image';
        if (fileType === 'application/pdf') return 'pdf';
        return 'file';
    }

    // Add touch-friendly styles
    if ('ontouchstart' in window) {
        document.querySelectorAll('.form-control').forEach(input => {
            input.style.minHeight = '44px'; // Better touch target
        });
        
        document.querySelectorAll('.btn').forEach(btn => {
            btn.style.minHeight = '44px';
            btn.style.minWidth = '44px';
        });
    }
});
</script>
@endpush

@push('styles')
<style>
    /* Mobile-first responsive design */
    .card {
        border: none;
        border-radius: 12px;
    }

    .form-label {
        font-size: 0.95rem;
        margin-bottom: 0.5rem;
    }

    .form-control {
        border-radius: 8px;
        padding: 0.75rem;
        font-size: 0.9rem;
        border: 2px solid #e9ecef;
        transition: all 0.3s ease;
    }

    .form-control:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
    }

    .btn {
        border-radius: 8px;
        padding: 0.75rem 1.5rem;
        font-size: 0.9rem;
        font-weight: 500;
        flex: 1;
        min-height: 44px;
    }

    .input-group {
        position: relative;
    }

    .file-preview {
        font-size: 0.8rem;
    }

    .text-truncate {
        max-width: 200px;
    }

    /* Mobile specific styles */
    @media (max-width: 576px) {
        .container {
            padding-left: 10px;
            padding-right: 10px;
        }
        
        .card {
            margin: 0.5rem;
            padding: 1.25rem !important;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        h4 {
            font-size: 1.25rem;
        }

        .btn {
            font-size: 0.85rem;
            padding: 0.75rem 1rem;
        }

        .form-text {
            font-size: 0.75rem;
        }

        .d-flex.flex-column .btn {
            width: 100%;
        }
    }

    /* Tablet styles */
    @media (min-width: 577px) and (max-width: 768px) {
        .card {
            padding: 2rem !important;
        }
        
        .btn {
            min-width: 120px;
        }
    }

    /* Desktop enhancements */
    @media (min-width: 769px) {
        .card {
            padding: 2.5rem !important;
        }
        
        .form-control:hover {
            border-color: #ced4da;
        }
    }

    /* High contrast support for accessibility */
    @media (prefers-contrast: high) {
        .form-control {
            border-width: 3px;
        }
        
        .btn {
            border-width: 2px;
        }
    }

    /* Reduced motion support */
    @media (prefers-reduced-motion: reduce) {
        .form-control {
            transition: none;
        }
    }
</style>
@endpush