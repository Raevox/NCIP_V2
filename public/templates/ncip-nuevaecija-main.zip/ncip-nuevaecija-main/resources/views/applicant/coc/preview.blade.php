@extends('layouts.applicant')

@section('title', 'COC Preview')
@section('page-title', 'Step 6: Preview & Confirm')
@include('applicant.coc.progress-circle', ['currentStep' => 6])
@section('content')
<style>
    body { font-family: Arial, Helvetica, sans-serif; font-size:13px; background:#f5f5f5; padding:20px; }
    .form-box { border:1px solid #000; padding:20px; max-width:1000px; margin:auto; background:#fff; border-radius:6px; page-break-after: always; }
    .form-header { display:grid; grid-template-columns:120px 1fr; align-items:center; margin-bottom:10px; }
    .header-left { text-align:center; }
    .header-left img { max-width:90px; margin-bottom:5px; }
    .header-left p { font-size:12px; font-weight:bold; margin:2px 0; }
    .header-center { text-align:center; line-height:1.4; }
    .header-center p { margin:2px 0; }
    .header-center b { font-size:14px; }
    .location-line { margin-top:8px; font-size:13px; line-height:1.6; }
    .location-line span { display:inline-block; border-bottom:1px solid #000; min-width:150px; }
    h2,h3 { margin:12px 0; font-size:16px; text-decoration:underline; }
    .title-form h2 { text-align:center; }
    .purpose-box { border:1px solid #000; padding:12px; margin-top:10px; }
    .purpose-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:5px 15px; }
    .purpose-grid label { display:flex; align-items:center; gap:5px; }
    .purpose-grid input[type="checkbox"] {accent-color: #0d6efd; width: 16px; height: 16px;}
    .grid-2, .grid-3 { display:grid; gap:10px 15px; margin-bottom:12px; }
    .grid-2 { grid-template-columns:repeat(2,1fr); }
    .grid-3 { grid-template-columns:repeat(3,1fr); }
    .grid-2 div, .grid-3 div { display:flex; flex-direction:column; }
    .grid-2 label, .grid-3 label { font-weight:bold; font-size:13px; margin-bottom:3px; }
    .grid-2 input, .grid-3 input, .grid-2 select, .grid-3 select { padding:5px 8px; border:1px solid #000; border-radius:3px; font-size:13px; }
    table { width:100%; border-collapse:collapse; margin-top:10px; font-size:13px; }
    table, th, td { border:1px solid #000; }
    th, td { padding:6px; text-align:left; }
    .land-section { margin-top:15px; font-size:13px; }
    .land-section p { margin:5px 0; }
    .underline { display:inline-block; border-bottom:1px solid #000; min-width:150px; }
    .pledge { border:1px solid #000; padding:12px; margin-top:15px; line-height:1.5; }
    .pledge p { margin-bottom:8px; text-align:justify; }
    .signature { margin-top:30px; text-align:right; }
    .signature p { margin:5px 0; }
</style>

<div class="form-box">

    <div class="form-header">
        <div class="header-left">
            <img src="{{ asset('images/ncip logo.jpg') }}" alt="NCIP Logo" />
            <p>REGION 3</p>
            <p>CENTRAL LUZON</p>
        </div>
        <div class="header-center">
            <p>Republic of the Philippines</p>
            <p>OFFICE OF THE PRESIDENT</p>
            <p><b>NATIONAL COMMISSION ON INDIGENOUS PEOPLES</b></p>
            <div class="location-line">
                Province of <span>{{ $step1['province_name'] ?? '' }}</span><br>
                AD/Municipality <span>{{ $step1['municipality_name'] ?? '' }}</span><br>
                AD/Barangay of <span>{{ $step1['barangay_name'] ?? '' }}</span>
            </div>
        </div>
    </div>
    <div class="title-form"><h2>INFORMATION INDEX</h2></div>
    <div class="purpose-box">
        <h3>Purpose: (Check only 1 box)</h3>
        <div class="purpose-grid">
            @php
                $purposes = [
                    'Scholarship (SCH)','Local Employment (LE)','Land Matter (LM)','Civil Service Commission (CSC)',
                    'NAPOLCOM Requirement (PNP)','BJMP: Age Waiver (AW)','BuCor: Age Waiver (AW)','BFP: Age Waiver (AW)',
                    'AFP: Age Waiver (AW)','IPMR (IPMR)','Cert. of Tribal Marriage (CTM)','Travel Abroad (TA)'
                ];
                $selectedPurposes = $step1['purpose'] ?? [];
            @endphp
            @foreach($purposes as $index => $p)
                <label><input type="checkbox" {{ in_array($p, $selectedPurposes) ? 'checked' : '' }} disabled> {{ $index+1 }}. {{ $p }}</label>
            @endforeach
            <label>Others: <input type="text" value="{{ $step1['purpose_others'] ?? '' }}" readonly></label>
        </div>
    </div>
    <h2>I. Personal Information</h2>
    <div class="grid-2">
        <div><label>First Name</label><input type="text" value="{{ $step1['first_name'] ?? '' }}" readonly></div>
        <div><label>Last Name</label><input type="text" value="{{ $step1['last_name'] ?? '' }}" readonly></div>
    </div>
    <div class="grid-3">
        <div><label>Sex</label><input type="text" value="{{ $step1['sex'] ?? '' }}" readonly></div>
        <div><label>Civil Status</label><input type="text" value="{{ $step1['civil_status'] ?? '' }}" readonly></div>
        <div><label>Place of Origin</label><input type="text" value="{{ $step1['place_origin'] ?? '' }}" readonly></div>
    </div>
    <div class="spouse-section">
        <p>If married, provide the name of your spouse. If not married, indicate N/A.</p>
        <div class="grid-2">
            <div><label>First Name</label><input type="text" value="{{ $step1['spouse_first_name'] ?? 'N/A' }}" readonly></div>
            <div><label>Last Name</label><input type="text" value="{{ $step1['spouse_last_name'] ?? 'N/A' }}" readonly></div>
        </div>
    </div>
    <h3>II. Educational Background</h3>
    <div class="grid-2">
        <div><label>Highest Educational Attainment</label><input type="text" value="{{ $step2['educational_attainment'] ?? '' }}" readonly></div>
        <div><label>Degree Obtained</label><input type="text" value="{{ $step2['degree_obtained'] ?? '' }}" readonly></div>
    </div>
    <h3>III. Parental Background</h3>
    <table>
        <thead>
            <tr><th>Details</th><th>Father</th><th>Mother(Maiden name)</th></tr>
        </thead>
        <tbody>
            <tr><td>Name</td><td>{{ $step2['father_name'] ?? '' }}</td><td>{{ $step2['mother_name'] ?? '' }}</td></tr>
            <tr><td>IP Group</td><td>{{ $step2['father_ipgroup'] ?? '' }}</td><td>{{ $step2['mother_ipgroup'] ?? '' }}</td></tr>
            <tr><td>Place Origin</td><td>{{ $step2['father_origin'] ?? '' }}</td><td>{{ $step2['mother_origin'] ?? '' }}</td></tr>
            <tr><td>Grandfather</td><td>{{ ($step2['paternal_grandfather_first_name'] ?? '') . ' ' . ($step2['paternal_grandfather_last_name'] ?? '') }}</td><td>{{ ($step2['maternal_grandfather_first_name'] ?? '') . ' ' . ($step2['maternal_grandfather_last_name'] ?? '') }}</td></tr>
            <tr><td>IP Group</td><td>{{ $step2['paternal_grandfather_ipgroup'] ?? '' }}</td><td>{{ $step2['maternal_grandfather_ipgroup'] ?? '' }}</td></tr>
            <tr><td>Place Origin</td><td>{{ $step2['paternal_grandfather_origin'] ?? '' }}</td><td>{{ $step2['maternal_grandfather_origin'] ?? '' }}</td></tr>
            <tr><td>Grandmother</td><td>{{ ($step2['paternal_grandmother_first_name'] ?? '') . ' ' . ($step2['paternal_grandmother_last_name'] ?? '') }}</td><td>{{ ($step2['maternal_grandmother_first_name'] ?? '') . ' ' . ($step2['maternal_grandmother_last_name'] ?? '') }}</td></tr>
            <tr><td>IP Group</td><td>{{ $step2['paternal_grandmother_ipgroup'] ?? '' }}</td><td>{{ $step2['maternal_grandmother_ipgroup'] ?? '' }}</td></tr>
            <tr><td>Place Origin</td><td>{{ $step2['paternal_grandmother_origin'] ?? '' }}</td><td>{{ $step2['maternal_grandmother_origin'] ?? '' }}</td></tr>
        </tbody>
    </table>
    <div class="land-section">
        <label><input type="checkbox" disabled> If Purpose is Land Matter fill up the following:</label>
        <p>Homestead/Free Patent No. <span class="underline">{{ $step2['homestead_no'] ?? '' }}</span> Lot No. <span class="underline">{{ $step2['lot_no'] ?? '' }}</span></p>
        <p>Date of Issuance <span class="underline">{{ $step2['issuance_date'] ?? '' }}</span> Area <span class="underline">{{ $step2['area'] ?? '' }}</span></p>
        <p>Location <span class="underline" style="min-width:300px">{{ $step2['location'] ?? '' }}</span></p>
    </div>
    <h3>III. Applicant Pledge</h3>
    <div class="pledge">
        <p>I, {{ $step2['applicant_name'] ?? $application->user->first_name ?? '' }}, do solemnly swear that all data given in the above information are true and correct to the best of my knowledge and based on authentic records.</p>
        <p>I understand that any false information is enough to cause the denial of my application and could subject me to CRIMINAL and/or ADMINISTRATIVE prosecution.</p>
    </div>
    </div>
    <div class="form-box">
        <div class="paper-container">
            <div class="paper shadow p-5 bg-white">       
               <div class="title-form"><h2>GENEALOGY FORM</h2></div>
                <h3>IV. Genealogy - Father's Side</h3>

                <table>
                    <thead>
                        <tr>
                            <th>Relation</th>
                            <th>Full Name</th>
                            <th>Place of Origin</th>
                            <th>IP Group</th>
                        </tr>
                    </thead>
                    <tbody>
                        {{-- Applicant --}}
                        <tr>
                            <td>Applicant</td>
                            <td>{{ ($step3['applicant_first_name'] ?? '') . ' ' . ($step3['applicant_last_name'] ?? '') }}</td>
                            <td>{{ $step3['applicant_origin'] ?? '' }}</td>
                            <td>{{ $step3['applicant_ipgroup'] ?? '' }}</td>
                        </tr>
                        {{-- Father --}}
                        <tr>
                            <td>Father</td>
                            <td>{{ ($step3['father_first_name'] ?? '') . ' ' . ($step3['father_last_name'] ?? '') }}</td>
                            <td>{{ $step3['father_origin'] ?? '' }}</td>
                            <td>{{ $step3['father_ipgroup'] ?? '' }}</td>
                        </tr>
                        {{-- Paternal Grandfather --}}
                        <tr>
                            <td>Grandfather (Father's Side)</td>
                            <td>{{ ($step3['paternal_grandfather_first_name'] ?? '') . ' ' . ($step3['paternal_grandfather_last_name'] ?? '') }}</td>
                            <td>{{ $step3['paternal_grandfather_origin'] ?? '' }}</td>
                            <td>{{ $step3['paternal_grandfather_ipgroup'] ?? '' }}</td>
                        </tr>
                        {{-- Paternal Grandmother --}}
                        <tr>
                            <td>Grandmother (Father's Side)</td>
                            <td>{{ ($step3['paternal_grandmother_first_name'] ?? '') . ' ' . ($step3['paternal_grandmother_last_name'] ?? '') }}</td>
                            <td>{{ $step3['paternal_grandmother_origin'] ?? '' }}</td>
                            <td>{{ $step3['paternal_grandmother_ipgroup'] ?? '' }}</td>
                        </tr>
                        {{-- Great Grandparents - Father Side --}}
                        <tr>
                            <td>Great Grandfather (Grandfather's Father)</td>
                            <td>{{ ($step3['great_grandfather_grandfather_first_name'] ?? '') . ' ' . ($step3['great_grandfather_grandfather_last_name'] ?? '') }}</td>
                            <td>{{ $step3['great_grandfather_grandfather_origin'] ?? '' }}</td>
                            <td>{{ $step3['great_grandfather_grandfather_ipgroup'] ?? '' }}</td>
                        </tr>
                        <tr>
                            <td>Great Grandmother (Grandfather's Mother)</td>
                            <td>{{ ($step3['great_grandmother_grandfather_first_name'] ?? '') . ' ' . ($step3['great_grandmother_grandfather_last_name'] ?? '') }}</td>
                            <td>{{ $step3['great_grandmother_grandfather_origin'] ?? '' }}</td>
                            <td>{{ $step3['great_grandmother_grandfather_ipgroup'] ?? '' }}</td>
                        </tr>
                        <tr>
                            <td>Great Grandfather (Grandmother's Father)</td>
                            <td>{{ ($step3['great_grandfather_grandmother_first_name'] ?? '') . ' ' . ($step3['great_grandfather_grandmother_last_name'] ?? '') }}</td>
                            <td>{{ $step3['great_grandfather_grandmother_origin'] ?? '' }}</td>
                            <td>{{ $step3['great_grandfather_grandmother_ipgroup'] ?? '' }}</td>
                        </tr>
                        <tr>
                            <td>Great Grandmother (Grandmother's Mother)</td>
                            <td>{{ ($step3['great_grandmother_grandmother_first_name'] ?? '') . ' ' . ($step3['great_grandmother_grandmother_last_name'] ?? '') }}</td>
                            <td>{{ $step3['great_grandmother_grandmother_origin'] ?? '' }}</td>
                            <td>{{ $step3['great_grandmother_grandmother_ipgroup'] ?? '' }}</td>
                        </tr>
                    </tbody>
                </table>
            <h3>V. Genealogy - Mother's Side</h3>

            <table>
                <thead>
                    <tr>
                        <th>Relation</th>
                        <th>Full Name</th>
                        <th>Place of Origin</th>
                        <th>IP Group</th>
                    </tr>
                </thead>
                <tbody>
                    {{-- Mother --}}
                    <tr>
                        <td>Mother</td>
                        <td>{{ ($step4['mother_first_name'] ?? '') . ' ' . ($step4['mother_last_name'] ?? '') }}</td>
                        <td>{{ $step4['mother_origin'] ?? '' }}</td>
                        <td>{{ $step4['mother_ipgroup'] ?? '' }}</td>
                    </tr>
                    {{-- Maternal Grandfather --}}
                    <tr>
                        <td>Grandfather (Mother's Side)</td>
                        <td>{{ ($step4['maternal_grandfather_first_name'] ?? '') . ' ' . ($step4['maternal_grandfather_last_name'] ?? '') }}</td>
                        <td>{{ $step4['maternal_grandfather_origin'] ?? '' }}</td>
                        <td>{{ $step4['maternal_grandfather_ipgroup'] ?? '' }}</td>
                    </tr>
                    {{-- Maternal Grandmother --}}
                    <tr>
                        <td>Grandmother (Mother's Side)</td>
                        <td>{{ ($step4['maternal_grandmother_first_name'] ?? '') . ' ' . ($step4['maternal_grandmother_last_name'] ?? '') }}</td>
                        <td>{{ $step4['maternal_grandmother_origin'] ?? '' }}</td>
                        <td>{{ $step4['maternal_grandmother_ipgroup'] ?? '' }}</td>
                    </tr>
                    {{-- Great Grandparents - Mother Side --}}
                    <tr>
                        <td>Great Grandfather (Grandfather's Father)</td>
                        <td>{{ ($step4['great_grandfather_grandfather_mother_first_name'] ?? '') . ' ' . ($step4['great_grandfather_grandfather_mother_last_name'] ?? '') }}</td>
                        <td>{{ $step4['great_grandfather_grandfather_mother_origin'] ?? '' }}</td>
                        <td>{{ $step4['great_grandfather_grandfather_mother_ipgroup'] ?? '' }}</td>
                    </tr>
                    <tr>
                        <td>Great Grandmother (Grandfather's Mother)</td>
                        <td>{{ ($step4['great_grandmother_grandfather_mother_first_name'] ?? '') . ' ' . ($step4['great_grandmother_grandfather_mother_last_name'] ?? '') }}</td>
                        <td>{{ $step4['great_grandmother_grandfather_mother_origin'] ?? '' }}</td>
                        <td>{{ $step4['great_grandmother_grandfather_mother_ipgroup'] ?? '' }}</td>
                    </tr>
                    <tr>
                        <td>Great Grandfather (Grandmother's Father)</td>
                        <td>{{ ($step4['great_grandfather_grandmother_mother_first_name'] ?? '') . ' ' . ($step4['great_grandfather_grandmother_mother_last_name'] ?? '') }}</td>
                        <td>{{ $step4['great_grandfather_grandmother_mother_origin'] ?? '' }}</td>
                        <td>{{ $step4['great_grandfather_grandmother_mother_ipgroup'] ?? '' }}</td>
                    </tr>
                    <tr>
                        <td>Great Grandmother (Grandmother's Mother)</td>
                        <td>{{ ($step4['great_grandmother_grandmother_mother_first_name'] ?? '') . ' ' . ($step4['great_grandmother_grandmother_mother_last_name'] ?? '') }}</td>
                        <td>{{ $step4['great_grandmother_grandmother_mother_origin'] ?? '' }}</td>
                        <td>{{ $step4['great_grandmother_grandmother_mother_ipgroup'] ?? '' }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="form-box">
    <div class="paper-container">
        <div class="paper shadow p-5 bg-white">
                   <div class="documents-list">

                {{-- Applicant Photo --}}
                <div class="doc-item mb-3">
                    <span class="doc-label fw-bold">Applicant Photo:</span>
                    @if(!empty($application->applicant_picture))
                        <a href="{{ asset('storage/'.$application->applicant_picture) }}" target="_blank" class="view-btn btn btn-outline-primary btn-sm ms-2">View</a>
                    @else
                        <span class="text-muted ms-2">No applicant photo uploaded</span>
                    @endif
                </div>

           {{-- Birth Certificate --}}
                <div class="doc-item mb-3">
                    <span class="doc-label fw-bold">Birth Certificate:</span>
                   @if($ipAccount && $ipAccount->document_path)
                            <a href="{{ asset('storage/' . $ipAccount->document_path) }}" target="_blank"class="view-btn btn btn-outline-primary btn-sm ms-2">
                                View
                            </a>
                        @else
                            <p>No birth certificate uploaded yet.</p>
                        @endif                                   
                </div>
                            

                {{-- Signature --}}
                <div class="doc-item mb-3">
                    <span class="doc-label fw-bold">Applicant Signature:</span>
                    @if(!empty($application->signature))
                        <a href="{{ asset('storage/'.$application->signature) }}" target="_blank" class="view-btn btn btn-outline-primary btn-sm ms-2">View</a>
                    @else
                        <span class="text-muted ms-2">No signature uploaded</span>
                    @endif
                </div>

                {{-- Tribal Certificate --}}
                <div class="doc-item mb-3">
                    <span class="doc-label fw-bold">Certificate of Tribal Chieftain:</span>
                    @if(!empty($application->tribal_certificate))
                        <a href="{{ asset('storage/'.$application->tribal_certificate) }}" target="_blank" class="view-btn btn btn-outline-primary btn-sm ms-2">View</a>
                    @else
                        <span class="text-muted ms-2">No certificate uploaded</span>
                    @endif
                </div>
                {{-- Genealogy Form --}}
                <div class="doc-item mb-3">
                    <span class="doc-label fw-bold">Genealogy Form:</span>
                    @if(!empty($application->genealogy_form))
                        <a href="{{ asset('storage/'.$application->genealogy_form) }}" target="_blank" class="view-btn btn btn-outline-primary btn-sm ms-2">View</a>
                    @else
                        <span class="text-muted ms-2">No genealogy form uploaded</span>
                    @endif
                </div>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                <a href="{{ url()->previous() }}" class="btn btn-secondary">
                    ← Back
                </a>
                <form action="{{ route('applicant.coc.submit', $application->id) }}" method="POST">
                    @csrf
                    <button type="submit" class="btn btn-primary">
                        Submit
                    </button>
                </form>
            </div>

            </div>
        </div>
    </div>
</div>

@endsection
