@extends('layouts.applicant')

@section('title', 'COC Form')
@section('page-title', 'NCIP COC Form 2')

@section('content')
    @include('applicant.coc.progress-circle', ['currentStep' => 2])
    <div class="container py-4 d-flex justify-content-center">
        <div class="paper-container">
            <div class="paper shadow p-5 bg-white">
                <h2 class="fw-bold mb-3 text-center">NATIONAL COMMISSION ON INDIGENOUS PEOPLES</h2>
                <p class="text-center mb-4">
                    <strong>Direction:</strong> The information below will be used to fill out Certificate of Confirmation.<br>
                    Please fill out this form as completely and accurately as possible.
                </p>

                <form action="{{ route('applicant.coc.step2.store') }}" method="POST">
                    @csrf

                    {{-- Educational Background --}}
                    <div class="mb-4 p-3 border rounded">
                        <h4 class="fw-bold mb-3">II. Educational Background</h4>
                        <div class="mb-3">
                            <label class="form-label">Highest Educational Attainment:</label>
                            <select name="educational_attainment" class="form-control" required>
                                <option value="">-- Select Educational Attainment --</option>
                                <option value="Elementary" {{ old('educational_attainment', $step2['educational_attainment'] ?? '') == 'Elementary' ? 'selected' : '' }}>Elementary</option>
                                <option value="High School" {{ old('educational_attainment', $step2['educational_attainment'] ?? '') == 'High School' ? 'selected' : '' }}>High School</option>
                                <option value="College" {{ old('educational_attainment', $step2['educational_attainment'] ?? '') == 'College' ? 'selected' : '' }}>College</option>
                                <option value="Post Graduate" {{ old('educational_attainment', $step2['educational_attainment'] ?? '') == 'Post Graduate' ? 'selected' : '' }}>Post Graduate</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Degree Obtained:</label>
                            <input type="text" name="degree_obtained" class="form-control"
                                   placeholder="Enter your degree (if any)"
                                   value="{{ old('degree_obtained', $step2['degree_obtained'] ?? '') }}">
                        </div>
                    </div>

                    {{-- Parental Background --}}
                    <div class="mb-4 p-3 border rounded">
                        <h4 class="fw-bold mb-3">III. Parental Background</h4>
                        <table class="table table-bordered text-sm mb-0">
                            <thead class="table-light text-center">
                                <tr>
                                    <th>Father</th>
                                    <th>Mother (Maiden Name)</th>
                                </tr>
                            </thead>
                            <tbody>
                                {{-- Parents --}}
                                <tr>
                                    <td>
                                        <label class="form-label">Father's Name:</label>
                                        <input type="text" name="father_name" class="form-control"
                                               placeholder="Enter father's full name"
                                               value="{{ old('father_name', $step2['father_name'] ?? '') }}">
                                    </td>
                                    <td>
                                        <label class="form-label">Mother's Name:</label>
                                        <input type="text" name="mother_name" class="form-control"
                                               placeholder="Enter mother's maiden name"
                                               value="{{ old('mother_name', $step2['mother_name'] ?? '') }}">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="form-label">IP Group:</label>
                                        <input type="text" name="father_ipgroup" class="form-control"
                                               placeholder="Enter father's IP group"
                                               value="{{ old('father_ipgroup', $step2['father_ipgroup'] ?? '') }}">
                                    </td>
                                    <td>
                                        <label class="form-label">IP Group:</label>
                                        <input type="text" name="mother_ipgroup" class="form-control"
                                               placeholder="Enter mother's IP group"
                                               value="{{ old('mother_ipgroup', $step2['mother_ipgroup'] ?? '') }}">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="form-label">Place of Origin:</label>
                                        <input type="text" name="father_origin" class="form-control"
                                               placeholder="Enter father's place of origin"
                                               value="{{ old('father_origin', $step2['father_origin'] ?? '') }}">
                                    </td>
                                    <td>
                                        <label class="form-label">Place of Origin:</label>
                                        <input type="text" name="mother_origin" class="form-control"
                                               placeholder="Enter mother's place of origin"
                                               value="{{ old('mother_origin', $step2['mother_origin'] ?? '') }}">
                                    </td>
                                </tr>

                                {{-- Grandparents --}}
                                <tr class="fw-bold text-center table-secondary">
                                    <td colspan="2">Grandparents</td>
                                </tr>

                                {{-- Grandfathers --}}
                                <tr>
                                    <td>
                                        <label class="form-label">Paternal Grandfather First Name:</label>
                                        <input type="text" name="paternal_grandfather_first_name" class="form-control"
                                               placeholder="Enter first name"
                                               value="{{ old('paternal_grandfather_first_name', $step2['paternal_grandfather_first_name'] ?? '') }}">
                                        <label class="form-label mt-2">Paternal Grandfather Last Name:</label>
                                        <input type="text" name="paternal_grandfather_last_name" class="form-control"
                                               placeholder="Enter last name"
                                               value="{{ old('paternal_grandfather_last_name', $step2['paternal_grandfather_last_name'] ?? '') }}">
                                        <label class="form-label mt-2">IP Group:</label>
                                        <input type="text" name="paternal_grandfather_ipgroup" class="form-control"
                                               placeholder="Enter IP group"
                                               value="{{ old('paternal_grandfather_ipgroup', $step2['paternal_grandfather_ipgroup'] ?? '') }}">
                                        <label class="form-label mt-2">Place of Origin:</label>
                                        <input type="text" name="paternal_grandfather_origin" class="form-control"
                                               placeholder="Enter place of origin"
                                               value="{{ old('paternal_grandfather_origin', $step2['paternal_grandfather_origin'] ?? '') }}">
                                    </td>
                                    <td>
                                        <label class="form-label">Maternal Grandfather First Name:</label>
                                        <input type="text" name="maternal_grandfather_first_name" class="form-control"
                                               placeholder="Enter first name"
                                               value="{{ old('maternal_grandfather_first_name', $step2['maternal_grandfather_first_name'] ?? '') }}">
                                        <label class="form-label mt-2">Maternal Grandfather Last Name:</label>
                                        <input type="text" name="maternal_grandfather_last_name" class="form-control"
                                               placeholder="Enter last name"
                                               value="{{ old('maternal_grandfather_last_name', $step2['maternal_grandfather_last_name'] ?? '') }}">
                                        <label class="form-label mt-2">IP Group:</label>
                                        <input type="text" name="maternal_grandfather_ipgroup" class="form-control"
                                               placeholder="Enter IP group"
                                               value="{{ old('maternal_grandfather_ipgroup', $step2['maternal_grandfather_ipgroup'] ?? '') }}">
                                        <label class="form-label mt-2">Place of Origin:</label>
                                        <input type="text" name="maternal_grandfather_origin" class="form-control"
                                               placeholder="Enter place of origin"
                                               value="{{ old('maternal_grandfather_origin', $step2['maternal_grandfather_origin'] ?? '') }}">
                                    </td>
                                </tr>

                                {{-- Grandmothers --}}
                                <tr>
                                    <td>
                                        <label class="form-label">Paternal Grandmother First Name:</label>
                                        <input type="text" name="paternal_grandmother_first_name" class="form-control"
                                               placeholder="Enter first name"
                                               value="{{ old('paternal_grandmother_first_name', $step2['paternal_grandmother_first_name'] ?? '') }}">
                                        <label class="form-label mt-2">Paternal Grandmother Last Name:</label>
                                        <input type="text" name="paternal_grandmother_last_name" class="form-control"
                                               placeholder="Enter last name"
                                               value="{{ old('paternal_grandmother_last_name', $step2['paternal_grandmother_last_name'] ?? '') }}">
                                        <label class="form-label mt-2">IP Group:</label>
                                        <input type="text" name="paternal_grandmother_ipgroup" class="form-control"
                                               placeholder="Enter IP group"
                                               value="{{ old('paternal_grandmother_ipgroup', $step2['paternal_grandmother_ipgroup'] ?? '') }}">
                                        <label class="form-label mt-2">Place of Origin:</label>
                                        <input type="text" name="paternal_grandmother_origin" class="form-control"
                                               placeholder="Enter place of origin"
                                               value="{{ old('paternal_grandmother_origin', $step2['paternal_grandmother_origin'] ?? '') }}">
                                    </td>
                                    <td>
                                        <label class="form-label">Maternal Grandmother First Name:</label>
                                        <input type="text" name="maternal_grandmother_first_name" class="form-control"
                                               placeholder="Enter first name"
                                               value="{{ old('maternal_grandmother_first_name', $step2['maternal_grandmother_first_name'] ?? '') }}">
                                        <label class="form-label mt-2">Maternal Grandmother Last Name:</label>
                                        <input type="text" name="maternal_grandmother_last_name" class="form-control"
                                               placeholder="Enter last name"
                                               value="{{ old('maternal_grandmother_last_name', $step2['maternal_grandmother_last_name'] ?? '') }}">
                                        <label class="form-label mt-2">IP Group:</label>
                                        <input type="text" name="maternal_grandmother_ipgroup" class="form-control"
                                               placeholder="Enter IP group"
                                               value="{{ old('maternal_grandmother_ipgroup', $step2['maternal_grandmother_ipgroup'] ?? '') }}">
                                        <label class="form-label mt-2">Place of Origin:</label>
                                        <input type="text" name="maternal_grandmother_origin" class="form-control"
                                               placeholder="Enter place of origin"
                                               value="{{ old('maternal_grandmother_origin', $step2['maternal_grandmother_origin'] ?? '') }}">
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    {{-- Land Matter Certification --}}
                    <div class="mb-4 p-3 border rounded">
                        <div class="form-check mb-3">
                            <input type="checkbox" name="land_matter" value="1" class="form-check-input" id="landMatterCheck"
                                   {{ old('land_matter', $step2['land_matter'] ?? '') ? 'checked' : '' }}>
                            <label class="form-check-label" for="landMatterCheck">
                                If purpose of certification is land matter, fill up the following:
                            </label>
                        </div>

                        <div id="landMatterFields" class="row g-3" style="{{ old('land_matter', $step2['land_matter'] ?? '') ? '' : 'display: none;' }}">
                            <div class="col-md-6">
                                <label class="form-label">Homestead/Free Patent No.:</label>
                                <input type="text" name="homestead_no" class="form-control land-matter-input"
                                       placeholder="Enter Homestead or Free Patent No."
                                       value="{{ old('homestead_no', $step2['homestead_no'] ?? '') }}"
                                       {{ old('land_matter', $step2['land_matter'] ?? '') ? '' : 'disabled' }}>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Lot No.:</label>
                                <input type="text" name="lot_no" class="form-control land-matter-input"
                                       placeholder="Enter Lot No."
                                       value="{{ old('lot_no', $step2['lot_no'] ?? '') }}"
                                       {{ old('land_matter', $step2['land_matter'] ?? '') ? '' : 'disabled' }}>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Date of Issuance:</label>
                                <input type="text" name="issuance_date" class="form-control land-matter-input"
                                       placeholder="Enter date of issuance"
                                       value="{{ old('issuance_date', $step2['issuance_date'] ?? '') }}"
                                       {{ old('land_matter', $step2['land_matter'] ?? '') ? '' : 'disabled' }}>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Area:</label>
                                <input type="text" name="area" class="form-control land-matter-input"
                                       placeholder="Enter land area"
                                       value="{{ old('area', $step2['area'] ?? '') }}"
                                       {{ old('land_matter', $step2['land_matter'] ?? '') ? '' : 'disabled' }}>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Location:</label>
                                <input type="text" name="location" class="form-control land-matter-input"
                                       placeholder="Enter land location"
                                       value="{{ old('location', $step2['location'] ?? '') }}"
                                       {{ old('land_matter', $step2['land_matter'] ?? '') ? '' : 'disabled' }}>
                            </div>
                        </div>
                    </div>

                    {{-- Applicant Pledge --}}
                    <div class="mb-4 p-3 border rounded">
                        <h4 class="fw-bold mb-3">IV. Applicant Pledge</h4>
                        <p>
                            I 
                            <input type="text" name="applicant_name" class="border rounded px-2 py-1"
                                   placeholder="Enter your name"
                                   value="{{ old('applicant_name', $step2['applicant_name'] ?? $user->first_name) }}">
                            do solemnly swear that all data given in the above information are true and correct.
                        </p>
                        <div class="mb-3">
                            <label class="form-label">Date of Accomplishment:</label>
                            <input type="date" name="date_accomplishment" class="form-control"
                                   value="{{ old('date_accomplishment', $step2['date_accomplishment'] ?? '') }}">
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="{{ route('applicant.coc.step1') }}" class="btn btn-secondary">Back</a>
                        @if(
                            $application->status === 'Returned' && 
                            $application->index_status === 'returned' &&
                            empty($application->genealogy_status) &&
                            empty($application->documents_status)
                        )
                        <div>
                            <button type="submit" class="btn btn-primary w-100 mt-3">
                                <i class="fas fa-paper-plane me-2"></i> Resubmit Application
                            </button>
                        </div>
                        @else
                            <div>
                             <button type="submit" class="btn btn-primary">Next</button>
                            </div>
                        @endif
                    </div>
                </form>
            </div>
        </div>
    </div>

    @push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const landMatterCheck = document.getElementById('landMatterCheck');
            const landMatterFields = document.getElementById('landMatterFields');
            const landMatterInputs = document.querySelectorAll('.land-matter-input');

            function toggleLandMatterFields() {
                if (landMatterCheck.checked) {
                    landMatterFields.style.display = 'block';
                    landMatterInputs.forEach(input => {
                        input.disabled = false;
                    });
                } else {
                    landMatterFields.style.display = 'none';
                    landMatterInputs.forEach(input => {
                        input.disabled = true;
                        // Optional: Clear values when disabled
                        input.value = '';
                    });
                }
            }

            // Initial state
            toggleLandMatterFields();

            // Add event listener
            landMatterCheck.addEventListener('change', toggleLandMatterFields);
        });
    </script>
    @endpush
@endsection