@extends('layouts.applicant')

@section('title', 'COC Form')
@section('page-title', 'NCIP COC Form 4')

@section('content')
       @include('applicant.coc.progress-circle', ['currentStep' => 4])
<div class="container py-4 d-flex justify-content-center">
    <div class="paper-container">
        <div class="paper shadow p-5 bg-white">
    

            <h2 class="fw-bold mb-3 text-center">NCIP COC Form 4 (Genealogy - Mother Side)</h2>

            <form action="{{ route('applicant.coc.step4.store', ['id' => $step4['id'] ?? null]) }}" method="POST">
                @csrf

                {{-- Full Name of Applicant's Mother --}}
                <div class="mb-4">
                    <h5 class="fw-bold">Applicant Mother</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">First Name</label>
                            <input type="text" name="mother_first_name" class="form-control" placeholder="First name"
                                   value="{{ old('mother_first_name', $step4['mother_first_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="mother_last_name" class="form-control" placeholder="Last name"
                                   value="{{ old('mother_last_name', $step4['mother_last_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Place of Origin</label>
                            <input type="text" name="mother_origin" class="form-control" placeholder="Place origin"
                                   value="{{ old('mother_origin', $step4['mother_origin'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">IP Group</label>
                            <input type="text" name="mother_ipgroup" class="form-control" placeholder="IP group"
                                   value="{{ old('mother_ipgroup', $step4['mother_ipgroup'] ?? '') }}">
                        </div>
                    </div>
                </div>
                
                {{-- Maternal Grandfather --}}
                <div class="mb-4">
                    <h5 class="fw-bold">Grandfather (Mother’s Side)</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">First Name</label>
                            <input type="text" name="maternal_grandfather_first_name" class="form-control"
                                   placeholder="Enter first name"
                                   value="{{ old('maternal_grandfather_first_name', $step4['maternal_grandfather_first_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="maternal_grandfather_last_name" class="form-control"
                                   placeholder="Enter last name"
                                   value="{{ old('maternal_grandfather_last_name', $step4['maternal_grandfather_last_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Place of Origin</label>
                            <input type="text" name="maternal_grandfather_origin" class="form-control"
                                   placeholder="Enter place of origin"
                                   value="{{ old('maternal_grandfather_origin', $step4['maternal_grandfather_origin'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">IP Group</label>
                            <input type="text" name="maternal_grandfather_ipgroup" class="form-control"
                                   placeholder="Enter IP group"
                                   value="{{ old('maternal_grandfather_ipgroup', $step4['maternal_grandfather_ipgroup'] ?? '') }}">
                        </div>
                    </div>
                </div>
                
                {{-- Maternal Grandmother --}}
                <div class="mb-4">
                    <h5 class="fw-bold">Grandmother (Mother’s Side)</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">First Name</label>
                            <input type="text" name="maternal_grandmother_first_name" class="form-control"
                                   placeholder="Enter first name"
                                   value="{{ old('maternal_grandmother_first_name', $step4['maternal_grandmother_first_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="maternal_grandmother_last_name" class="form-control"
                                   placeholder="Enter last name"
                                   value="{{ old('maternal_grandmother_last_name', $step4['maternal_grandmother_last_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Place of Origin</label>
                            <input type="text" name="maternal_grandmother_origin" class="form-control"
                                   placeholder="Enter place of origin"
                                   value="{{ old('maternal_grandmother_origin', $step4['maternal_grandmother_origin'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">IP Group</label>
                            <input type="text" name="maternal_grandmother_ipgroup" class="form-control"
                                   placeholder="Enter IP group"
                                   value="{{ old('maternal_grandmother_ipgroup', $step4['maternal_grandmother_ipgroup'] ?? '') }}">
                        </div>
                    </div>
                </div>
                

                {{-- Great Grandparents (Mother Side) --}}
                <div class="mb-4">
                    <h5 class="fw-bold">Great Grandfather (Grandfather’s Father)</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">First Name</label>
                            <input type="text" name="great_grandfather_grandfather_mother_first_name" class="form-control"
                                   placeholder="Enter first name"
                                   value="{{ old('great_grandfather_grandfather_mother_first_name', $step4['great_grandfather_grandfather_mother_first_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="great_grandfather_grandfather_mother_last_name" class="form-control"
                                   placeholder="Enter last name"
                                   value="{{ old('great_grandfather_grandfather_mother_last_name', $step4['great_grandfather_grandfather_mother_last_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Place of Origin</label>
                            <input type="text" name="great_grandfather_grandfather_mother_origin" class="form-control"
                                   placeholder="Enter place of origin"
                                   value="{{ old('great_grandfather_grandfather_mother_origin', $step4['great_grandfather_grandfather_mother_origin'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">IP Group</label>
                            <input type="text" name="great_grandfather_grandfather_mother_ipgroup" class="form-control"
                                   placeholder="Enter IP group"
                                   value="{{ old('great_grandfather_grandfather_mother_ipgroup', $step4['great_grandfather_grandfather_mother_ipgroup'] ?? '') }}">
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <h5 class="fw-bold">Great Grandmother (Grandfather’s Mother)</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">First Name</label>
                            <input type="text" name="great_grandmother_grandfather_mother_first_name" class="form-control"
                                   placeholder="Enter first name"
                                   value="{{ old('great_grandmother_grandfather_mother_first_name', $step4['great_grandmother_grandfather_mother_first_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="great_grandmother_grandfather_mother_last_name" class="form-control"
                                   placeholder="Enter last name"
                                   value="{{ old('great_grandmother_grandfather_mother_last_name', $step4['great_grandmother_grandfather_mother_last_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Place of Origin</label>
                            <input type="text" name="great_grandmother_grandfather_mother_origin" class="form-control"
                                   placeholder="Enter place of origin"
                                   value="{{ old('great_grandmother_grandfather_mother_origin', $step4['great_grandmother_grandfather_mother_origin'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">IP Group</label>
                            <input type="text" name="great_grandmother_grandfather_mother_ipgroup" class="form-control"
                                   placeholder="Enter IP group"
                                   value="{{ old('great_grandmother_grandfather_mother_ipgroup', $step4['great_grandmother_grandfather_mother_ipgroup'] ?? '') }}">
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <h5 class="fw-bold">Great Grandfather (Grandmother’s Father)</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">First Name</label>
                            <input type="text" name="great_grandfather_grandmother_mother_first_name" class="form-control"
                                   placeholder="Enter first name"
                                   value="{{ old('great_grandfather_grandmother_mother_first_name', $step4['great_grandfather_grandmother_mother_first_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="great_grandfather_grandmother_mother_last_name" class="form-control"
                                   placeholder="Enter last name"
                                   value="{{ old('great_grandfather_grandmother_mother_last_name', $step4['great_grandfather_grandmother_mother_last_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Place of Origin</label>
                            <input type="text" name="great_grandfather_grandmother_mother_origin" class="form-control"
                                   placeholder="Enter place of origin"
                                   value="{{ old('great_grandfather_grandmother_mother_origin', $step4['great_grandfather_grandmother_mother_origin'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">IP Group</label>
                            <input type="text" name="great_grandfather_grandmother_mother_ipgroup" class="form-control"
                                   placeholder="Enter IP group"
                                   value="{{ old('great_grandfather_grandmother_mother_ipgroup', $step4['great_grandfather_grandmother_mother_ipgroup'] ?? '') }}">
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <h5 class="fw-bold">Great Grandmother (Grandmother’s Mother)</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">First Name</label>
                            <input type="text" name="great_grandmother_grandmother_mother_first_name" class="form-control"
                                   placeholder="Enter first name"
                                   value="{{ old('great_grandmother_grandmother_mother_first_name', $step4['great_grandmother_grandmother_mother_first_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="great_grandmother_grandmother_mother_last_name" class="form-control"
                                   placeholder="Enter last name"
                                   value="{{ old('great_grandmother_grandmother_mother_last_name', $step4['great_grandmother_grandmother_mother_last_name'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Place of Origin</label>
                            <input type="text" name="great_grandmother_grandmother_mother_origin" class="form-control"
                                   placeholder="Enter place of origin"
                                   value="{{ old('great_grandmother_grandmother_mother_origin', $step4['great_grandmother_grandmother_mother_origin'] ?? '') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">IP Group</label>
                            <input type="text" name="great_grandmother_grandmother_mother_ipgroup" class="form-control"
                                   placeholder="Enter IP group"
                                   value="{{ old('great_grandmother_grandmother_mother_ipgroup', $step4['great_grandmother_grandmother_mother_ipgroup'] ?? '') }}">
                        </div>
                    </div>
                    {{-- Notice for downloading and printing PDF --}}
                <div class="alert alert-warning text-center fw-bold">
                    <i class="fas fa-info-circle me-2"></i>
                    Please <span class="text-decoration-underline">download and print</span> the Genealogy Form before proceeding to Step 5. You will need to upload the completed PDF in the next step.
                </div>
                <div class="mt-4 text-center">
                    <a href="{{ asset('docs/COC-Genealogy-Form-Template-2025.pdf') }}" 
                    class="btn btn-success" 
                    download="COC-Genealogy-Form-Template-2025.pdf">
                        <i class="fas fa-download me-2"></i> Download Genealogy Form
                    </a>
                </div>

                </div>
                {{-- Buttons --}}
                <div class="d-flex justify-content-between mt-4">
                    <a href="{{ route('applicant.coc.step3') }}" class="btn btn-secondary">Back</a>

                    @if(
                        $application->status === 'Returned' && 
                        $application->genealogy_status === 'returned' &&
                        empty($application->index_status) &&
                        empty($application->documents_status)
                    )
                        <button type="submit" class="btn btn-primary w-100 mt-3">
                            <i class="fas fa-paper-plane me-2"></i> Resubmit Application
                        </button>
                    @else
                         <div>
                         <button type="submit" class="btn btn-primary">Next</button>
                        </div>
                    @endif
                </div>

            </form>
            </form>
        </div>
    </div>
</div>
@endsection
