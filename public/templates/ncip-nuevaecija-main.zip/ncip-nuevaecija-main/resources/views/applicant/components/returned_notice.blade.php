
@if($application && $application->status === 'Returned')
@php
    // Default to step1 if no returned_step in session
    $step = session('returned_step', 1);
@endphp

<div class="container mt-4">
    <div class="status-card shadow-card p-3 rounded" style="border-left: 4px solid #dc3545; background-color: #fff3f3;">
        <div class="notice-header fw-bold text-danger mb-2">
            ⚠️ Document / Form Resubmission Required
        </div>
        @if($application->index_status === 'returned' && $application->index_remarks)
            <div class="mb-2">
                <strong>Index Form Remarks:</strong>
                <p class="mb-0 ms-2 text-dark">{{ $application->index_remarks }}</p>
            </div>
        @endif
        @if($application->genealogy_status === 'returned' && $application->genealogy_remarks)
            <div class="mb-2">
                <strong>Genealogy Form Remarks:</strong>
                <p class="mb-0 ms-2 text-dark">{{ $application->genealogy_remarks }}</p>
            </div>
        @endif
        @if($application->documents_status === 'returned' && $application->documents_remarks)
            <div class="mb-2">
                <strong>Documents Remarks:</strong>
                <p class="mb-0 ms-2 text-dark">{{ $application->documents_remarks }}</p>
            </div>
        @endif
        <div class="notice-body mb-3 text-muted small">
            Please review the remarks above, update the necessary information or documents, and resubmit your application.
        </div>
        <div class="resubmit-container mt-2">
            <a href="{{ route('applicant.coc.resubmit.step', ['step' => $step, 'application' => $application->id]) }}" 
               class="btn btn-danger w-100">
                Resubmit
            </a>
        </div>

    </div>
</div>
@endif
