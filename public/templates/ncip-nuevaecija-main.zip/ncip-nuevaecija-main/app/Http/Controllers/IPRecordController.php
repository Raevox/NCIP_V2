<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\IPRecord;
use App\Models\User;
use App\Models\IpAccount; // 🔹 For archived applicants
use Illuminate\Support\Facades\Response;
use Barryvdh\DomPDF\Facade\Pdf; // Install: composer require barryvdh/laravel-dompdf
use setasign\Fpdi\Fpdi;

class IPRecordController extends Controller
{
    // -------------------- Listing IP Records --------------------
    public function index(Request $request)
    {
        $query = IPRecord::query();

        if ($request->filled('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('first_name', 'like', '%' . $request->search . '%')
                  ->orWhere('last_name', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->filled('municipality')) {
            $query->where('municipality', $request->municipality);
        }

        if ($request->filled('ip_group')) {
            $query->where('ip_group', $request->ip_group);
        }

        $records = $query->paginate(10);
        $municipalities = IPRecord::select('municipality')->distinct()->whereNotNull('municipality')->orderBy('municipality')->pluck('municipality');
        $ipGroups = IPRecord::select('ip_group')->distinct()->whereNotNull('ip_group')->orderBy('ip_group')->pluck('ip_group');

        return view('admin.ip_records.index', compact('records', 'municipalities', 'ipGroups'));
    }

    // -------------------- Archive / Soft Delete --------------------
    public function archive($id)
    {
        $record = IPRecord::findOrFail($id);
        $record->delete(); // Soft delete

        return redirect()->route('admin.archive.ip_records')
            ->with('success', 'IP Record archived successfully.');
    }

    // -------------------- Restore Archived Record --------------------
    public function restore($id)
    {
        $record = IPRecord::onlyTrashed()->findOrFail($id);
        $record->restore();

        return redirect()->route('admin.archive.ip_records')
            ->with('success', 'IP Record restored successfully.');
    }

    // -------------------- View All Archived Records --------------------
 // Show all archived IP records
public function archivedRecords()
{
    $records = IPRecord::onlyTrashed()->paginate(10);
    $staffAdminAccounts = User::onlyTrashed()
                              ->whereIn('role', ['admin','staff'])
                              ->paginate(10, ['*'], 'staffAdminPage');
    $ipAccounts = IpAccount::onlyTrashed()->paginate(10, ['*'], 'ipPage');

    // Gamitin existing tabbed archive view
    return view('admin.accounts.archive', compact('records', 'staffAdminAccounts', 'ipAccounts'));
}



    // -------------------- CRUD Methods --------------------
    public function create()
    {
        return view('admin.ip_records.create');
    }

   public function store(Request $request)
{
    $validated = $this->validateRecord($request);

    if ($request->hasFile('image')) {
        $filename = time() . '_' . $request->file('image')->getClientOriginalName();
        $validated['image'] = $request->file('image')->storeAs('uploads/images', $filename, 'public');
    }

    // ✅ Add this line
    $validated['name'] = $validated['first_name'] . ' ' . $validated['last_name'];

    IPRecord::create($validated);

    return redirect()->route('ip_records.index')->with('success', 'IP Record added successfully.');
}

public function update(Request $request, $id)
{
    $record = IPRecord::findOrFail($id);
    $validated = $this->validateRecord($request);

    if ($request->hasFile('image')) {
        $filename = time() . '_' . $request->file('image')->getClientOriginalName();
        $validated['image'] = $request->file('image')->storeAs('uploads/images', $filename, 'public');
    }

    // ✅ Add this line
    $validated['name'] = $validated['first_name'] . ' ' . $validated['last_name'];

    $record->update($validated);

    return redirect()->route('ip_records.index')->with('success', 'IP Record updated successfully.');
}

    public function destroy($id)
    {
        $record = IPRecord::findOrFail($id);
        $record->delete(); // Soft delete

        return redirect()->route('ip_records.index')->with('success', 'IP Record moved to archive.');
    }

    // -------------------- Download CSV --------------------
    public function download(Request $request)
    {
        $query = IPRecord::query();

        if ($request->filled('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('first_name', 'like', '%' . $request->search . '%')
                  ->orWhere('last_name', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->filled('municipality')) {
            $query->where('municipality', $request->municipality);
        }

        if ($request->filled('ip_group')) {
            $query->where('ip_group', $request->ip_group);
        }

        $records = $query->get();

        $filename = "ip_records_export.csv";
        $headers = [
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=$filename",
        ];

        $callback = function () use ($records) {
            $file = fopen('php://output', 'w');
            fputcsv($file, [
                'First Name', 'Last Name', 'Sex', 'IP Group',
                'Birth Date', 'Origin Province', 'Origin Municipality', 'Origin Barangay',
                'Province', 'Municipality', 'Barangay', 'Census Date',
                'Civil Status', 'Religion', 'NCIP Number', 'Occupation',
                'Income', 'PWD', 'Educational Level', 'Degree'
            ]);

            foreach ($records as $row) {
                fputcsv($file, [
                    $row->first_name,
                    $row->last_name,
                    $row->sex,
                    $row->ip_group,
                    $row->birth_date,
                    $row->origin_province,
                    $row->origin_municipality,
                    $row->origin_barangay,
                    $row->province,
                    $row->municipality,
                    $row->barangay,
                    $row->census_date,
                    $row->civil_status,
                    $row->religion,
                    $row->ncip_number,
                    $row->occupation,
                    $row->income,
                    $row->pwd,
                    $row->educational_level,
                    $row->degree
                ]);
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }

    public function transaction($id)
    {
        $record = IPRecord::findOrFail($id);
        return view('admin.ip_records.transaction', compact('record'));
    }

    public function show($id)
    {
        $record = IPRecord::findOrFail($id);
        return view('admin.ip_records.show', compact('record'));
    }

    // -------------------- CERTIFICATE METHODS --------------------
    public function showCertificate($id)
    {
        $record = IPRecord::findOrFail($id);
        return view('admin.ip_records.certificate', compact('record'));
    }
    
    public function printCertificate($id)
    {
        $record = IPRecord::findOrFail($id);
        
        $pdf = Pdf::loadView('admin.ip_records.certificate_pdf', compact('record'));
        $pdf->setPaper('A4', 'portrait');
        
        $filename = 'COC-' . $record->first_name . '-' . $record->last_name . '-' . date('Y-m-d') . '.pdf';
        
        return $pdf->download($filename);
    }

    // -------------------- Validation Helper --------------------
    private function validateRecord(Request $request)
    {
        return $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'sex' => 'required|string|max:10',
            'ip_group' => 'required|string|max:100',
            'birth_date' => 'required|date',
            'origin_province' => 'nullable|string|max:100',
            'origin_municipality' => 'nullable|string|max:100',
            'origin_barangay' => 'nullable|string|max:100',
            'census_date' => 'required|date',
            'province' => 'required|string|max:100',
            'municipality' => 'required|string|max:100',
            'barangay' => 'required|string|max:100',
            'civil_status' => 'required|string|max:50',
            'religion' => 'required|string|max:100',
            'ncip_number' => 'required|string|max:100',
            'occupation' => 'required|string|max:100',
            'income' => 'nullable|string|max:100',
            'pwd' => 'nullable|string|max:100',
            'educational_level' => 'required|string|max:50',
            'degree' => 'nullable|string|max:100',
            'image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);
    }
public function formCertificate($id, Request $request)
{
    $record = IPRecord::findOrFail($id);
    
    $pdf = Pdf::loadView('admin.ip_records.coc_template', compact('record'));
    $pdf->setPaper('A4', 'portrait');
    
    // Generate filename with COC number format
    $cocNumber = 'COC-R03-NUE-' . date('m-y', strtotime($record->created_at)) . '-' . str_pad($record->id, 4, '0', STR_PAD_LEFT);
    $filename = $cocNumber . '.pdf';
    
    // Check if download is requested
    if ($request->get('download') == '1') {
        return $pdf->download($filename);
    }
    
    // Default: stream for preview
    return $pdf->stream($filename);
}
}