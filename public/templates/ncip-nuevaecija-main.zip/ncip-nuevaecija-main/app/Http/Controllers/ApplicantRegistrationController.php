<?php

namespace App\Http\Controllers;

use App\Models\ApplicantRegistration;
use Illuminate\Http\Request;

class ApplicantRegistrationController extends Controller
{
    /**
     * Show registration form
     */
    public function create()
    {
        return view('auth.register');
    }

    /**
     * Handle registration with document upload
     */
    public function store(Request $request)
    {
        // Validate input
        $data = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name'  => 'required|string|max:255',
            'email'      => 'required|email|unique:applicant_registrations,email',
            'contact'    => 'nullable|string|max:20',
            'address'    => 'nullable|string|max:255',
            'password'   => 'required|string|min:6|confirmed',
            'document'   => 'required|file|mimes:jpg,jpeg,png,pdf|max:2048',
        ]);

        // Hash password
        $data['password'] = bcrypt($data['password']);

        // Upload file to storage/app/public/documents
        if ($request->hasFile('document')) {
            $file = $request->file('document');
            $filename = time() . '_' . $file->getClientOriginalName();
            $path = $file->storeAs('documents', $filename, 'public'); // saves in storage/app/public/documents

            // Save the relative path to DB
            $data['document_path'] = $path;
        }

        // Create applicant registration
        ApplicantRegistration::create($data);

        return redirect()->route('login')
            ->with('success', 'Registration submitted. Please wait for approval.');
    }
    public function decline($id)
{
    $application = ApplicantRegistration::find($id);

    if (!$application) {
        return redirect()->back()->with('error', 'Application not found.');
    }

    $application->status = 'Declined';
    $application->save();

    return redirect()->back()->with('success', 'Application declined successfully.');
}

}
