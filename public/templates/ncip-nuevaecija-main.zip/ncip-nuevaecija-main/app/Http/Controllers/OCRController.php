<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use thiagoalessio\TesseractOCR\TesseractOCR; // ✅ make sure this is imported

class OCRController extends Controller
{
    public function scan(Request $request)
    {
        $request->validate([
            'birth_certificate' => 'required|image|mimes:jpeg,png,jpg|max:5120',
        ]);

        $file = $request->file('birth_certificate');

        try {
            // Make sure method chaining starts immediately after new TesseractOCR()
            $ocr = new TesseractOCR($file->getPathname());
            $ocr->executable('C:\\Program Files\\Tesseract-OCR\\tesseract.exe');
            $ocr->lang('eng');

            $text = $ocr->run();

            return response()->json([
                'success' => true,
                'text' => $text,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'OCR failed: ' . $e->getMessage(),
            ]);
        }
    }
}
