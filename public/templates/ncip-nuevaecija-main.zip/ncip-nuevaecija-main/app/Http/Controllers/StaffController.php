<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CocApplication;
use App\Models\IpAccount;

class StaffController extends Controller
{
    // Dashboard
    public function index()
    {
        return view('staff.dashboard');
    }

    // Staff Profile
    public function profile()
    {
        return view('staff.profile');
    }

    // Review Applications
    public function review()
    {
        $underReview = CocApplication::where('status', 'Under Review')
            ->with('user') // eager load para maiwasan N+1
            ->orderBy('created_at', 'desc')
            ->get();

        $approved = CocApplication::where('status', 'Approved')
            ->with('user')
            ->orderBy('created_at', 'desc')
            ->get();

        $returned = CocApplication::where('status', 'Returned')
            ->with('user')
            ->orderBy('created_at', 'desc')
            ->get();

        return view('staff.review', compact('underReview', 'approved', 'returned'));
    }

    public function show($id)
    {
        $application = CocApplication::findOrFail($id);

        $step1 = json_decode($application->step1, true) ?? [];
        $step2 = json_decode($application->step2, true) ?? [];
        $step3 = json_decode($application->step3, true) ?? [];
        $step4 = json_decode($application->step4, true) ?? [];

        $ipAccount = $application->user ?? null; // ← This is the applicant account

        return view('staff.show', compact('application', 'ipAccount', 'step1', 'step2', 'step3', 'step4'));
    }

    // Approve application
    public function approve($id)
    {
        $application = CocApplication::findOrFail($id);
        $application->status = 'Approved';
        $application->save();

        return redirect()->route('staff.review')->with('success', 'Application approved successfully.');
    }

    // Return application
    public function return($id, Request $request)
    {
        $application = CocApplication::findOrFail($id);
        $application->status = 'Returned';
        $application->remarks = $request->input('remarks', 'No remarks provided');
        $application->save();

        return redirect()->route('staff.review')->with('success', 'Application returned successfully.');
    }

    public function decision(Request $request, $id)
    {
        try {
            $application = CocApplication::findOrFail($id);

            // ✅ Update statuses and remarks
            $application->index_status = $request->input('index_status');
            $application->index_remarks = $request->input('index_remarks');
            $application->genealogy_status = $request->input('genealogy_status');
            $application->genealogy_remarks = $request->input('genealogy_remarks');
            $application->documents_status = $request->input('documents_status');
            $application->documents_remarks = $request->input('documents_remarks');
            $application->classification = $request->input('classification', []);

            // Determine if all approved
            $allApproved = $application->index_status === 'approved' &&
                          $application->genealogy_status === 'approved' &&
                          $application->documents_status === 'approved';

            if ($allApproved) {
                $application->status = 'Approved';
                $application->coc_status = 'Admin Approval';
                $application->save();

                // Create message based on classification
                $classifications = $application->classification;
                $message = '';
                
                if (is_array($classifications)) {
                    if (in_array('national', $classifications) && in_array('local', $classifications)) {
                        $message = 'Application has been successfully forwarded to Regional Admin for National and Local Purpose.';
                    } elseif (in_array('national', $classifications)) {
                        $message = 'Application has been successfully forwarded to Regional Admin for National Purpose.';
                    } elseif (in_array('local', $classifications)) {
                        $message = 'Application has been successfully forwarded to Provincial Admin for Local Purpose.';
                    } else {
                        $message = 'Application has been successfully forwarded to Admin.';
                    }
                } else {
                    $message = 'Application has been successfully forwarded to Admin.';
                }

                // Always return JSON if ajax or json parameter is present
                if ($request->has('ajax') || $request->has('json') || $request->ajax()) {
                    return response()->json([
                        'success' => true,
                        'message' => $message,
                        'type' => 'approved'
                    ]);
                }

                return redirect()->route('staff.review')
                                ->with('success', 'Application forwarded successfully.');
            } else {
                $application->status = 'Returned';
                $application->coc_status = 'Returned';
                $application->save();

                // Always return JSON if ajax or json parameter is present
                if ($request->has('ajax') || $request->has('json') || $request->ajax()) {
                    return response()->json([
                        'success' => true,
                        'message' => 'Application has been returned to applicant for corrections.',
                        'type' => 'returned'
                    ]);
                }

                return redirect()->route('staff.review')
                                ->with('success', 'Application returned to applicant for correction.');
            }

        } catch (\Exception $e) {
            // Always return JSON if ajax or json parameter is present
            if ($request->has('ajax') || $request->has('json') || $request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Error: ' . $e->getMessage(),
                    'type' => 'error'
                ]);
            }

            return redirect()->back()->with('error', 'An error occurred while processing the decision.');
        }
    }
}