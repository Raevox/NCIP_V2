<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\IPRecord;
use App\Models\CocApplication;
use App\Models\IpAccount;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;

class AdminController extends Controller
{
   public function index()
{
    $totalUsers = IpAccount::count();
    $totalIPRecords = IPRecord::count();
    $totalCOC = CocApplication::where('coc_status', 'Approved')->count();
    $totalPending = CocApplication::where('coc_status', 'Pending')->count();

    // Group applications by tribe (via applicant)
    $monthlyApplications = CocApplication::with('applicant')
        ->selectRaw('user_id, COUNT(*) as count')
        ->groupBy('user_id')
        ->get()
        ->map(function ($app) {
            return [
                'tribe' => $app->applicant?->tribe ?? 'Unknown',
                'count' => $app->count,
            ];
        })
        ->groupBy('tribe') // ✅ pagsamahin per tribe
        ->map(function ($group) {
            return $group->sum('count');
        });

    // Convert into labels + data para sa chart
    $chartLabels = $monthlyApplications->keys();   // tribes
    $chartData   = $monthlyApplications->values(); // counts

    // Applications for applicants table (wag isama walang applicant)
    $applications = CocApplication::with('applicant')
        ->whereHas('applicant')
        ->orderByRaw("
            CASE 
                WHEN coc_status = 'Admin Approval' THEN 1
                WHEN coc_status = 'Returned' THEN 2
                ELSE 3
            END
        ")
        ->orderBy('created_at', 'desc')
        ->take(10)
        ->get();

    return view('dashboard', compact(
    'totalUsers',
    'totalIPRecords',
    'totalCOC',
    'totalPending',
    'chartLabels',
    'chartData',
    'applications'
));

}


    // ✅ AJAX Search Method
    public function search(Request $request)
    {
        try {
            $status = $request->input('status', 'all');
            $search = $request->input('search', '');
            
            $query = CocApplication::with(['applicant' => function($q) {
                $q->select('id', 'first_name', 'last_name', 'email', 'tribe', 'contact');
            }]);

            // Status filter
            if ($status !== 'all') {
                $query->where('coc_status', $status);
            }

            // Search filter
            if (!empty($search)) {
                $query->whereHas('applicant', function ($q) use ($search) {
                    $q->where('first_name', 'like', "%{$search}%")
                      ->orWhere('last_name', 'like', "%{$search}%")
                      ->orWhere('email', 'like', "%{$search}%");
                });
            }

            $applications = $query->orderByRaw("CASE 
                    WHEN coc_status = 'Admin Approval' THEN 1 
                    WHEN coc_status = 'Returned' THEN 2
                    ELSE 3 END ASC")
                ->orderBy('created_at', 'desc')
                ->paginate(10);

            // Format data for AJAX response
            $formattedApplications = [];
            foreach ($applications as $coc) {
                $formattedApplications[] = [
                    'id' => $coc->id,
                    'applicant' => [
                        'id' => $coc->applicant->id,
                        'first_name' => $coc->applicant->first_name,
                        'last_name' => $coc->applicant->last_name,
                        'email' => $coc->applicant->email,
                        'tribe' => $coc->applicant->tribe,
                    ],
                    'coc_status' => $coc->coc_status,
                    'classification' => $coc->classification ?? [],
                    'created_at' => $coc->created_at,
                ];
            }

            return response()->json([
                'success' => true,
                'applicants' => $formattedApplications,
                'pagination' => [
                    'current_page' => $applications->currentPage(),
                    'last_page' => $applications->lastPage(),
                    'per_page' => $applications->perPage(),
                    'total' => $applications->total(),
                    'from' => $applications->firstItem(),
                    'to' => $applications->lastItem(),
                ],
                'total' => $applications->total()
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error performing search: ' . $e->getMessage()
            ]);
        }
    }

    // ✅ View Applicant Document
    public function viewDocument($id)
    {
        $applicant = IPRecord::findOrFail($id);

        if (!$applicant->document || !Storage::disk('public')->exists($applicant->document)) {
            abort(404, 'Document not found.');
        }

        return view('admin.applicants.document', compact('applicant'));
    }

    // ✅ Approve Application (Final Issuance of COC)
    public function approveApplication(Request $request, $id)
    {
        try {
            DB::transaction(function () use ($id) {
                // 1. Hanapin ang application at account
                $application = CocApplication::findOrFail($id);
                $account = IpAccount::findOrFail($application->user_id);

                // 2. Update status ng application
                $application->status = 'Approved';
                $application->coc_status = 'Approved';
                $application->save();

                // 3. Kunin ang step1 data (JSON decode)
                $step1 = $application->step1 ? json_decode($application->step1, true) : [];

                // 4. Insert or Update sa ip_records
                

                // 5. Send Email Notification
                if (!empty($account->email)) {
                    $emailMessage = "Hi {$account->first_name},\n\n" .
                                    "Your COC application has been approved.\n\n" .
                                    "Pickup Location\n" .
                                    "Burgos Avenue at Old Capitol, Cabanatuan City, Nueva Ecija\n\n" .
                                    "Instructions\n" .
                                    "Please bring the hard copy of the following:\n" .
                                    "• Certificate of IP Membership\n" .
                                    "• Two (2) identical 2x2 ID photos\n" .
                                    "• Photocopy of Birth Certificate\n" .
                                    "• Certification from the Office of the Tribal Chieftain";

                    Mail::raw($emailMessage, function ($message) use ($account) {
                        $message->to($account->email)
                                ->subject('COC Application Approved');
                    });
                }

                // 6. Send SMS Notification
                if (!empty($account->contact)) {
                    try {
                        Http::post('https://sms-provider-api/send', [
                            'to' => $account->contact,
                            'message' => "Hi {$account->first_name}, your COC application has been approved by the Admin. Your Certificate of Confirmation has been issued.",
                        ]);
                    } catch (\Exception $e) {
                        \Log::error('SMS sending failed: '.$e->getMessage());
                    }
                }
            });

            // Return JSON response for AJAX requests
            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Application has been approved successfully! COC issued and notifications sent to the applicant.'
                ]);
            }

            return redirect()->back()->with('success', 'Application approved, IP record created, and notifications sent.');

        } catch (\Exception $e) {
            // Handle errors for AJAX requests
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Error approving application: ' . $e->getMessage()
                ]);
            }

            return redirect()->back()->with('error', 'An error occurred while approving the application.');
        }
    }

    // ✅ Decline Application Method
    public function decline(Request $request, $id)
    {
        try {
            $applicant = IpAccount::findOrFail($id);
            $reason = $request->input('reason', 'No reason provided');

            // Decline the COC application
            if ($applicant->latestCocApplication) {
                $application = $applicant->latestCocApplication;
                $application->status = 'Declined';
                $application->coc_status = 'Declined';
                $application->remarks = $reason;
                $application->save();
            }

            // Send notification email if needed
            if (!empty($applicant->email)) {
                $emailMessage = "Hi {$applicant->first_name},\n\n" .
                               "Unfortunately, your COC application has been declined.\n\n" .
                               "Reason: {$reason}\n\n" .
                               "You may contact our office for more information.";

                Mail::raw($emailMessage, function ($message) use ($applicant) {
                    $message->to($applicant->email)
                            ->subject('COC Application Declined');
                });
            }

            // Return JSON response for AJAX requests
            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Application has been declined successfully. Notification sent to the applicant.'
                ]);
            }

            return redirect()->back()->with('success', 'Application declined successfully.');

        } catch (\Exception $e) {
            // Handle errors for AJAX requests
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Error declining application: ' . $e->getMessage()
                ]);
            }

            return redirect()->back()->with('error', 'An error occurred while declining the application.');
        }
    }
    // ✅ Archive Applicant (soft delete account + related applications)
public function archive($id)
{
    $account = IpAccount::findOrFail($id);

    // Soft delete related applications
    $account->applications()->delete();

    // Soft delete the account itself
    $account->delete();

    return redirect()->back()->with('success', 'Applicant archived successfully.');
}

// ✅ Restore Applicant (restore account + related applications)
public function restore($id)
{
    $account = IpAccount::withTrashed()->findOrFail($id);

    // Restore account
    $account->restore();

    // Restore related applications
    $account->applications()->withTrashed()->restore();

    return redirect()->back()->with('success', 'Applicant restored successfully.');
}

}
