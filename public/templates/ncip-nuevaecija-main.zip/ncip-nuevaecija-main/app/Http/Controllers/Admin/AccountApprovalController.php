<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ApplicantRegistration;
use App\Models\IpAccount;
use App\Models\User;
use App\Models\IPRecord;
use App\Models\CocApplication;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\AccountApprovedMail;

class AccountApprovalController extends Controller
{
    /**
     * List applicants with approved coc applications
     */
public function index(Request $request)
{
    $status = $request->get('status', 'all'); // default all

    $query = CocApplication::with('applicant')
        ->whereNotIn('coc_status', ['Draft', 'Under Review'])
        ->whereHas('applicant'); // ✅ filter out yung walang applicant

    if ($status !== 'all') {
        $query->where('coc_status', $status);
    }

    // search filter
    if ($request->filled('search')) {
        $search = $request->search;
        $query->whereHas('applicant', function ($q) use ($search) {
            $q->where('first_name', 'LIKE', "%{$search}%")
              ->orWhere('last_name', 'LIKE', "%{$search}%")
              ->orWhere('email', 'LIKE', "%{$search}%");
        });
    }

    $applications = $query
        ->orderByRaw("CASE WHEN coc_status = 'Admin Approval' THEN 1 WHEN coc_status = 'Returned' THEN 2 ELSE 3 END")
        ->orderBy('created_at', 'desc')
        ->paginate(10);

    if ($request->ajax()) {
        return view('admin.applicants.partials.applicant-table', compact('applications'))->render();
    }

    return view('admin.applicants.index', compact('applications', 'status'));
}


    /**
     * Approve pending applicant -> move to IpAccounts
     */
    public function approve(Request $request, $id)
    {
        try {
            $applicant = ApplicantRegistration::findOrFail($id);

            // Move/update to IpAccounts
            $ipAccount = IpAccount::updateOrCreate(
                ['email' => $applicant->email],
                [
                    'first_name'        => $applicant->first_name,
                    'last_name'         => $applicant->last_name,
                    'name'              => $applicant->first_name . ' ' . $applicant->last_name,
                    'contact'           => $applicant->contact,
                    'address'           => $applicant->address,
                    'province_code'     => $applicant->province_code,
                    'province_name'     => $applicant->province_name,
                    'municipality_code' => $applicant->municipality_code,
                    'municipality_name' => $applicant->municipality_name,
                    'barangay_code'     => $applicant->barangay_code,
                    'barangay_name'     => $applicant->barangay_name,
                    'tribe'             => $applicant->tribe,
                    'leader'            => $applicant->leader,
                    'password'          => $applicant->password,
                    'status'            => 'active',
                    'document_path'     => $applicant->document_path ?? null,
                    'document_text'     => $applicant->document_text ?? null,
                ]
            );

            // Mark applicant as approved
            $applicant->update(['status' => 'approved']);

            // Send approval email to applicant
            if (!empty($ipAccount->email)) {
                try {
                    Mail::to($ipAccount->email)->send(new AccountApprovedMail($applicant));
                } catch (\Exception $e) {
                    \Log::error('Email sending failed: ' . $e->getMessage());
                }
            }

            // Return JSON response for AJAX requests
            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Account has been approved successfully! Welcome email sent to the applicant.'
                ]);
            }

            return redirect()->route('admin.applicants.pending')
                           ->with('success', 'Account approved, moved to IP Accounts, and email sent to applicant.');

        } catch (\Exception $e) {
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Error approving account: ' . $e->getMessage()
                ]);
            }

            return redirect()->back()->with('error', 'An error occurred while approving the account.');
        }
    }

    /**
     * Decline applicant with email notification and database removal
     */
    public function decline(Request $request, $id)
    {
        try {
            $applicant = ApplicantRegistration::findOrFail($id);
            $reason = $request->input('reason', 'No reason provided');

            // Send decline email with reason
            if (!empty($applicant->email)) {
                try {
                    $emailMessage = "Hi {$applicant->first_name},\n\n" .
                                  "Thank you for your interest in registering with NCIP Nueva Ecija.\n\n" .
                                  "Unfortunately, your account registration has been declined for the following reason:\n\n" .
                                  "REASON: {$reason}\n\n" .
                                  "What to do next:\n" .
                                  "• Please review and correct the issues mentioned above\n" .
                                  "• You may register again once the requirements are met\n" .
                                  "• For questions, contact our office during business hours\n\n" .
                                  "Office Contact Information:\n" .
                                  "Address: Burgos Avenue at Old Capitol, Cabanatuan City, Nueva Ecija\n" .
                                  "Phone: [Your phone number]\n" .
                                  "Email: [Your email address]\n\n" .
                                  "Thank you for your understanding.\n\n" .
                                  "NCIP Nueva Ecija Office";

                    Mail::raw($emailMessage, function ($message) use ($applicant) {
                        $message->to($applicant->email)
                                ->subject('Account Registration Declined - NCIP Nueva Ecija');
                    });
                } catch (\Exception $e) {
                    \Log::error('Decline email sending failed: ' . $e->getMessage());
                }
            }

            // Remove the applicant from database (hard delete to allow re-registration)
            $applicantName = $applicant->first_name . ' ' . $applicant->last_name;
            $applicant->delete();

            // Return JSON response for AJAX requests
            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => "Account for {$applicantName} has been declined and removed. Decline reason sent via email."
                ]);
            }

            return redirect()->route('admin.applicants.pending')
                           ->with('success', 'Account declined, removed from database, and notification email sent.');

        } catch (\Exception $e) {
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Error declining account: ' . $e->getMessage()
                ]);
            }

            return redirect()->back()->with('error', 'An error occurred while declining the account.');
        }
    }

    /**
     * List approved IpAccounts
     */
    public function approvedAccounts(Request $request)
    {
        $query = IpAccount::where('status', 'active');

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('first_name', 'LIKE', "%{$search}%")
                  ->orWhere('last_name', 'LIKE', "%{$search}%")
                  ->orWhere('email', 'LIKE', "%{$search}%")
                  ->orWhere('contact', 'LIKE', "%{$search}%");
            });
        }

        $approvedUsers = $query->paginate(10);

        return view('admin.applicants.accounts', compact('approvedUsers'));
    }

    /**
     * View applicant details
     */
    public function view($id)
    {
        $applicant = ApplicantRegistration::findOrFail($id);
        return view('admin.applicants.view', compact('applicant'));
    }

    /**
     * View applicant document
     */
    public function viewDocument($id)
    {
        $applicant = ApplicantRegistration::findOrFail($id);

        if (!$applicant->document_path || !file_exists(storage_path('app/public/' . $applicant->document_path))) {
            abort(404, 'Document not found.');
        }

        $extension = strtolower(pathinfo($applicant->document_path, PATHINFO_EXTENSION));

        return view('admin.applicants.view-document', compact('applicant', 'extension'));
    }

    /**
     * Archive an IpAccount
     */
   public function archive($id)
{
    $account = IpAccount::findOrFail($id);

    // Archive related applications and records
    CocApplication::where('user_id', $account->id)->delete();
    IPRecord::where('first_name', $account->first_name)
            ->where('last_name', $account->last_name)
            ->delete();

    $account->delete(); // archive account mismo

    return redirect()->route('admin.applicants.accounts')
                     ->with('success', 'Account and related records archived successfully.');
}

public function restore($id)
{
    $account = IpAccount::onlyTrashed()->findOrFail($id);
    $account->restore();

    // Restore related applications and records
    CocApplication::onlyTrashed()->where('user_id', $account->id)->restore();
    IPRecord::onlyTrashed()
        ->where('first_name', $account->first_name)
        ->where('last_name', $account->last_name)
        ->restore();

    return redirect()->route('admin.archive.accounts')
                     ->with('success', 'Account and related records restored successfully.');
}


    /**
     * Show archived accounts
     */
    public function archivedAccounts()
    {
        $staffAdminAccounts = User::onlyTrashed()
            ->whereIn('role', ['admin', 'staff'])
            ->paginate(10, ['*'], 'staffAdminPage');

        $ipAccounts = IpAccount::onlyTrashed()
            ->paginate(10, ['*'], 'ipPage');

        $records = IPRecord::onlyTrashed()->paginate(10, ['*'], 'recordsPage');

        return view('admin.archive.index', compact('staffAdminAccounts', 'ipAccounts', 'records'));
    }

    /**
     * List pending applicants
     */
    public function pending(Request $request)
    {
        $query = ApplicantRegistration::where('status', 'pending');

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('first_name', 'LIKE', "%{$search}%")
                  ->orWhere('last_name', 'LIKE', "%{$search}%")
                  ->orWhere('email', 'LIKE', "%{$search}%")
                  ->orWhere('contact', 'LIKE', "%{$search}%");
            });
        }

        $pendingAccounts = $query->get();

        $pendingAccounts = $query->get();

        // Quick OCR name match
        $pendingAccounts->transform(function ($account) {
            $expectedName  = strtolower($account->first_name . ' ' . $account->last_name);
            $extractedName = strtolower($account->name ?? '');
            $account->ocr_match = stripos($extractedName, $expectedName) !== false ? 'Match' : 'Mismatch';
            return $account;
        });

        return view('admin.applicants.pending_accounts', compact('pendingAccounts'));
    }

    /**
     * Admin approval of CocApplication -> move to IpRecords
     */
public function adminApprove($id)
{
    $application = CocApplication::findOrFail($id);

    // Check current status, block if already Approved
    if ($application->coc_status === 'Approved') {
        return redirect()->back()
                         ->with('info', 'This application is already approved. No action taken.');
    }

    // Just update status, do not move to IPRecord
    $application->status     = 'Approved';
    $application->coc_status = 'Approved';
    $application->save();

    return redirect()->back()
                     ->with('success', 'Application status updated to Approved. No record was moved.');
}


// Restore IP Record
public function restoreIpRecord($id)
{
    $record = IPRecord::onlyTrashed()->findOrFail($id);
    $record->restore();

    return redirect()->route('admin.archive.ip_records')
                     ->with('success', 'IP Record restored successfully.');
}

// Restore Staff/Admin Accounts
public function restoreStaffAdmin($id)
{
    $account = User::onlyTrashed()->findOrFail($id);
    $account->restore();

    return redirect()->route('admin.archive.accounts')
                     ->with('success', 'Staff/Admin account restored successfully.');
}

// Restore Applicant Accounts (IpAccount)
public function restoreIpAccount($id)
{
    $account = IpAccount::onlyTrashed()->findOrFail($id);
    $account->restore();

    return redirect()->route('admin.archive.accounts')
                     ->with('success', 'Applicant account restored successfully.');
}


}