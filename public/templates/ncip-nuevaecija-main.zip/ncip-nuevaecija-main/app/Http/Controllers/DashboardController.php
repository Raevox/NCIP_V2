<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\IPRecord; // <-- Import mo ito!
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        return view('dashboard', [
            'totalUsers' => User::count(),
            'totalIPRecords' => IPRecord::count(), 
            'totalCOC' => 0,
            'totalPending' => 0,
            'monthlyApplications' => collect([
                ['tribe' => 'Aeta', 'count' => 5],
                ['tribe' => 'Ilongot', 'count' => 3],
                ['tribe' => 'Dumagat', 'count' => 7],
            ]),
        ]);
    }
}