<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes; // ✅ import SoftDeletes

class CocApplication extends Model
{
    use SoftDeletes; // ✅ enable SoftDeletes

    protected $fillable = [
        'user_id',
        'step1',
        'step2',
        'step3',
        'step4',
        'applicant_picture',
        'signature',
        'tribal_certificate',
        'birth_certificate',
        'genealogy_form',
        'tribe',
        'status',
        'remarks',
        'index_status',
        'genealogy_status',
        'documents_status',
        'submitted_at',
        'coc_status', 
    ];

    protected $casts = [
        'step1' => 'array',
        'step2' => 'array',
        'step3' => 'array',
        'step4' => 'array',
        'submitted_at' => 'datetime',
        'created_at' => 'datetime',
        'remarks' => 'array',
        'classification' => 'array',
        'coc_status' => 'string',
    ];

    // 🔹 Relationships
    public function user()
    {
        return $this->belongsTo(IpAccount::class, 'user_id', 'id');
    }

    public function applicant()
    {
        return $this->belongsTo(IpAccount::class, 'user_id', 'id');
    }

    // 🔹 Returned sections/steps
    public function getReturnedSections(): array
    {
        $sections = [];
        if ($this->index_status === 'returned') $sections[] = 'index';
        if ($this->genealogy_status === 'returned') $sections[] = 'genealogy';
        if ($this->documents_status === 'returned') $sections[] = 'documents';
        return $sections;
    }

    public function countReturnedSections(): int
    {
        return count($this->getReturnedSections());
    }

    public function getReturnedSteps(): array
    {
        $map = [
            'index'     => [1, 2],
            'genealogy' => [3, 4],
            'documents' => [5],
        ];
        $steps = [];
        foreach ($this->getReturnedSections() as $section) {
            $steps = array_merge($steps, $map[$section]);
        }
        return $steps;
    }

    public function getNextReturnedStep(): ?int
    {
        $steps = $this->getReturnedSteps();
        return !empty($steps) ? min($steps) : null;
    }
}
