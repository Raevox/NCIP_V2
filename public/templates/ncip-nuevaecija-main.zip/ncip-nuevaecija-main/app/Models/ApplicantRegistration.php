<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApplicantRegistration extends Model
{
    use HasFactory;

    protected $fillable = [
        'first_name',
        'last_name',
        'name',
        'email',
        'contact',
        'address',
        'province_code',
        'province_name',
        'municipality_code',
        'municipality_name',
        'barangay_code',
        'barangay_name',
        'tribe',
        'leader',
        'password',
        'status',
        'document_path',   
        'updated_at',
        'created_at',  
    ];
public function ipAccount()
{
    return $this->hasOne(IpAccount::class, 'email', 'email');
}

public function latestCocApplication()
{
    return $this->hasOneThrough(
        CocApplication::class,
        IpAccount::class,
        'email',   
        'user_id', 
        'email',   
        'id'       
    )->latestOfMany();
}

public function cocApplications()
{
    return $this->hasManyThrough(
        CocApplication::class,
        IpAccount::class,
        'email',
        'user_id',
        'email',
        'id'
    );
}

}
