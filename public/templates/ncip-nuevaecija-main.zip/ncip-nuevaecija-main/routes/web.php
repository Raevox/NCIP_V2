<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\IPController;
use App\Http\Controllers\IPRecordController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\Admin\AccountApprovalController;
use App\Http\Controllers\StaffAccountController;
use App\Http\Controllers\ApplicantDashboardController;
use App\Http\Controllers\OCRController;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\SignatureController;

// 🌐 Public Welcome Page
Route::get('/', fn() => view('auth.login'));
// 🔀 Redirect Based on Role (Home Path)
Route::get('/redirect-based-on-role', function () {
    if (Auth::check()) {
        $role = Auth::user()->role;
        if ($role === 'admin') {
            return redirect()->route('admin.dashboard');
        } elseif ($role === 'staff') {
            return redirect()->route('staff.dashboard');
        }
    } elseif (Auth::guard('applicant')->check()) {
        return redirect()->route('applicant.dashboard');
    }
    return redirect('/login');
});

// 🛡️ Authentication Routes
require __DIR__.'/auth.php';

// 🔹 OCR Scan
// 🔹 OCR Scan
Route::post('/ocr/scan', [OCRController::class, 'scan'])->name('ocr.scan');
Route::post('/api/process-signature', [SignatureController::class, 'processSignature'])->name('api.process-signature');

// 🔹 Additional Signature Routes
Route::get('/api/signature-preview/{path}', [SignatureController::class, 'getPreview'])->name('api.signature-preview');
Route::post('/api/compare-signatures', [SignatureController::class, 'compareSignatures'])->name('api.compare-signatures');
// ✅ TEST EMAIL ROUTE
Route::get('/test-mail', function () {
    Mail::raw('This is a test email from NCIP system.', function ($message) {
        $message->to('ninoemmanueltadeo@gmail.com') // 🔹 palitan mo ng email mo muna para matest
                ->subject('Test Mail');
    });

    return 'Test email sent!';
});

// 🔐 Authenticated & Verified Routes
Route::middleware(['auth:web', 'verified'])->group(function () {
    // 📝 Approve COC Application (Admin)
    Route::put('/admin/applications/{id}/approve', [AdminController::class, 'approveApplication'])->name('admin.applications.approve');

    // 📊 Dashboards
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/admin/dashboard', [AdminController::class, 'index'])->name('admin.dashboard');
    Route::get('/staff/dashboard', [StaffController::class, 'index'])->name('staff.dashboard');
    Route::get('/ip/dashboard', [IPController::class, 'index'])->name('ip.dashboard');

    // 👤 Profile
    Route::prefix('profile')->group(function () {
        Route::get('/', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/', [ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/', [ProfileController::class, 'destroy'])->name('profile.destroy');
    });

    // 🗂 IP Records (Admin)
    Route::prefix('admin/ip-records')->name('ip_records.')->group(function () {
    Route::get('/', [IPRecordController::class, 'index'])->name('index');
    Route::get('/create', [IPRecordController::class, 'create'])->name('create');
    Route::post('/', [IPRecordController::class, 'store'])->name('store');
    Route::get('/{id}', [IPRecordController::class, 'show'])->name('show');
    Route::get('/{id}/edit', [IPRecordController::class, 'edit'])->name('edit');
    Route::put('/{id}', [IPRecordController::class, 'update'])->name('update');
    Route::delete('/{id}', [IPRecordController::class, 'destroy'])->name('destroy');
    Route::get('/{id}/transaction', [IPRecordController::class, 'transaction'])->name('transaction');
    Route::get('/download/export', [IPRecordController::class, 'download'])->name('download');

    // Certificate routes
    Route::get('ip_records/{id}/certificate', [IPRecordController::class, 'showCertificate'])->name('ip_records.certificate');
    Route::get('ip_records/{id}/certificate/pdf', [IPRecordController::class, 'printCertificate'])->name('ip_records.print_certificate_pdf');
    Route::get('/{id}/certificate/form', [IPRecordController::class, 'formCertificate'])->name('form_certificate'); // ✅ new route
    Route::get('/ip_records/{id}/form-certificate', [IPRecordController::class, 'formCertificate'])->name('ip_records.form_certificate');
});

// 🗂 Admin Applicants
Route::prefix('admin/applicants')->name('admin.applicants.')->group(function () {
    Route::get('/', [AccountApprovalController::class, 'index'])->name('index');
    Route::get('/pending', [AccountApprovalController::class, 'pending'])->name('pending'); 
    Route::post('/{id}/approve', [AccountApprovalController::class, 'approve'])->name('approve');
    Route::post('/{id}/decline', [AccountApprovalController::class, 'decline'])->name('decline');
    Route::get('/accounts', [AccountApprovalController::class, 'approvedAccounts'])->name('accounts');
    Route::post('/accounts/{id}/archive', [AccountApprovalController::class, 'archive'])->name('accounts.archive');
    Route::get('/{id}/view', [AccountApprovalController::class, 'view'])->name('view');
    Route::get('/{id}/document', [AccountApprovalController::class, 'viewDocument'])->name('document');

       Route::post('/{application}/coc-approve', [AdminController::class, 'approveApplication'])
        ->name('coc-approve');

    Route::post('/search', [AccountApprovalController::class, 'search'])->name('search');
});

// 🔹 Admin Accounts (CRUD + Archive/Restore)
Route::prefix('admin/accounts')->name('admin.accounts.')->group(function () {
    Route::get('/', [AccountController::class, 'index'])->name('index');
    Route::get('/create', [AccountController::class, 'create'])->name('create');
    Route::post('/', [AccountController::class, 'store'])->name('store');
    Route::get('/{account}', [AccountController::class, 'show'])->name('show');
    Route::get('/{account}/edit', [AccountController::class, 'edit'])->name('edit');
    Route::put('/{account}', [AccountController::class, 'update'])->name('update');
    Route::delete('/{account}', [AccountController::class, 'destroy'])->name('destroy');
});

// 🔹 Archived Accounts & IP Records
Route::prefix('admin/archive')->name('admin.archive.')->group(function () {
    // Accounts archive
    Route::get('/accounts', [AccountController::class, 'archive'])->name('accounts');
    Route::post('/accounts/{type}/{id}/restore', [AccountController::class, 'restore'])
        ->name('accounts.restore');

    // IP Records archive
    Route::get('/ip-records', [IPRecordController::class, 'archivedRecords'])->name('ip_records');
    Route::post('/ip-records/{id}/restore', [IPRecordController::class, 'restore'])->name('ip_records.restore');
    Route::get('/ip-records/{id}/archive', [IPRecordController::class, 'archive'])->name('ip_records.archive');
});


    // 👥 Staff Accounts
    Route::prefix('staff/accounts')->name('staff.accounts.')->group(function () {
        Route::get('/', [StaffAccountController::class, 'index'])->name('index');
        Route::get('/create', [StaffAccountController::class, 'create'])->name('create');
        Route::post('/', [StaffAccountController::class, 'store'])->name('store');
        Route::get('/{account}', [StaffAccountController::class, 'show'])->name('show');
    });
        // 👤 Staff Profile & Review
    Route::prefix('staff')->name('staff.')->group(function () {
        Route::get('/profile', [StaffController::class, 'profile'])->name('profile');
        Route::get('/review', [StaffController::class, 'review'])->name('review');

        // ✅ Show page with genealogy, documents, and applications tabs
        Route::get('/review/{id}', [StaffController::class, 'show'])->name('review.show');

        Route::post('/review/{id}/approve', [StaffController::class, 'approve'])->name('review.approve');
        Route::post('/review/{id}/return', [StaffController::class, 'return'])->name('review.return');

        // 📝 Review Decision (NEW)
        Route::put('/review/{id}/decision', [StaffController::class, 'decision'])->name('review.decision');
    });


});

// 🔹 Applicant Routes (Multi-step COC Form + Resubmit)
Route::prefix('applicant')->name('applicant.')->middleware('auth:applicant')->group(function () {
    Route::get('/dashboard', [ApplicantDashboardController::class, 'dashboard'])->name('dashboard');
    Route::get('/profile', [ApplicantDashboardController::class, 'profile'])->name('profile');
Route::get('/history', [ApplicantDashboardController::class, 'history'])->name('history');
    // COC Multi-step Form
    Route::prefix('coc')->name('coc.')->group(function () {
        Route::get('/', [ApplicantDashboardController::class, 'coc'])->name('index');

        // ✅ Alias para sa route('applicant.coc.application')
        Route::get('/application', [ApplicantDashboardController::class, 'coc'])->name('application');
        // Alias para gumana yung route('applicant.coc')
        Route::get('/coc', [ApplicantDashboardController::class, 'coc'])->name('coc');


        Route::get('/form/step1', [ApplicantDashboardController::class, 'showCocFormStep1'])->name('step1');
        Route::post('/form/step1', [ApplicantDashboardController::class, 'saveCocStep1'])->name('step1.store');
        Route::get('/form/step2', [ApplicantDashboardController::class, 'showCocFormStep2'])->name('step2');
        Route::post('/form/step2', [ApplicantDashboardController::class, 'saveCocStep2'])->name('step2.store');
        Route::get('/form/step3/{id?}', [ApplicantDashboardController::class, 'showCocFormStep3'])->name('step3');
        Route::post('/form/step3/{id?}', [ApplicantDashboardController::class, 'saveCocStep3'])->name('step3.store');
        Route::get('/form/step4/{id?}', [ApplicantDashboardController::class, 'showCocFormStep4'])->name('step4');
        Route::post('/form/step4/{id?}', [ApplicantDashboardController::class, 'saveCocStep4'])->name('step4.store');
        Route::get('/form/step5/{id?}', [ApplicantDashboardController::class, 'showCocFormStep5'])->name('step5');
        Route::post('/form/step5/{id?}', [ApplicantDashboardController::class, 'saveCocStep5'])->name('step5.store');
        Route::get('/preview/{id}', [ApplicantDashboardController::class, 'previewCoc'])->name('preview');
        Route::post('/submit/{id}', [ApplicantDashboardController::class, 'submitCoc'])->name('submit');
    });
    

    // Track Status
    Route::get('/track-status', [ApplicantDashboardController::class, 'trackStatus'])->name('track-status');
// ✅ Resubmit
Route::prefix('coc/resubmit')->name('coc.resubmit.')->group(function () {
    Route::get('/{application}', [ApplicantDashboardController::class, 'showResubmit'])->name('show');
    Route::post('/{application}', [ApplicantDashboardController::class, 'submitResubmit'])->name('post');
    Route::get('/step/{step}/{application}', [ApplicantDashboardController::class, 'resubmitToStep'])->name('step');
});

// ✅ Alias para gumana yung route('applicant.coc.resubmit')
Route::post('/applicant/coc/resubmit/{application}', [ApplicantDashboardController::class, 'submitResubmit'])
    ->name('applicant.coc.resubmit');

});

// 🚪 Logout for all guards
Route::post('/logout', function () {
    if (Auth::guard('applicant')->check()) {
        Auth::guard('applicant')->logout();
    } else {
        Auth::guard('web')->logout(); // admin + staff share web guard
    }
    return redirect('/login');
})->name('logout');
