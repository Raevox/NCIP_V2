<?php

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SignatureController;

// Test route para siguraduhin gumagana ang API
Route::get('/ping', function () {
    return response()->json(['message' => 'API is working']);
});

// Route para sa signature processing
Route::post('/process-signature', [SignatureController::class, 'processSignature'])
    ->name('api.process-signature');
